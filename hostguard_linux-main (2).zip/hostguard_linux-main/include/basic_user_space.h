/*** 
 * @Author: JiaHao
 * @Date: 2024-07-04 13:26:40
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-02 17:04:07
 * @FilePath: /hostguard_linux/include/basic_user_space.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#ifndef __BASIC_USER_SPACE_H
#define __BASIC_USER_SPACE_H

#include <future>
#include "utils.h"
#include "json.hpp"

using json = nlohmann::json;

/* 预定定义好的一些常量字符串最大长度 */
#define STATIC_STR_MAXLEN 50

/* Main Thread Id of each Manager */
enum class ManagerMainThreadId {
    UDISK_MANAGER_MAIN_THREAD = 0,
    EXEC_MANAGER_MAIN_THREAD = 1,
    GENERAL_MANAGER_MAIN_THREAD = 2,
    MANAGER_MAIN_THREAD_MAX
};

/* Sub Threads Id in each Manager */
enum class ManagerSubThreadId {
    SUB_THREAD_WHITELIST_MAIN_THREAD = 0,
    SUB_THREAD_MONITOR_MAIN_THREAD,
    SUB_THREAD_MANAGER_SERVER_THREAD,
    SUB_THREAD_MAX
};

enum class ReqRspType {
    REQUEST = 0,
    RESPONSE = 1,
    MAX
};


/* process Launcher */
class LauncherInfo {
public:
    unsigned long long pid = 0;
    uid_t uid = 0;
	uid_t euid = 0;
    std::string userName = "-";
};


/* Data Query Range */
class DataQueryRange {
public:
    unsigned int pageId_    = 0;
    unsigned int pageSize_  = 0;
public:
    void fromJson(const json& j);
    json toJson() const;
    std::stringstream print() const;
};

inline void DataQueryRange::fromJson(const json& j) {
    try {
        if (j.contains("pageId"))       { pageId_       = j.at("pageId").get<unsigned int>(); }
        else { throw std::invalid_argument("pageId is required!");}

        if (j.contains("pageSize"))     { pageSize_     = j.at("pageSize").get<unsigned int>(); }
        else { throw std::invalid_argument("pageSize is required!");}

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error DataQueryRange fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

inline json DataQueryRange::toJson() const {
    json j;
    j["pageId"]     = pageId_;
    j["pageSize"]   = pageSize_;
    return j;
}

inline std::stringstream DataQueryRange::print() const {
    std::stringstream ss;
    ss  << "[DataQueryRange: "      << std::endl
        << "    "   << "[pageId: "  << pageId_      << "]"  << std::endl
        << "    "   << "[pageSize: "<< pageSize_    << "]"  << std::endl
        << "]"      << std::endl;
    return ss;
}


#endif /* __BASIC_USER_SPACE_H */

