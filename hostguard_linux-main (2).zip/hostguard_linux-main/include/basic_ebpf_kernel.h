/*** 
 * @Author: JiaHao
 * @Date: 2024-05-21 09:05:33
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-07-04 13:25:25
 * @FilePath: /hostguard_linux/include/basic_ebpf_kernel.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef __BASIC_EBPF_KERNEL_H
#define __BASIC_EBPF_KERNEL_H

/* 父进程回溯的最大迭代次数 */
#define PARENT_TASK_ITER_MAX_COUNT  4

/* username 最大长度 */
#define USER_NAME_MAXLEN	256	/* 256 bytes */

/* BPF kernel 日志 */
// 定义BPF日志级别
#define BPF_LOG_CRITICAL	0
#define BPF_LOG_ERROR   	1
#define BPF_LOG_WARNING 	2
#define BPF_LOG_SUCCESS 	3
#define BPF_LOG_INFO    	4
#define BPF_LOG_DEBUG   	5
#define BPF_LOG_TRACE   	6

// 当前日志级别，默认为 DEBUG
#define BPF_LOG_LEVEL   	BPF_LOG_WARNING

// 定义一个宏来包装 printf，根据日志级别进行打印
#define BPF_LOG(level, format, ...)                        \
    do {                                               \
        if (level <= BPF_LOG_LEVEL) {                    \
            bpf_printk(format, ##__VA_ARGS__);             \
        }                                              \
    } while(0)



/* WorkMode */
enum HgWorkModeOption {
    WORK_MODE_OPTION_DEF = 0,
    WORK_MODE_OPTION_SILENT,
    WORK_MODE_OPTION_WARNING,
    WORK_MODE_OPTION_BLOCK,
    WORK_MODE_OPTION_MAX
};

/* real launcher info of sudo xx */
struct LauncherIDs {
	unsigned long long pid;
	uid_t uid;
	uid_t euid;
};


#endif /* __BASIC_EBPF_KERNEL_H */
