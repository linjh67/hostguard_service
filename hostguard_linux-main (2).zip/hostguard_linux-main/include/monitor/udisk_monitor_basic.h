/*** 
 * @Author: JiaHao
 * @Date: 2024-05-13 14:41:55
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-19 08:57:35
 * @FilePath: /hostguard_linux/include/monitor/udisk_monitor_basic.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef __UDISK_MONITOR_BASIC_H
#define __UDISK_MONITOR_BASIC_H

#include "basic_ebpf_kernel.h"

#define statfunc static __always_inline

#define MNT_FORCE	0x00000001	/* Attempt to forcibily umount */
#define MNT_DETACH	0x00000002	/* Just detach from the tree */
#define MNT_EXPIRE	0x00000004	/* Mark for expiry */
#define UMOUNT_NOFOLLOW	0x00000008	/* Don't follow symlink on umount, only umount symlink itself, and do not umount the actual target filesystem */
#define UMOUNT_UNUSED	0x80000000	/* Flag guaranteed to be unused */

#define SIGINT  2
#define SIGTERM 15

#define MS_RDONLY   1	    /* Mount read-only */






// Mount syscall args
#define MOUNT_TYPE_MAXLEN   64
#define DEV_NAME_MAXLEN     256
#define PATH_STR_MAXLEN     512

// USB Disk info
#define VENDOR_ID_MAXLEN   	16
#define PRODUCT_ID_MAXLEN   16
#define SERAIL_ID_MAXLEN   	128
#define UDISK_KEY_MAXLEN    (VENDOR_ID_MAXLEN + PRODUCT_ID_MAXLEN + SERAIL_ID_MAXLEN)

enum mount_event_type {
	DEFAULT_MOUNT_EVENT_TYPE = 0,
    KERNEL_MOUNT,
	MOUNT,
	UMOUNT,
    REMOUNT,    
    MOVE_MOUNT,
	MOUNT_EVENT_MAX,
};

enum mount_mode {
	DEFAULT_MOUNT_MODE = 0,
	MOUNT_READ_ONLY,
	MOUNT_READ_WRITE,
	MOUNT_OTHER,
	MOUNT_MODE_MAX,
};

enum mount_reaction {
	DENY_MOUNT = 0,
	ALLOW_MOUNT,
	WARNING_MOUNT,
	ALLOW_UMOUNT,
	WARNING_UMOUNT,
	REACT_MOUNT_MAX,
};

enum mount_retvalue {
	MOUNT_SUCCESS = 0,	
	MOUNT_EPERM = 1,			/* Operation not permitted */
	MOUNT_ENOENT = 2,			/* No such file or directory */
	/* ... */
	MOUNT_ENOTUDISK = 1000,		/* Not udisk dev */
};

enum umount_retvalue {
	UMOUNT_SUCCESS = 0,	
	UMOUNT_EPERM = 1,			/* Operation not permitted */
	UMOUNT_ENOENT = 2,			/* No such file or directory */
	/* ... */
	UMOUNT_ENOTUDISK = 1000,	/* Not udisk dev */
	UMOUNT_ENOFOLLOW = 1005,	/* Not follow symlink when umount */
};


struct mount_event {
	struct LauncherIDs launcher;
	enum mount_event_type event_type;
    enum mount_mode mode_in_udisk_whitelist;
    enum mount_mode mode_in_request;
	bool isLegal;
	enum mount_reaction react;		    // sizeof(enum mount_reaction): 4
	long syscall_ret;
	bool padding[4];
};

struct mount_args {
	char dev_name[DEV_NAME_MAXLEN];
    char path_str[PATH_STR_MAXLEN];
    char mount_type[MOUNT_TYPE_MAXLEN];
    unsigned long long flags;
};

struct mount_info {	
	unsigned long long pid;
	struct mount_event event;
	struct mount_args args;
};

struct kernel_udisk_whitelist_key {
	char dev_name[DEV_NAME_MAXLEN];
};

struct kernel_udisk_whitelist_value {	
    enum mount_mode mode;		    // sizeof(enum mount_mode): 4
	char padding[4];
};






#endif /* __UDISK_MONITOR_BASIC_H */