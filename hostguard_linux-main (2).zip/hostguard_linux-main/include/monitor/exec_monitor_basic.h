/*** 
 * @Author: JiaHao
 * @Date: 2023-11-14 15:27:47
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-22 08:48:40
 * @FilePath: /hostguard_linux/include/monitor/exec_monitor_basic.h
 * @Description: 
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved. 
 */

#ifndef __EXEC_MONITOR_BASIC_H
#define __EXEC_MONITOR_BASIC_H

#include "basic_ebpf_kernel.h"

#define statfunc static __always_inline

#define SIGINT  2
#define SIGTERM 15

#define EPERM       1   /* Operation not permitted */
#define ENOENT		2	/* No such file or directory */
#define	EINVAL		22	/* Invalid argument */
#define	EOPNOTSUPP	95	/* Operation not supported on transport endpoint */

#define TASK_COMM_LEN	 512
#define TASK_ARGV_NUM	 20			// only get the first TASK_ARGV_NUM argv; 
#define TASK_ARGV_LEN	 128
#define MAX_FILEPATH_LEN 2048

#define IMA_DIGEST_MAX_SIZE	64		/* [sha1: 20 bytes] [sha256: 32 bytes] [sha512: 64 bytes]*/


enum exec_event_type {
	DEFAULT_EXEC_EVENT_TYPE = 0,
	FORK = 1,
	VFORK = 2,
	CLONE = 3,
	EXECVE = 4,
	EXECVEAT = 5,
	LSM_EXEC = 6,
	EXIT = 7,
	EXEC_EVENT_MAX = 8,
};

/* events flag that has been processed successfully  */
enum exec_event_flag {
	FLAG_DEFAULT_EXEC_EVENT = 1<<DEFAULT_EXEC_EVENT_TYPE,
	FLAG_FORK 		= 1<<FORK,
	FLAG_VFORK 		= 1<<VFORK,
	FLAG_CLONE 		= 1<<CLONE,
	FLAG_EXECVE 	= 1<<EXECVE,
	FLAG_EXECVEAT 	= 1<<EXECVEAT,
	FLAG_LSM_EXEC 	= 1<<LSM_EXEC,
	FLAG_EXIT 		= 1<<EXIT,
	FLAG_EXEC_EVENT_MAX	= 1<<EXEC_EVENT_MAX,
};



enum exec_reaction {
	DENY_EXEC = 0,
	ALLOW_EXEC= 1,
	WARNING_EXEC = 2,
	OTHER_REACT_EXEC = 3,
	REACT_EXEC_MAX = 4,
};

struct task_event {
	struct LauncherIDs launcher;
	unsigned long long duration_us;
	unsigned int exit_code;
	enum exec_event_type type;
	enum exec_reaction react_whitelist;
	enum exec_reaction react_actual;		// sizeof(enum exec_reaction): 4
	char ima_hash[IMA_DIGEST_MAX_SIZE];
	char abs_filepath[MAX_FILEPATH_LEN];
	// char padding[4];
};

struct task_args {
	char argv[TASK_ARGV_NUM * TASK_ARGV_LEN];		// Note: 二维数组会导致verfier报错，只能用一维数组手动实现
	char comm[TASK_COMM_LEN];
};

struct task_info {	
	unsigned long long pid;
	unsigned long long ppid;
	unsigned long long event_history_flag;		/* (event_flag | CLONE) or (event_flag| LSM_EXEC) */
	unsigned long long start_time_ns;
	struct task_event event;
	struct task_args args;
};

struct kernel_exec_whitelist_key {	
	unsigned char ima_hash[IMA_DIGEST_MAX_SIZE];
};

struct kernel_exec_whitelist_value {	
	enum exec_reaction react;		// sizeof(enum exec_reaction): 4
	char padding[4];
};

/* key: 0 (u64) */
struct kernel_exec_workmode_value {
	enum HgWorkModeOption workmode;
	char padding[4];
};


#endif /* __EXEC_MONITOR_BASIC_H */
