/*** 
 * @Author: JiaHao
 * @Date: 2024-05-13 14:42:24
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-16 15:05:38
 * @FilePath: /hostguard_linux/include/monitor/udisk_monitor.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. s
 */

#ifndef __UDISK_MONITOR_H
#define __UDISK_MONITOR_H

#include <signal.h>
#include <libudev.h>
#include <sys/resource.h>
#include <pwd.h>
#include <iomanip>
#include <thread>
#include <filesystem>
#include "whitelist/udisk_whitelist.h"

/* 
首先，需要确定U盘的文件系统类型。
常见的文件系统有FAT32、NTFS、exFAT等。可以使用以下命令查看U盘的文件系统类型：
    sudo blkid /dev/sdb1

根据文件系统类型指定编码挂载U盘
FAT32或exFAT文件系统，可以使用以下命令指定编码（例如UTF-8）:
    sudo mount -o ro,iocharset=utf8 /dev/sdb1 ~/udisk/ 
    
NTFS文件系统，可以使用以下命令指定编码（例如UTF-8）:
    sudo mount -o ro,utf8 /dev/sdb1 ~/udisk/

*/



inline std::vector<std::string> udiskEventStrList = {
    "DEFAULT_EVENT", 
    "KERNEL_MOUNT", 
    "MOUNT", 
    "UMOUNT", 
    "REMOUNT", 
    "MOVE_MOUNT"
};

enum class UdiskMonitorSubThreadId {
    SUB_THREAD_RECORD = 0,
    SUB_THREAD_UDEV,
    SUB_THREAD_KERNEL,
    SUB_THREAD_MAX
};



class UdiskRecord {
public:
    unsigned long long pid_;
    LauncherInfo launcher_;
    std::string event_;  
    UdiskDevice device_;
    UdiskMountArgs mountArgs_;
    bool isLegal_ = false;
    std::string modeInRequest_ = "DEFAULT_MOUNT_MODE";
    std::string modeInWhiteList_ = "DEFAULT_MOUNT_MODE";
    std::string react_ = "DENY_MOUNT";
    std::string result_ = "MOUNT_SUCCESS";
    unsigned long long id_ = 0;
    std::string event_time_ = "";
};


class UdiskMonitor {
/*  func member */
public:
    UdiskMonitor(
        UdiskWhiteList* const pWhiteList,
        MySQLConnectionPool* pConnectionPool,
        const std::string& database = "hostguard_db",
        const std::string& tableName = "udisk_monitor"
    );
    ~UdiskMonitor();

    // uapi
    int init();
    int runMainThread();
    int stopMainThread();
    int reloadWhiteList();

private:
    // /* signal handler */
    // static void signalHandler(int sig);    

    /* database connection */
    int initConnection();
    void releaseConnection();
    int initDatabase();   

    /* database operation */
    int beginTransaction();
    int createDatabase();
    int deleteTable();
    int createTable();
    int deleteData();
    static int upsertData(const UdiskRecord& udiskRecord);
    static int retrieveData();
    int endTransaction();

    /* database record thread */
    int runDataRecordThread();

    /* whitelist operation*/
    int scanUdiskPluggedIn();

    /* udev monitor funcs */
    int getBlockDeviceInfo(struct udev_device *udevDevice, struct UdiskDevice& udiskDevice);
    int handleBlockDeviceAction(const char *action, udev_device *udevDevice);    
    int handleBlockDeviceAdd(struct udev_device *udevDevice);
    int handleBlockDeviceRemove(struct udev_device *udevDevice);
    int recordUdiskPlugEvent(const char *devnode, const std::string& plugEvent, const struct UdiskDevice& udiskDevice);
    int handleBlockDeviceOtherAction(struct udev_device *udevDevice);    

    /* userspace ebpf program */
    int runKernelMonitorThread();
    void clean();

    /* userspace ebpf map operation */
    int clearKernelWhiteList();
    int updateKernelWhiteList();
    int synchronizeKernelWhiteList();
    int lookupKernelWhiteList();

    /* userspace ebpf ringbuf handle funcs */
    static int handle_event(void* ctx, void* data, size_t data_sz);
    static int handleMount(const struct mount_info* p_mount_info);
    static int handleUmount(const struct mount_info* p_mount_info);

    /* udev monitor */
    int runUdevMonitorThread();

    /* start & end threads */
    int startSubThreads();
    int stopSubThreads();
    int joinSubThreads();


/* data member */
private:
    /* mutex */
    static std::mutex recordMutex_;

    /* semaphore */
    static std::counting_semaphore<0> recordRequestSemaphore_;    /* queue中元素初始数量为0, C++20 */

    /* data record queue */
    static std::queue<UdiskRecord> recordQueue_;

    /* signal handler */
    static volatile bool& exitingFlag_;

    /* sub thread running flag */
    static volatile bool subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_MAX)];

    /* database connection */
    static MySQLConnectionPool* pConnectionPool_;
    static std::string database_;
    static std::string tableName_;
    static std::shared_ptr<sql::Connection> connection_;

    /* whitelist */
    static UdiskWhiteList* pWhiteList_;

    /* monitor sub threads */
    std::map<UdiskMonitorSubThreadId, std::thread> subThreadsMap_ = {};

    /* ebpf monitor pointers */
    struct ring_buffer* rb_ = nullptr;
    struct udisk_monitor_bpf* skel_ = nullptr;
};



#endif /* __UDISK_MONITOR_H */