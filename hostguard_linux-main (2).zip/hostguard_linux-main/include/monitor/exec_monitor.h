/***
 * @Author: JiaHao
 * @Date: 2023-11-17 13:16:06
 * @LastEditors: JiaHao
 * @LastEditTime: 2023-12-27 13:39:25
 * @FilePath: /hostguard_linux/include/monitor_exec.h
 * @Description:
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved.
 */
#ifndef __EXEC_MONITOR_H
#define __EXEC_MONITOR_H

#include <argp.h>
#include <bpf/libbpf.h>
#include <openssl/evp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>
#include <pwd.h>
#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include "file_digest.hpp"
#include "monitor/exec_monitor_basic.h"
#include "whitelist/exec_whitelist.h"

inline std::vector<std::string> execEventStrList = {
    "DEFAULT", 
    "FORK", 
    "VFORK", 
    "CLONE", 
    "EXECVE", 
    "EXECVEA", 
    "EXEC", 
    "EXIT"
};

enum class ExecMonitorSubThreadId {
    SUB_THREAD_RECORD = 0,
    SUB_THREAD_KERNEL,
    SUB_THREAD_MAX
};


class ExecRecord {
public:
    std::string event_;
    unsigned long long pid_;
    unsigned long long ppid_;
    LauncherInfo launcher_;
    std::string command_;
    std::string filepath_;
    std::string args_           = "";
    std::string reactWhiteList_ = "DENY_EXEC";
    std::string reactActual_    = "DENY_EXEC";
    unsigned long long duration_us_ = 0;
    std::string fileDigest_     = "";
    unsigned long long id_      = 0;
    std::string time_           = "";
};



/* 
    Monitor record: 
    request & response 
*/

/* Exec Monitor Record Resquest */
class ExecMonitorRecordRequest
{
public:
    unsigned long long id_      = 0;
    ExecRecord execRecordEntry_ = {};
};

/* Exec Monitor Record Response */
class ExecMonitorRecordResponse
{
public:
    unsigned long long id_      = 0;
    ExecRecord execRecordEntry_ = {};
    bool isSuccess_         = true;
};



/*  1.为什么很多static类型的成员？
        1.ring_buffer__new(xx..) 的第二个参数 sample_cb 是回调函数，已规定好参数类型
        2.普通的类成员函数参数有 this指针，不符合要求，所以只能使用 static类型 函数
        3.static类型 函数只能访问 static类型 函数和变量，导致类成员多数为 static类型

    2.为什么使用 static MySQLConnectionPool* 而不是引用类型？
        1.static类型 变量需要在类定义时就初始化，而 引用类型 变量需要在定义时初始化阶段就引用其他变量实例，之后不能修改引用对象，因此 static和引用 二者不能同时满足
        2.只能使用 static MySQLConnectionPool* 类型，定义时初始化为 nullptr，构造函数中重新赋值
 */

class ExecMonitor {
    /*  func member */
public:
    ExecMonitor(
        ExecWhiteList* const pExecWhiteList,
        MySQLConnectionPool* pConnectionPool,
        const EVP_MD* pEVP_MD = EVP_sha256(),             /* 用所需的哈希函数替换 EVP_sha256，例如 EVP_sha1、EVP_sha512 等，ubuntu 默认sha1，可在grub修改启动参数进行更改 */
        const HgWorkModeOption workMode  = HgWorkModeOption::WORK_MODE_OPTION_WARNING,
        const std::string& database = "hostguard_db",
        const std::string& tableName = "exec_monitor"
    );
    ~ExecMonitor();

    // uapi
    int init();
    int runMainThread();
    int stopMainThread();

    /* whitelist operation*/
    int reloadWhiteList();

    /* workmode operation */
    HgWorkModeOption getWorkMode() const;
    int setWorkMode(const HgWorkModeOption& workMode);
    int synchronizeKernelWorkMode();
    int lookupKernelWorkMode(HgWorkModeOption& workMode);

private:
    // /* signal handler */
    // static void signalHandler(int sig);

    /* database connection */
    int initConnection();
    void releaseConnection();
    int initDatabase();

    /* database operations */
    int beginTransaction();
    int createDatabase();
    int deleteTable();
    int createTable();
    int deleteData();
    static int upsertData(const ExecRecord& execRecord);
    static int retrieveData();
    int endTransaction();

    /* database record thread */
    int runDataRecordThread();

    

    /* userspace ebpf ringbuf handle funcs */
    static int getEventBasicInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventBasicInfo);
    static int getEventArgsInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventArgsInfo);
    static int getEventFileDigestInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventFileDigestInfo);
    static bool getEventWhiteListEntryInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventWhiteListEntryInfo);

    static int getEventInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord);
    static std::vector<unsigned char> getFileDigest(const std::string& filePath);
    static int handleTaskEvent(const struct task_info* p_taskinfo);
    static int handleEvent(void* ctx, void* data, size_t data_sz);

    /* userspace ebpf program */
    int runKernelMonitorThread();
    void clean();

    /* userspace ebpf map operation */
    int clearKernelWhiteList(bpf_map* whiteListMapToClear);
    int updateKernelWhiteList(bpf_map* whiteListMapToUpdate);
    int switchKernelWhiteList(unsigned long long whiteListMapIdToUse);
    int synchronizeKernelWhiteList();
    int lookupKernelWhiteList();

    /* thread operation */
    int startSubThreads();
    int stopSubThreads();
    int joinSubThreads();


/* static data member */
private:
    /* mutex */
    static std::mutex recordRequestQueueMutex_;
    static std::mutex recordResponseQueueMutex_;

    /* semaphore */
    static std::counting_semaphore<0> recordRequestSemaphore_;      /* 初始值为0, C++20 */
    static std::counting_semaphore<0> recordFinishSemaphore_;       /* 初始值为0, C++20 */

    /* queues */
    static std::queue<ExecMonitorRecordRequest> recordRequestQueue_;
    static std::queue<ExecMonitorRecordResponse> recordResponseQueue_;

    /* signal handler */
    static volatile bool& exitingFlag_;

    /* sub thread running flag */
    static volatile bool subThreadRunningFlag_[static_cast<int>(ExecMonitorSubThreadId::SUB_THREAD_MAX)];

    /* database connection */
    static MySQLConnectionPool* pConnectionPool_;
    static std::string database_;
    static std::string tableName_;
    static std::shared_ptr<sql::Connection> connection_;

    /* whitelist */
    static const EVP_MD* pEVP_MD_;    /* sha1 / sha256 / sha512 */
    static ExecWhiteList* pWhiteList_;
    static FileDigestCalculator fileDigestCalculator_;

    /* monitor sub threads */
    std::map<ExecMonitorSubThreadId, std::thread> subThreadsMap_ = {};

/* non static data member */
private:
    /* ebpf monitor pointers */
    struct ring_buffer* rb_ = nullptr;
    struct exec_monitor_bpf* skel_ = nullptr;
    std::atomic<unsigned long long> kernelWhiteListIdInUse_ = 0;

    /* work mode */
    HgWorkModeOption workMode_  = HgWorkModeOption::WORK_MODE_OPTION_WARNING;
};

#endif /* __EXEC_MONITOR_H */