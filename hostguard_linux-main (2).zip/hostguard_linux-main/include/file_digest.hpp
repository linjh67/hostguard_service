/*** 
 * @Author: JiaHao
 * @Date: 2023-12-11 10:25:43
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-21 15:15:19
 * @FilePath: /hostguard_linux/include/file_digest.hpp
 * @Description: 
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved. 
 */



// clang++ hash_calc.cpp -std=c++17 -lssl -lcrypto 
#ifndef __FILE_DIGEST_HPP
#define __FILE_DIGEST_HPP

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <stdexcept>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <stdexcept>


class FileDigestCalculator {
public:
    FileDigestCalculator(const EVP_MD* md) 
    : md_(md) 
    {
        /* constructor */
    }

    ~FileDigestCalculator() {
        /* destructor */
    }

    void setDigestAlgorithm(const EVP_MD* md) {
        md_ = md;
    }

    std::vector<unsigned char> calculateFileDigest(const std::string& filepath);

private:
    // EVP_MD_CTX* mdContext_;
    const EVP_MD* md_;
};

///////////////////////////////////////////
inline std::vector<unsigned char> FileDigestCalculator::calculateFileDigest(const std::string& filepath) {

    EVP_MD_CTX* mdContext_(EVP_MD_CTX_new());

    if (!mdContext_) {
        throw std::runtime_error("Failed to create EVP_MD_CTX!");
    }

    if (!EVP_DigestInit_ex(mdContext_, md_, nullptr)) {
        throw std::runtime_error("EVP_DigestInit_ex failed!");
    }

    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Error opening file: " + filepath);
    }

    char buffer[4096];
    while (true) {
        file.read(buffer, sizeof(buffer));
        std::streamsize bytesRead = file.gcount();
        if (bytesRead > 0) {
            if (!EVP_DigestUpdate(mdContext_, buffer, bytesRead)) {
                throw std::runtime_error("EVP_DigestUpdate failed!");
            }
        }
        if (bytesRead < sizeof(buffer)) {
            break;  // End of file reached
        }
    }

    /* 获取最终的digest */
    std::vector<unsigned char> digest(EVP_MD_size(md_));
    unsigned int digestLength;
    if (!EVP_DigestFinal_ex(mdContext_, digest.data(), &digestLength)) {
        throw std::runtime_error("EVP_DigestFinal_ex failed!");
    }

    EVP_MD_CTX_free(mdContext_);

    /* 无需手动关闭file，由std::ifstream的析构函数自动释放(RAII机制) */
    return digest;
}




///////////////////////////////////////////////////////////////////////////////////////////////
// 将哈希值格式化为十六进制字符串
inline std::string toHexString(const std::vector<unsigned char>& hash) {
    std::stringstream ss;
    for (const auto& byte : hash) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
    }
    return ss.str();
}

inline std::vector<unsigned char> fromHexString(const std::string& hexString) {
    std::vector<unsigned char> result;
    
    // 如果字符串长度不是偶数，则返回空向量
    if(hexString.size() % 2 != 0)
        return result;
    
    // 将字符串中的每两个字符转换为对应的十六进制值
    for (int i = 0; i < hexString.size(); i += 2) {
        unsigned int byte;
        std::istringstream(hexString.substr(i, 2)) >> std::hex >> byte;
        result.push_back(static_cast<unsigned char>(byte));
    }
    
    return result;
}



#endif /* __FILE_DIGEST_HPP */


// Usage:

// int main(int argc, char* argv[]) {

//     if (3 != argc) {
//         std::cerr << "Usage: ./a.out filepath1 filepath2" << std::endl;
//         std::cerr << argv << std::endl;
//         return -1;
//     }

//     try {
//         // 用所需的哈希函数替换 EVP_sha256，例如 EVP_sha1、EVP_sha512 等
//         FileHashCalculator hashCalculator(EVP_sha256());

//         std::vector<unsigned char> hash = hashCalculator.calculateFileHash(argv[1]);
//         std::cout << toHexString(hash) << std::endl;
//         std::vector<unsigned char> hash2 = hashCalculator.calculateFileHash(argv[2]);
//         std::cout << toHexString(hash2) << std::endl;

//     } catch (const std::exception& e) {
//         std::cerr << "异常：" << e.what() << std::endl;
//         return 1;
//     }

//     return 0;
// }