/*** 
 * @Author: JiaHao
 * @Date: 2024-07-16 12:58:57
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-07-26 09:21:04
 * @FilePath: /hostguard_linux/include/unix_ipc/unix_server.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef UNIX_SERVER_H
#define UNIX_SERVER_H

#include <sys/socket.h>
#include <sys/un.h>
#include <signal.h>
#include <unistd.h>
#include <iostream>
#include <string>
#include <vector>
#include "logger.hpp"

#define BUFFER_SIZE 32*1024
#define UNIX_SOCKET_SERVER_PATH "unix_socket_server_hostguard"

class UnixSocketServer {
public:
    UnixSocketServer(
        const std::string& socketPath = UNIX_SOCKET_SERVER_PATH
    );

    ~UnixSocketServer();

public:
    int  init();
    int  acceptConnection();
    void clean();
    void cleanClientFd();
    void cleanServerFd();
    long receiveMessage(std::vector<char>& buffer, long bufferSize);
    long sendMessage(const std::string& message);


private:
    int createSocket();
    int bindAddress();
    int listenSocket();


private:
    /* signal handler */
    static volatile bool& exitingFlag_;

    std::string socketPath_;
    int serverFd_, clientFd_;
    struct sockaddr_un sockAddress_;
    
};

#endif // UNIX_SERVER_H

