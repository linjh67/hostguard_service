/*** 
 * @Author: JiaHao
 * @Date: 2024-07-14 14:24:19
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-15 14:36:55
 * @FilePath: /hostguard_linux/include/utils.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#ifndef _UTILS_H_
#define _UTILS_H_

#include <chrono>
#include <string>
#include <sstream>
#include <cerrno>
#include <cstring>
#include <sys/stat.h>



/* timestamp */
/* get time point now (us) */
inline std::chrono::_V2::system_clock::time_point getTimePoint() {
    return std::chrono::high_resolution_clock::now();
}

/* get time gone from start */
inline std::chrono::microseconds getDuration_us(const std::chrono::_V2::system_clock::time_point& start) {
    auto now = std::chrono::high_resolution_clock::now();
    std::chrono::microseconds duration = std::chrono::duration_cast<std::chrono::microseconds>(now - start);
    return duration;
}


inline std::string capturePerrorOutput() {
    // 创建一个字符串流来捕获错误信息
    std::ostringstream oss;

    // 获取上一个错误的描述
    oss << std::strerror(errno); // strerror(errno) 获取错误描述

    // 返回错误信息
    return oss.str();
}


#endif
