/*** 
 * @Author: JiaHao
 * @Date: 2023-12-13 11:16:43
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-22 16:07:17
 * @FilePath: /hostguard_linux/include/whitelist/exec_whitelist.h
 * @Description: 
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved. 
 */

#ifndef __EXEC_WHITELIST_H
#define __EXEC_WHITELIST_H

// clang++ whitelist_4.cpp -std=c++17 -lspdlog -lfmt -lssl -lcrypto -lmysqlcppconn -fsanitize=address -fno-omit-frame-pointer -fno-optimize-sibling-calls -O1
#include <dirent.h>
#include <fcntl.h>
// #include <mysql_connection.h>
// #include <mysql_driver.h>
// #include <openssl/evp.h>
// #include <openssl/sha.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stack>
#include <stdexcept>
#include <unordered_map>
#include <vector>
#include <queue>
#include <semaphore>
#include "file_digest.hpp"
#include "database/mysql_conn_pool.h"
#include "whitelist/exec_whitelist_basic.h"

enum class ExecWhiteListSubThreadId {
    SUB_THREAD_RECORD = 0,
    SUB_THREAD_SCAN,
    SUB_THREAD_MAX
};

/* 
    WhiteList record: 
    request & response 
*/

/* Exec WhiteList Record Resquest */
class ExecWhiteListRecordRequest
{
public:
    unsigned long long id_  = 0;
    ExecRuntimeFilePathEntry filePathEntry_  = {};
};

/* Exec WhiteList Record Response */
class ExecWhiteListRecordResponse
{
public:
    unsigned long long id_  = 0;
    ExecRuntimeFilePathEntry filePathEntry_  = {};
    bool isSuccess_         = true;
};


/* 
    Scan Path: 
    request & response 
*/

/* Scan Path Resquest */
class ScanPathRequest
{
public:
    unsigned long long id_  = 0;
    std::string path_       = {};
};

/* Scan Path Response */
class ScanPathResponse
{
public:
    unsigned long long id_      = 0;
    std::string path_           = {};
    bool isSuccess_             = true;
    unsigned long long scannedFileCount_    = 0;
    unsigned long long candidateFileCount_  = 0;
    long long timeConsume_us    = 0;
};


/* 
    File Process
    request & response
 */

/* File Process Request */
class FileProcessRequest
{
public:
    unsigned long long id_  = 0;
    std::string filepath_   = {};
};

/* File Process Response */
class FileProcessResponse
{
public:
    unsigned long long id_  = 0;
    std::string filepath_   = {};
    bool isSuccess_         = true;
};


/////////////////////////////////////ExceptionPath//////////////////////////////////////


class ExceptionPathList {
public:
    ExceptionPathList(
        MySQLConnectionPool* pConnectionPool,
        const std::string& database = "hostguard_db",
        const std::string& tableName = "exec_exception_path"
    );
    ~ExceptionPathList();

    // uapi
    int init();
    int reloadExceptionPathList();              /* database -> mem */
    std::map<std::string, bool> upsertEntryListInDB(const std::vector<ExceptionPathEntry>& pathList);
    std::map<unsigned long long, bool> deleteEntryListInDB(const std::vector<unsigned long long>& idList);
    std::stringstream printExceptionPathList();

private:
    // database operations
    int initConnection();
    void releaseConnection();
    int initDatabase();
    int createDatabase();
    int deleteTable();
    int createTable();
    int deleteData();
    int retrieveData(int pageSize = 10, int pageId = 0);

public:
    /* exceptionPathList mutex */
    std::mutex exceptionPathListMutex_ = {};
    /* exception path list */
    std::vector<ExceptionPathEntry> exceptionPathList_ = {};

private:
    /* signal handler */
    static volatile bool& exitingFlag_;

    /* database connection */
    const std::string database_;
    const std::string tableName_;
    MySQLConnectionPool* pConnectionPool_;
    std::shared_ptr<sql::Connection> connection_ = nullptr;
};


/////////////////////////////////////ExecWhiteList//////////////////////////////////////
/* 
    Main class:
    ExecWhiteList
 */

class ExecWhiteList {

/*  func member */
public:
    ExecWhiteList(
        MySQLConnectionPool* pConnectionPool,
        const EVP_MD* pEVP_MD = EVP_sha256(),                  /* 用所需的哈希函数替换 EVP_sha256，例如 EVP_sha1、EVP_sha512 等，ubuntu 默认sha1，可在grub修改启动参数进行更改 */
        const std::string& database = "hostguard_db",
        const std::string& tableName = "exec_whitelist"    
    );
    ~ExecWhiteList();

    // uapi
    int init();
    int runMainThread();
    int stopMainThread();
    std::stringstream printWhiteListRuntimeMap();
    std::stringstream printFormalListMap();
    int upsertFilePathEntryInRuntimeMap(std::unordered_map<std::string, ExecWhiteListEntry>& whiteListRuntimeMap, const ExecRuntimeFilePathEntry& filePathEntry);
    int deleteFilePathEntryInRuntimeMap(std::unordered_map<std::string, ExecWhiteListEntry>& whiteListRuntimeMap, const std::string& fileDigest, const std::string& filePath);
    std::map<unsigned long long, bool> deleteEntryListInDB(const std::vector<unsigned long long>& idList);
    int deleteNonCandidateEntryInDB();
    int setCandidateFlagFalseInDB();
    int setFormalFlagTrueInDB();
    // int getLastIdInDB();
    // int deleteEntryUnderLastIdInDB();
    int stopScan();

public:
    /* database operations */
    int initConnection();
    void releaseConnection();
    int initDatabase();
    int beginTransaction();
    int createDatabase();
    int deleteTable();
    int createTable();
    int deleteData();
    int upsertData(const ExecRuntimeFilePathEntry& filePathEntry);
    int retrieveData(int pageSize = 5, int pageId = 0);
    int rollbackTransaction();
    int endTransaction();

    /* mem whitelist */
    int reloadWhiteListRuntimeMap();

private:
    /* start & end threads */
    int startSubThreads();
    int stopSubThreads();
    int joinSubThreads();

    /* subthreads */
    int runDataRecordThread();
    int runFileScanThread();    
    int runFileProcessThread(int id);
    // int runServerThread();

    /* print */
    std::stringstream printRecordRequestQueue();
    
    /* file digest */
    std::string getCanonicalPath(const std::string& path);
    bool scanDirectory(const std::string& path);
    bool isForbiddenPath(const std::string& path);
    bool isExceptionPath(const std::string& path);
    int readDirFiles(std::stack<std::string>& scanDirStack);
    bool isRegularFile(const std::string& filepath);
    bool isEmptyFile(const std::string& filepath);
    bool isExecutableMode(const std::string& filepath);
    bool isELF(const std::string& filepath);
    int processFile(const std::string& filepath);
    std::vector<unsigned char> getFileDigest(const std::string& filePath);

    /* time consume */
    void resetStartTimeAndCount();
    void resetCount();
    void resetStartTime();
    void checkMilestone();

    /* mem whitelist */
    int reloadFormalListMap();

    /* mem exception path list */
    int initExceptionPathList();
    int reloadExceptionPathList();

/* data member */
public:
    /* signal handler */
    static volatile bool& exitingFlag_;

    /* exceptionPathList */
    ExceptionPathList scanExceptionPathList_;
    std::vector<std::string> forbiddenPathList_;

    /* 
        FormalList & Mutex
     */
    /* Mutex */
    std::mutex formalListMapMutex_ = {};
    /* Map: serialId -> FilePathEntry, read directly from database */
    std::unordered_map<unsigned long long, ExecRuntimeFilePathEntry> formalListMap_ = {};
    // /* lastIdInDB */
    // std::atomic<unsigned long long> lastIdInDB_ = 0;


    /* 
        whiteListRunTimeMaps & Mutex
     */
    /* Mutex */
    std::mutex whiteListRuntimeMapMutex_ = {};

    /* Map: digest -> whiteListEntry, init from entries in formalListMap_ */
    const int runtimeMapSwitchWaitTimeMS_ = 300;    // ms
    std::unordered_map<std::string, ExecWhiteListEntry> whiteListRuntimeMapA_ = {};          // In use usually in most time, IMA hash --> FilePathList (multiple filepaths)
    std::unordered_map<std::string, ExecWhiteListEntry> whiteListRuntimeMapB_ = {};          // Only in use when updating whiteListRuntimeMapA_
    std::atomic<std::unordered_map<std::string, ExecWhiteListEntry>*> pWhiteListRuntimeMap_ = {&whiteListRuntimeMapA_};    // Point to whiteListRuntimeMapA_ or whiteListRuntimeMapB_


    /* 
        sub thread mutex
     */

    /* scan stop flag */
    std::atomic<bool> scanRunningFlag_     = false;
    std::atomic<bool> scanNeedToStopFlag_  = false;

    /* mutex */
    std::mutex scanMutex_ = {};
    std::mutex scanRequestQueueMutex_ = {};
    std::mutex scanResponseQueueMutex_ = {};
    std::mutex fileProcessRequestQueueMutex_ = {};
    std::mutex fileProcessResponseQueueMutex_ = {};
    std::mutex recordRequestQueueMutex_ = {};
    std::mutex recordResponseQueueMutex_ = {};

    /* semaphores */
    std::counting_semaphore<0> scanRequestSemaphore_{0};        /* 初始值为0, C++20 */
    std::counting_semaphore<0> scanFinishSemaphore_{0};         /* 初始值为0, C++20 */
    std::counting_semaphore<0> fileProcessRequestSemaphore_{0}; /* 初始值为0, C++20 */
    std::counting_semaphore<0> fileProcessFinishSemaphore_{0};  /* 初始值为0, C++20 */
    std::counting_semaphore<0> recordRequestSemaphore_{0};      /* 初始值为0, C++20 */
    std::counting_semaphore<0> recordFinishSemaphore_{0};       /* 初始值为0, C++20 */
    
    /* queues */    
    std::queue<ScanPathRequest>             scanPathRequestQueue_   = {};
    std::queue<ScanPathResponse>            scanPathResponseQueue_  = {};
    std::queue<FileProcessRequest>          fileProcessRequestQueue_    = {};
    std::queue<FileProcessResponse>         fileProcessResponseQueue_   = {};
    std::queue<ExecWhiteListRecordRequest>  recordRequestQueue_     = {};
    std::queue<ExecWhiteListRecordResponse> recordResponseQueue_    = {};


private:
    /* database connection */
    const std::string database_;
    const std::string tableName_;
    MySQLConnectionPool* pConnectionPool_;
    std::shared_ptr<sql::Connection> connection_ = nullptr;

    /* file digest calc */
    FileDigestCalculator fileDigestCalculator_;

    /* whitelist sub threads */
    std::map<ExecWhiteListSubThreadId, std::thread> subThreadsMap_ = {};

    /* scan mile stone */
    std::atomic<unsigned long long> scannedFileCount_           = 0;
    std::atomic<unsigned long long> candidateFileCount_         = 0;
    std::atomic<unsigned long long> fileProcessRequestCount_    = 0;
    std::atomic<unsigned long long> fileRecordRequestCount_     = 0;
    const unsigned long long scanStepLen_                       = 1000;
    std::chrono::_V2::system_clock::time_point start_;
    
    /* file process threads */
    unsigned int fileProcessThreadNum_ = std::max(std::thread::hardware_concurrency(), (unsigned int)8);      /* logic cpu num */
    std::vector<std::thread> fileProcessThreads_ = {};
    
};

#endif /* __EXEC_WHITELIST_H */

