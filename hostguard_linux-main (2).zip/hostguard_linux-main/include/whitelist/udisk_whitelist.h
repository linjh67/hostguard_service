/*** 
 * @Author: JiaHao
 * @Date: 2024-05-15 10:00:57
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-19 10:34:22
 * @FilePath: /hostguard_linux/include/whitelist/udisk_whitelist.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#ifndef __UDISK_WHITELIST_H
#define __UDISK_WHITELIST_H

#include <atomic>
#include <chrono>
#include <queue>
#include <semaphore>
#include "database/mysql_conn_pool.h"
// #include "monitor/udisk_monitor_basic.h"
// #include "basic_user_space.h"
#include "whitelist/udisk_whitelist_basic.h"



struct UdiskMountPoint
{
    std::string pathStr = "";
    std::string mountType = "";
    unsigned long long mountFlags = 0;
};

struct UdiskMountArgs
{
    std::string devName = "";
    UdiskMountPoint mountPoint = {};
};



/* Udisk runtime devNodes Entry */
class UdiskRuntimeDevNodeEntry
{
public:
    UdiskRuntimeDevNodeEntry(
        const std::string& devNode = "",
        const std::map<std::string, UdiskMountPoint>& mountPoints = {},    /* < pathStr, UdiskMountPoint> */
        bool isPluggedIn = false,
        int mountRefCnt = 0,
        const std::string& pluggedInTime = ""
    );
    ~UdiskRuntimeDevNodeEntry();

    std::stringstream print() const;

public:
    std::string devNode_;
    std::map<std::string, UdiskMountPoint> mountPoints_;
    bool isPluggedIn_;
    int  mountRefCnt_;
    std::string pluggedInTime_;
};


/* Udisk WhiteList Entry */
class UdiskWhiteListEntry {
public:
    UdiskWhiteListEntry(
        const UdiskDevice& device = {},
        const std::map<std::string, UdiskRuntimeDevNodeEntry>& runtimeDevNodes = {},
        const mount_mode& mountMode = DEFAULT_MOUNT_MODE,
        int id = 0,
        const std::string& time = ""
    );
    ~UdiskWhiteListEntry();

    std::stringstream print() const;

public:
    UdiskDevice device_;
    std::map<std::string, UdiskRuntimeDevNodeEntry> runtimeDevNodes_;
    mount_mode mountMode_;
    int id_;
    std::string time_;
};


class UdiskWhiteList {

/*  func member */
public:
    UdiskWhiteList(
        MySQLConnectionPool* pConnectionPool,
        const std::string& database = "hostguard_db",
        const std::string& tableName = "udisk_whitelist"
    );
    ~UdiskWhiteList();

    // uapi
    int init();
    int reloadWhiteListRuntimeMap();
    std::stringstream printWhiteListRuntimeMap();
    int upsertDevNodeEntryInRuntimeMap(const UdiskDevice& device, const UdiskRuntimeDevNodeEntry& runtimeDevNodeEntry);
    int deleteDevNodeEntryInRuntimeMap(const std::string& udiskKey, const std::string& devNode);

public:
    /* database operations */
    int initConnection();
    void releaseConnection();
    int initDatabase();
    int beginTransaction();
    int createDatabase();
    int deleteTable();
    int createTable();
    int deleteData();
    int upsertData(const UdiskWhiteListEntry& whiteListEntry);
    int retrieveData();
    int endTransaction();


/* data member */
public:
    /* mutex */
    std::mutex whiteListRuntimeMapMutex_ = {};

    /* whiteListRuntimeMap */
    const int runtimeMapSwitchWaitTimeMS_ = 300;    // ms
    std::map<std::string, UdiskWhiteListEntry> whiteListRuntimeMapA_ = {};          // In use usually in most time, udiskKey --> UdiskWhiteListEntry
    std::map<std::string, UdiskWhiteListEntry> whiteListRuntimeMapB_ = {};          // Only in use when updating whiteListRuntimeMapA_
    std::atomic<std::map<std::string, UdiskWhiteListEntry>*> pWhiteListRuntimeMap_ = {&whiteListRuntimeMapA_};    // Point to whiteListRuntimeMapA_ or whiteListRuntimeMapB_

private:
    /* signal handler */
    static volatile bool& exitingFlag_;

    /* database */
    const std::string database_;
    const std::string tableName_;
    MySQLConnectionPool* pConnectionPool_;
    std::shared_ptr<sql::Connection> connection_ = nullptr; 
};

#endif  /* __UDISK_WHITELIST_H */