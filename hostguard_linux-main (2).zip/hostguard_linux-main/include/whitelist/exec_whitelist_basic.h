/*** 
 * @Author: JiaHao
 * @Date: 2024-07-29 15:06:46
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-15 10:52:09
 * @FilePath: /hostguard_linux/include/whitelist/exec_whitelist_basic.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef __EXEC_WHITELIST_BASIC_H
#define __EXEC_WHITELIST_BASIC_H

#include <string>
#include "basic_user_space.h"
#include "monitor/exec_monitor_basic.h"


inline std::vector<std::string> execReactionStrList = {
    "DENY",
    "ALLOW",
    "WARNING",
    "OTHER_REACT",
    "REACT_MAX"
};


/* ExceptionPathEntry */
class ExceptionPathEntry {
public:
    std::string path_       = "";
    unsigned long long id_  = 0;
    std::string time_       = "";
public:
    void fromJson(const json& j);
    json toJson() const;
    std::stringstream print() const;
};

/* Exec runtime filepath Entry */
class ExecRuntimeFilePathEntry
{
public:
    std::string filepath_       = "";
    bool isELF_                 = false;
    bool isXmode_               = false;
    std::string fileDigest_     = "";
    exec_reaction reaction_     = exec_reaction::ALLOW_EXEC;    
    bool isCandidate_           = false;
    bool isFormal_              = false;
    unsigned long long id_      = 0;
    std::string time_           = "";
public:
    void fromJson(const json& j);
    json toJson() const;
    std::stringstream print() const;
};


class ExecWhiteListEntry {
public:    
    std::string fileDigest_ = "";
    std::map<std::string, ExecRuntimeFilePathEntry> filePaths_ = {};
    exec_reaction reaction_  = exec_reaction::ALLOW_EXEC;
public:
    void fromJson(const json& j);
    json toJson() const;
    std::stringstream print() const;
};


////////////////// ExceptionPathEntry ///////////////////////
inline void ExceptionPathEntry::fromJson(const json& j) {
    try {
        if (j.contains("path"))     { path_     = j.at("path").get<std::string>(); }
        else { throw std::invalid_argument("path is required!");}

        if (j.contains("id"))       { id_       = j.at("id").get<unsigned long long>(); }
        // else { throw std::invalid_argument("id is required!");}

        if (j.contains("time"))     { time_     = j.at("time").get<std::string>(); }
        // else { throw std::invalid_argument("time is required!");}

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error ExceptionPathEntry fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

inline json ExceptionPathEntry::toJson() const {
    json j;
    j["path"]   = path_;
    j["id"]     = id_;
    j["time"]   = time_;
    return j;
}

inline std::stringstream ExceptionPathEntry::print() const {
    std::stringstream ss;
    ss  << "    "
        << "[ExceptionPath: "   << std::left    << std::setw(9) << path_ << "], "
        << "[id: "              << id_          << "], "
        << "[Time: "            << time_        << "]";

    return ss;
}


////////////////// ExecRuntimeFilePathEntry ///////////////////////
inline void ExecRuntimeFilePathEntry::fromJson(const json& j) {
    try {
        if (j.contains("filepath"))     { filepath_     = j.at("filepath").get<std::string>(); }
        else { throw std::invalid_argument("filepath is required!");}

        if (j.contains("isELF"))        { isELF_        = j.at("isELF").get<bool>(); }
        else { throw std::invalid_argument("isELF is required!");}

        if (j.contains("isXmode"))      { isXmode_      = j.at("isXmode").get<bool>(); }
        else { throw std::invalid_argument("isXmode is required!");}

        if (j.contains("reaction"))     { reaction_     = j.at("reaction").get<exec_reaction>(); }
        else { throw std::invalid_argument("reaction is required!");}

        if (j.contains("fileDigest"))   { fileDigest_   = j.at("fileDigest").get<std::string>(); }
        else { throw std::invalid_argument("fileDigest is required!");}

        if (j.contains("isCandidate"))  { isCandidate_  = j.at("isCandidate").get<bool>(); }
        else { throw std::invalid_argument("isCandidate is required!");}

        if (j.contains("isFormal"))     { isFormal_     = j.at("isFormal").get<bool>(); }
        else { throw std::invalid_argument("isFormal is required!");}

        if (j.contains("id"))           { id_           = j.at("id").get<unsigned long long>(); }
        else { throw std::invalid_argument("id is required!");}

        if (j.contains("time"))         { time_         = j.at("time").get<std::string>(); }
        // else { throw std::invalid_argument("time is required!");}

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error ExecRuntimeFilePathEntry fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

inline json ExecRuntimeFilePathEntry::toJson() const {
    json j;
    j["filepath"]       = filepath_;
    j["isELF"]          = isELF_;
    j["isXmode"]        = isXmode_;
    j["reaction"]       = reaction_;
    j["fileDigest"]     = fileDigest_;
    j["isCandidate"]    = isCandidate_;
    j["isFormal"]       = isFormal_;
    j["id"]             = id_;
    j["time"]           = time_;
    return j;
}

inline std::stringstream ExecRuntimeFilePathEntry::print() const {
    int i = 0;
    std::stringstream ss;
    ss  << "    "
        << "[FilePath: "    << std::left    << std::setw(9) << filepath_ << "], "
        << "[isELF: "       << isELF_       << "], "
        << "[isXmode: "     << isXmode_     << "], ";
    
    if (reaction_ >= exec_reaction::DENY_EXEC && reaction_ < exec_reaction::REACT_EXEC_MAX) {
        ss << "[Reaction: " << execReactionStrList[static_cast<int>(reaction_)] << "], ";
    } else {
        ss << "[Reaction: Unknown (" << static_cast<int>(reaction_) << ") ], ";
    }
    
    ss  << "[FileDigest: "  << fileDigest_  << "], "
        << "[isCandidate: " << isCandidate_ << "], "
        << "[isFormal: "    << isFormal_    << "], "
        << "[id: "          << id_          << "], "
        << "[Time: "        << time_        << "]";

    // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecRuntimeFilePathEntry] \n{}", ss.str().c_str());
    return ss;
}


////////////////// ExecWhiteListEntry ///////////////////////
/* 
    ExecWhiteListEntry
 */
inline void ExecWhiteListEntry::fromJson(const json& j) {
    try {
        if (j.contains("fileDigest"))   { fileDigest_   = j.at("fileDigest").get<std::string>(); }
        else { throw std::invalid_argument("fileDigest is required!");}

        if (j.contains("reaction"))     { reaction_     = j.at("reaction").get<exec_reaction>(); }
        else { throw std::invalid_argument("reaction is required!");}

        if (j.contains("filePaths")) {
            for (const auto& filePath : j["filePaths"]) {
                ExecRuntimeFilePathEntry filePathEntry;
                filePathEntry.fromJson(filePath);
                filePaths_.emplace(filePathEntry.filepath_, filePathEntry);
            }
        } else {
            throw std::invalid_argument("filePaths is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error ExecWhiteListEntry fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

inline json ExecWhiteListEntry::toJson() const {
    json j;
    j["fileDigest"]     = fileDigest_;
    j["reaction"]       = reaction_;
    json filePathsJson;
    for (const auto& pair : filePaths_) {
        filePathsJson.emplace_back(pair.second.toJson());
    }
    j["filePaths"]      = filePathsJson;
    return j;
}

inline std::stringstream ExecWhiteListEntry::print() const {
    std::stringstream ss;
    ss  << "    " << "[FileDigest: "  << fileDigest_                    << "], ";

    if (reaction_ >= exec_reaction::DENY_EXEC && reaction_ < exec_reaction::REACT_EXEC_MAX) {
        ss << "[Reaction: " << execReactionStrList[static_cast<int>(reaction_)] << "]"  << std::endl;
    } else {
        ss << "[Reaction: Unknown (" << static_cast<int>(reaction_) << ") ]"            << std::endl;
    }
    
    for (const auto& pair : filePaths_) {
        ss << "        " << pair.second.print().str() << std::endl;
    }
    // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteListEntry] \n{}", ss.str().c_str());
    return ss;
}

#endif