/*** 
 * @Author: JiaHao
 * @Date: 2024-08-15 09:41:16
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-16 14:16:03
 * @FilePath: /hostguard_linux/include/whitelist/udisk_whitelist_basic.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef __UDISK_WHITELIST_BASIC_H
#define __UDISK_WHITELIST_BASIC_H

#include <string>
#include "basic_user_space.h"
#include "monitor/udisk_monitor_basic.h"


inline std::vector<std::string> udiskMountModeStrList = {
    "MOUNT_MODE_DEF",
	"MOUNT_MODE_READ_ONLY",
	"MOUNT_MODE_READ_WRITE",
	"MOUNT_MODE_OTHER",
	"MOUNT_MODE_MAX"
};

inline std::vector<std::string> udiskMountReactStrList = {
    "DENY_MOUNT", 
    "ALLOW_MOUNT", 
    "WARNING_MOUNT", 
    "ALLOW_UMOUNT", 
    "WARNING_UMOUNT"
};


class UdiskDevice
{
public:
    std::string udiskKey_   = "";
    std::string vendorId_   = "";
    std::string productId_  = "";
    std::string serialId_   = "";
    std::string usbDriver_  = "";
    mount_mode mountMode_   = mount_mode::DEFAULT_MOUNT_MODE;

public:
    void fromJson(const json& j);
    json toJson() const;
    std::stringstream print() const;
};



/* 
    UdiskDevice
 */
inline void UdiskDevice::fromJson(const json& j) {
    try {
        if (j.contains("udiskKey"))     { udiskKey_     = j.at("udiskKey").get<std::string>(); }
        else { throw std::invalid_argument("udiskKey is required!");}

        if (j.contains("vendorId"))     { vendorId_     = j.at("vendorId").get<std::string>(); }
        else { throw std::invalid_argument("vendorId is required!");}
        
        if (j.contains("productId"))    { productId_    = j.at("productId").get<std::string>(); }
        else { throw std::invalid_argument("productId is required!");}

        if (j.contains("serialId"))     { serialId_     = j.at("serialId").get<std::string>(); }
        else { throw std::invalid_argument("serialId is required!");}

        if (j.contains("usbDriver"))    { usbDriver_    = j.at("usbDriver").get<std::string>(); }
        // else { throw std::invalid_argument("usbDriver is required!");}

        if (j.contains("mountMode"))    { mountMode_    = j.at("mountMode").get<mount_mode>(); }
        else { throw std::invalid_argument("mountMode is required!");}

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error UdiskDevice fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

inline json UdiskDevice::toJson() const {
    json j;
    j["udiskKey"]       = udiskKey_;
    j["vendorId"]       = vendorId_;
    j["productId"]      = productId_;
    j["serialId"]       = serialId_;
    j["usbDriver"]      = usbDriver_;
    j["mountMode"]      = mountMode_;
    return j;
}

inline std::stringstream UdiskDevice::print() const {
    std::stringstream ss;
    ss  << std::left
        << std::setw(30) << "        [Udisk UdiskKey: "     << udiskKey_    << " ]" << std::endl
        << std::setw(30) << "        [Udisk VendorId: "     << vendorId_    << " ]" << std::endl
        << std::setw(30) << "        [Udisk ProductId: "    << productId_   << " ]" << std::endl
        << std::setw(30) << "        [Udisk SerialId: "     << serialId_    << " ]" << std::endl
        << std::setw(30) << "        [Udisk UsbDriver: "    << usbDriver_   << " ]" << std::endl;

    if (mountMode_ >= mount_mode::DEFAULT_MOUNT_MODE && mountMode_ < mount_mode::MOUNT_MODE_MAX) {
        ss  << std::setw(30) << "        [Udisk MountMode: "    << udiskMountModeStrList[(int)mountMode_]   << " (" << (int)mountMode_<< ") ]" << std::endl;
    } else {
        ss  << std::setw(30) << "        [Udisk MountMode: "    << "Unknown MountMode"                      << " (" << (int)mountMode_<< ") ]" << std::endl;
    }
    
    return ss;
}


#endif // __UDISK_WHITELIST_BASIC_H
