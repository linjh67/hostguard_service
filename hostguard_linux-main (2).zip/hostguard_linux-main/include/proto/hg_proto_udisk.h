/*** 
 * @Author: JiaHao
 * @Date: 2024-08-15 09:46:34
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-21 16:34:50
 * @FilePath: /hostguard_linux/include/proto/hg_proto_udisk.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#ifndef _HG_PROTO_UDISK_H_
#define _HG_PROTO_UDISK_H_

#include "proto/hg_proto_base.h"
#include "whitelist/udisk_whitelist_basic.h"

/* Udisk WhiteList */
enum class HgUdiskSubCode {
    UDISK_SUBCODE_DEF = 0,
    UDISK_SUBCODE_WHITELIST_RELOAD,
    UDISK_SUBCODE_MAX
};

inline std::vector<std::string> HgUdiskSubCodeStr = {
    "UDISK_SUBCODE_DEF",
    "UDISK_SUBCODE_WHITELIST_RELOAD",
    "UDISK_SUBCODE_MAX"
};




/* Hg Udisk Packet */
class HgUdiskPacket : public HgPacket {
private:
    HgUdiskSubCode subCode_  = HgUdiskSubCode::UDISK_SUBCODE_DEF;

public:
    HgUdiskPacket(
        const HgUdiskSubCode& subCode    = HgUdiskSubCode::UDISK_SUBCODE_DEF
    );
    virtual ~HgUdiskPacket() = default;
    virtual void fromJson(const json& j);
    virtual json toJson() const;
    std::stringstream print() const;
    HgUdiskSubCode getSubCode() const;
};


/* 
    HgUdiskSimplePacket

    HgUdiskPacketWithKeyList

    HgUdiskPacketWithDevList
 
 */

/* Hg Udisk simple Packet */
class HgUdiskSimplePacket : public HgUdiskPacket {
public:
    HgUdiskSimplePacket(
        const HgUdiskSubCode& subCode    = HgUdiskSubCode::UDISK_SUBCODE_DEF
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};

/* Hg Udisk Packet with udiskKeyList */
class HgUdiskPacketWithKeyList : public HgUdiskPacket {
public:
    std::vector<std::string> udiskKeyList_  = {};

public:
    HgUdiskPacketWithKeyList(
        const HgUdiskSubCode& subCode                   = HgUdiskSubCode::UDISK_SUBCODE_DEF,
        const std::vector<std::string>& udiskKeyList    = {}
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};

/* Hg Udisk Packet with udiskDeviceList */
class HgUdiskPacketWithDevList : public HgUdiskPacket {
public:
    std::vector<UdiskDevice> udiskDeviceList_   = {};

public:
    HgUdiskPacketWithDevList(
        const HgUdiskSubCode& subCode                   = HgUdiskSubCode::UDISK_SUBCODE_DEF,
        const std::vector<UdiskDevice>& udiskDeviceList = {}
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};


#endif


