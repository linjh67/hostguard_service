/*** 
 * @Author: JiaHao
 * @Date: 2024-07-22 13:43:16
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-21 16:36:37
 * @FilePath: /hostguard_linux/include/proto/hg_proto_base.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef HG_PROTO_BASE_H
#define HG_PROTO_BASE_H

#include <iostream>
#include <string>
#include <vector>
#include <exception>
#include "json.hpp"


using json = nlohmann::json;

/* Type Request/Response  */
enum class HgType {
    HG_TYPE_REQUEST = 0,
    HG_TYPE_RESPONSE
};

inline std::vector<std::string> HgTypeStr = {
    "HG_TYPE_REQUEST",
    "HG_TYPE_RESPONSE"
};

/* Code */
enum class HgCode {
    HG_CODE_DEF = 0,
    HG_CODE_UDISK,
    HG_CODE_EXEC,
    HG_CODE_LOG_AUDIT,
    HG_CODE_MAX
};

inline std::vector<std::string> HgCodeStr = {
    "HG_CODE_DEF",
    "HG_CODE_UDISK",
    "HG_CODE_EXEC",
    "HG_CODE_LOG_AUDIT",
    "HG_CODE_MAX"
};


inline std::vector<std::string> HgWorkModeOptionStr = {
    "WORK_MODE_OPTION_DEF",
    "WORK_MODE_OPTION_SILENT",
    "WORK_MODE_OPTION_WARNING",
    "WORK_MODE_OPTION_BLOCK",
    "WORK_MODE_OPTION_MAX"
};

/* 
    response status
 */

enum class HgRspStatus {
    HG_RSP_STATUS_DEF = 0,
    HG_RSP_STATUS_SUCCESS,
    HG_RSP_STATUS_FAILED,
    HG_RSP_STATUS_MAX
};

inline std::vector<std::string> HgRspStatusStr = {
    "HG_RSP_STATUS_DEF",
    "HG_RSP_STATUS_SUCCESS",
    "HG_RSP_STATUS_FAILED",
    "HG_RSP_STATUS_MAX"
};



/* Hg Packet Base */
class HgPacket {
public:
    unsigned long long id_  = 0;
    HgType type_            = HgType::HG_TYPE_REQUEST;
    HgRspStatus status_     = HgRspStatus::HG_RSP_STATUS_DEF;
        
private:
    HgCode code_    = HgCode::HG_CODE_DEF;

public:
    HgPacket(
        const HgCode& code  = HgCode::HG_CODE_DEF
    );
    virtual ~HgPacket() = default;
    virtual void fromJson(const json& j);
    virtual json toJson() const;
    std::stringstream print() const;
    HgCode getCode() const;
    void setCode(const HgCode& code);
};

#endif

