/*** 
 * @Author: JiaHao
 * @Date: 2024-07-22 13:47:21
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-20 13:48:07
 * @FilePath: /hostguard_linux/include/proto/hg_proto_exec.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef _HG_PROTO_EXEC_H_
#define _HG_PROTO_EXEC_H_

#include "proto/hg_proto_base.h"
#include "whitelist/exec_whitelist_basic.h"

/* Exec WhiteList */
enum class HgExecSubCode {
    EXEC_SUBCODE_DEF = 0,

    /* WorkMode */
    EXEC_SUBCODE_WORKMODE_QUERY,
    EXEC_SUBCODE_WORKMODE_SET,

    /* Query WhiteList */
    EXEC_SUBCODE_WHITELIST_RELOAD,

    /* Scan Exception Path */
    EXEC_SUBCODE_EXCEPTION_PATH_RELOAD,

    /* Scan Operation */
    EXEC_SUBCODE_PATH_SCAN_START,
    EXEC_SUBCODE_PATH_SCAN_STOP,

    /* Query WhiteList Candidate after Scan */
    EXEC_SUBCODE_CANDIDATE_DELETE,
    EXEC_SUBCODE_CANDIDATE_OVERWRITE,
    EXEC_SUBCODE_CANDIDATE_APPEND,
    EXEC_SUBCODE_CANDIDATE_DROP,

    /* cnt */
    EXEC_SUBCODE_MAX
};

inline std::vector<std::string> HgExecSubCodeStr = {
    "EXEC_SUBCODE_DEF",

    /* WorkMode */
    "EXEC_SUBCODE_WORKMODE_QUERY",
    "EXEC_SUBCODE_WORKMODE_SET",

    /* Query WhiteList */
    "EXEC_SUBCODE_WHITELIST_RELOAD",

    /* Scan Exception Path */
    "EXEC_SUBCODE_EXCEPTION_PATH_RELOAD",

    /* Scan Operation */
    "EXEC_SUBCODE_PATH_SCAN_START",
    "EXEC_SUBCODE_PATH_SCAN_STOP",

    /* Query WhiteList Candidate after Scan */
    "EXEC_SUBCODE_CANDIDATE_DELETE",
    "EXEC_SUBCODE_CANDIDATE_OVERWRITE",
    "EXEC_SUBCODE_CANDIDATE_APPEND",
    "EXEC_SUBCODE_CANDIDATE_DROP",

    /* cnt */
    "EXEC_SUBCODE_MAX"
};


/* Hg Exec Packet */
class HgExecPacket : public HgPacket {
public:
    std::string description_ = "";
private:
    HgExecSubCode subCode_  = HgExecSubCode::EXEC_SUBCODE_DEF;

public:
    HgExecPacket(
        const HgExecSubCode& subCode    = HgExecSubCode::EXEC_SUBCODE_DEF
    );
    virtual ~HgExecPacket() = default;
    virtual void fromJson(const json& j);
    virtual json toJson() const;
    std::stringstream print() const;
    HgExecSubCode getSubCode() const;
};


/* 
    HgExecSimplePacket

    HgExecWhiteListQueryPacket
 */

/* HgExecSimplePacket */
class HgExecSimplePacket : public HgExecPacket {
public:
    HgExecSimplePacket(
        const HgExecSubCode& subCode    = HgExecSubCode::EXEC_SUBCODE_DEF
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};

/* HgExecDataQueryPacket */
class HgExecDataQueryPacket : public HgExecPacket {
public:
    DataQueryRange range_ = {};
public:
    HgExecDataQueryPacket(
        const HgExecSubCode& subCode    = HgExecSubCode::EXEC_SUBCODE_DEF,
        const DataQueryRange& range     = {}
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};

/* HgExecPacketWithWorkMode */
class HgExecPacketWithWorkMode : public HgExecPacket {
public:
    HgWorkModeOption workMode_  = HgWorkModeOption::WORK_MODE_OPTION_DEF;
public:
    HgExecPacketWithWorkMode(
        const HgExecSubCode& subCode    = HgExecSubCode::EXEC_SUBCODE_DEF,
        const HgWorkModeOption& workMode = HgWorkModeOption::WORK_MODE_OPTION_DEF
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};

/* HgExecPacketWithIdList */
class HgExecPacketWithIdList : public HgExecPacket {
public:
    std::vector<unsigned long long> idList_ = {};
public:
    HgExecPacketWithIdList(
        const HgExecSubCode& subCode    = HgExecSubCode::EXEC_SUBCODE_DEF,
        const std::vector<unsigned long long>& idList = {}
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};

/* HgExecPacketWithPathList */
class HgExecPacketWithPathList : public HgExecPacket {
public:
    std::vector<ExceptionPathEntry> pathList_  = {};
public:
    HgExecPacketWithPathList(
        const HgExecSubCode& subCode    = HgExecSubCode::EXEC_SUBCODE_DEF,
        const std::vector<ExceptionPathEntry>& pathList = {}
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};

/* HgExecPacketWithWhiteList */
class HgExecPacketWithWhiteList : public HgExecPacket {
public:
    DataQueryRange range_ = {};
    std::vector<ExecRuntimeFilePathEntry> whiteList_ = {};
public:
    HgExecPacketWithWhiteList(
        const HgExecSubCode& subCode    = HgExecSubCode::EXEC_SUBCODE_DEF,
        const DataQueryRange& range     = {},
        const std::vector<ExecRuntimeFilePathEntry>& whiteList = {}
    );
    void fromJson(const json& j) override;
    json toJson() const override;
    std::stringstream print() const;
};



#endif


