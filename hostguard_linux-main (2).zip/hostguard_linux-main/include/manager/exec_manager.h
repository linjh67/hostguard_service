/*** 
 * @Author: JiaHao
 * @Date: 2024-07-04 13:05:54
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-21 17:22:21
 * @FilePath: /hostguard_linux/include/manager/exec_manager.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */



#ifndef __EXEC_MANAGER_H
#define __EXEC_MANAGER_H

#include "monitor/exec_monitor.h"
#include "proto/hg_proto_exec.h"


/* 
    Service: 
    request & response 
*/

/* Service Resquest */
class ServiceRequest
{
public:
    unsigned long long id_  = 0;
    std::string command_    = {};
    std::string args_       = {};
};

/* Service Response */
class ServiceResponse
{
public:
    unsigned long long id_      = 0;
    bool isSuccess_             = true;
    std::string description_    = {};
};




/////////////////////////////////////ExecManager//////////////////////////////////////
class ExecManager {
/*  func member */
public:
    ExecManager(
        MySQLConnectionPool* pConnectionPool
    );
    ~ExecManager();

    // uapi
    int runMainThread();
    int stopMainThread();
    json processExecPacket(const json& packetJson);

private:
    // /* signal handler */
    // static void signalHandler(int sig);    

    /* start & end threads */
    int startSubThreads();
    int stopSubThreads();
    int joinSubThreads();

    
    /* 
        Actual process functions 
    */
    /* Exec */
    json processExecWorkModeQueryPacket(const json& packetJson);
    json processExecWorkModeSetPacket(const json& packetJson);
    json processExecWhiteListReloadPacket(const json& packetJson);
    json processExecExceptionPathReloadPacket(const json& packetJson);
    json processExecPathScanStartPacket(const json& packetJson);
    json processExecPathScanStopPacket(const json& packetJson);
    json processExecCandidateDeletePacket(const json& packetJson);
    json processExecCandidateOverWritePacket(const json& packetJson);
    json processExecCandidateAppendPacket(const json& packetJson);
    json processExecCandidateDropPacket(const json& packetJson);


    /* test */
    void testExecRequestProcess();



/* data member */
private:
    /* signal handler */
    static volatile bool& exitingFlag_;

    /* sub thread running flag */
    volatile bool subThreadRunningFlag_[static_cast<int>(ManagerSubThreadId::SUB_THREAD_MAX)] = {false};

    /* sub thread busy flag */
    volatile bool subThreadBusyFlag_[static_cast<int>(ManagerSubThreadId::SUB_THREAD_MAX)] = {false};

    /* mutex */
    std::mutex subThreadQueueMutex_[static_cast<int>(ManagerSubThreadId::SUB_THREAD_MAX)][static_cast<int>(ReqRspType::MAX)] = {};


    /* semaphores */
    std::counting_semaphore<0> recordRequestSemaphore_{0};      /* 初始值为0, C++20 */
    std::counting_semaphore<0> recordFinishSemaphore_{0};       /* 初始值为0, C++20 */
    std::counting_semaphore<0> serviceRequestSemaphore_{0};     /* 初始值为0, C++20 */
    std::counting_semaphore<0> serviceFinishSemaphore_{0};      /* 初始值为0, C++20 */

    /* queues */
    // std::queue<ExecWhiteListRecordRequest>  recordRequestQueue_     = {};
    // std::queue<ExecWhiteListRecordResponse> recordResponseQueue_    = {};
    std::queue<ServiceRequest>              serviceRequestQueue_    = {};
    std::queue<ServiceResponse>             serviceResponseQueue_   = {};


    /* database connection */
    const std::string database_;
    const std::string tableName_;
    MySQLConnectionPool* pConnectionPool_;
    std::shared_ptr<sql::Connection> connection_; 

    /* monitor main thread */
    std::map<ManagerSubThreadId, std::thread> subThreadsMap_ = {};

    /* whitelist */
    ExecWhiteList* pWhiteList_  = nullptr;

    /* monitor */
    ExecMonitor* pMonitor_      = nullptr;

};



#endif /* __EXEC_MANAGER_H */