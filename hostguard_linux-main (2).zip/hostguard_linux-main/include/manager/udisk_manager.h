/*** 
 * @Author: JiaHao
 * @Date: 2024-07-02 09:14:17
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-21 17:23:23
 * @FilePath: /hostguard_linux/include/manager/udisk_manager.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#ifndef __UDISK_MANAGER_H
#define __UDISK_MANAGER_H

#include "monitor/udisk_monitor.h"
#include "proto/hg_proto_udisk.h"

class UdiskManager {
/*  func member */
public:
    UdiskManager(
        MySQLConnectionPool* pConnectionPool
    );
    ~UdiskManager();

    // uapi
    int runMainThread();
    int stopMainThread();
    json processUdiskPacket(const json& packetJson);

private:
    // /* signal handler */
    // static void signalHandler(int sig);    

    /* start & end threads */
    int startSubThreads();
    int stopSubThreads();
    int joinSubThreads();


    /* 
        Actual parse functions 
    */

    /* Udisk */
    json processUdiskWhiteListReloadPacket(const json& packetJson);


    /* test */
    void testUdiskRequestProcess();


/* data member */
private:
    /* signal handler */
    static volatile bool& exitingFlag_;

    /* database connection */
    const std::string database_;
    const std::string tableName_;
    MySQLConnectionPool* pConnectionPool_;
    std::shared_ptr<sql::Connection> connection_; 

    /* monitor main thread */
    std::map<ManagerSubThreadId, std::thread> subThreadsMap_ = {};

    /* whitelist */
    UdiskWhiteList* pWhiteList_ = nullptr;

    /* monitor */
    UdiskMonitor* pMonitor_ = nullptr;

};



#endif /* __UDISK_MANAGER_H */