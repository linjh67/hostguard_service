/*** 
 * @Author: JiaHao
 * @Date: 2024-07-25 15:21:29
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-07-26 09:50:39
 * @FilePath: /hostguard_linux/include/manager/general_manager.h
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#ifndef _GENERAL_MANAGER_H_
#define _GENERAL_MANAGER_H_

#include <mutex>
#include <queue>
#include <semaphore>
#include <thread>
#include <vector>
#include "unix_ipc/unix_server.h"
#include "manager/udisk_manager.h"
#include "manager/exec_manager.h"

class GeneralManager {
public:
    GeneralManager(UdiskManager* pUdiskManager, ExecManager* pExecManager);
    ~GeneralManager() = default;

    int init();

    int runMainThread();
    int stopMainThread();

private: 
    /* process packet */ 
    json getJson(const std::string& jsonStr);
    json processHgPacket(const json& packetJson);
    int processPacket(std::string packet);
    
    /* start & end threads */
    int startSubThreads();
    int stopSubThreads();
    int joinSubThreads();
    
    /* subthreads */
    int runPacketProcessThread(int id);
    void runServerThread();

private:
    /* signal handler */
    static volatile bool& exitingFlag_;

    /* Unix Socket */
    UnixSocketServer    unixSocketServer_;

    /* Managers */
    UdiskManager*       pUdiskManager_      = nullptr;
    ExecManager*        pExecManager_       = nullptr;

    /* packet receive thread */
    std::thread serverThread_;
    
    /* packet process */
    /* mutex */
    std::mutex packetProcessRequestQueueMutex_ = {};
    /* semaphores */
    std::counting_semaphore<0> packetProcessRequestSemaphore_{0}; /* 初始值为0, C++20 */
    /* queues */
    std::queue<std::string> packetProcessRequestQueue_ = {};
    /* threads */
    unsigned int packetProcessThreadNum_ = std::max(std::thread::hardware_concurrency(), (unsigned int)8); /* logic cpu num */
    std::vector<std::thread> packetProcessThreads_ = {};
    
};


#endif