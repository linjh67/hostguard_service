/***
 * @Author: JiaHao
 * @Date: 2023-11-29 10:41:15
 * @LastEditors: JiaHao
 * @LastEditTime: 2023-11-29 10:50:01
 * @FilePath: /test_scanfile/mysql_conn_pool_4.hpp
 * @Description:
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved.
 */

// g++ xx.cpp -lmysqlcppconn


#ifndef __MYSQL_CONN_POOL_HPP
#define __MYSQL_CONN_POOL_HPP

#include <cppconn/exception.h>
#include <cppconn/prepared_statement.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <mysql_connection.h>
#include <mysql_driver.h>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <mutex>
#include <vector>
#include "logger.hpp"

// clang++ mysql_conn_pool_4.cpp -std=c++17 -lspdlog -lfmt -lmysqlcppconn -fsanitize=address -fno-omit-frame-pointer -fno-optimize-sibling-calls -O1

extern Spdlogger logger;

class MySQLConnectionPool {
   public:
    /* Construction */
    MySQLConnectionPool(
        const std::string& host = "tcp://127.0.0.1:3306",
        const std::string& user = "JiaHao",
        const std::string& password = "hostguard123",
        // const std::string& password = "HostGuard_123",
        const std::string& database = "hostguard_db",
        unsigned int port = 3306,
        unsigned int poolSize = 40);
    ~MySQLConnectionPool();

    // Connection
    const std::shared_ptr<sql::Connection> getConnection();
    void setIsolationLevel(const std::shared_ptr<sql::Connection>& connection, const sql::enum_transaction_isolation& level);
    void releaseConnection(std::shared_ptr<sql::Connection> connection);

    // Transaction
    void beginTransaction(const std::shared_ptr<sql::Connection>& connection);
    void rollbackTransaction(const std::shared_ptr<sql::Connection>& connection);
    void endTransaction(const std::shared_ptr<sql::Connection>& connection);

    // Crud
    void createDatabase(const std::shared_ptr<sql::Connection>& connection, const std::string& databaseName);
    void createTable(const std::shared_ptr<sql::Connection>& connection, const std::string& sql);
    bool hasTable(const std::shared_ptr<sql::Connection>& connection, const std::string& tableName);
    void deleteTable(const std::shared_ptr<sql::Connection>& connection, const std::string& tableName);
    void upsertData(const std::shared_ptr<sql::Connection>& connection, const std::unique_ptr<sql::PreparedStatement>& pstmt);
    void deleteData(const std::shared_ptr<sql::Connection>& connection, const std::unique_ptr<sql::PreparedStatement>& pstmt);
    void selectData(const std::shared_ptr<sql::Connection>& connection, const std::string& sql, std::unique_ptr<sql::ResultSet>& result);


   private:
    const std::string host_;
    const std::string user_;
    const std::string password_;
    const std::string database_;
    unsigned int port_;
    unsigned int poolSize_;

    std::vector<std::shared_ptr<sql::Connection>> connections_;
    std::vector<bool> inUse_;
    std::mutex mutex_;

    void initializeConnections();
    void closeConnections();
};



#endif /* __MYSQL_CONN_POOL_HPP */