/***
 * @Author: JiaHao
 * @Date: 2023-11-22 16:35:32
 * @LastEditors: JiaHao
 * @LastEditTime: 2023-12-06 15:39:16
 * @FilePath: /hostguard_linux/include/logger.hpp
 * @Description:
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved.
 */

// g++ test_spdlog.cpp  -std=c++17 -lspdlog -lfmt

#ifndef __LOGGER_HPP
#define __LOGGER_HPP

#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_TRACE  // must before #include "spdlog/spdlog.h"

#include "spdlog/sinks/rotating_file_sink.h"
#include "spdlog/sinks/stdout_color_sinks.h"
#include "spdlog/spdlog.h"

// This way, the variable is implicitly inline, and you won't encounter multiple definition issues.
constexpr const char* stdout_log_pattern = "[%Y-%m-%d %H:%M:%S.%e] %^[%-7l] {%-80g: %-4#} [Thread %-5t] : %v%$";
constexpr const char* file_log_pattern   = "[%Y-%m-%d %H:%M:%S.%e] %^[%-7l] : %v%$";

class Spdlogger {
   public:
    inline Spdlogger(
        std::string my_stdout_log_pattern = stdout_log_pattern,
        std::string my_file_log_pattern   = file_log_pattern
    );
    inline ~Spdlogger();

    // 定义 log_xxx 函数模板，使用变参模板和完美转发，传递参数时，保留参数的左右值引用属性
    template <typename... Args>
    void log_trace(const char* fmt, Args&&... args);

    template <typename... Args>
    void log_debug(const char* fmt, Args&&... args);

    template <typename... Args>
    void log_info(const char* fmt, Args&&... args);

    template <typename... Args>
    void log_warn(const char* fmt, Args&&... args);

    template <typename... Args>
    void log_error(const char* fmt, Args&&... args);

    template <typename... Args>
    void log_critical(const char* fmt, Args&&... args);

   public:
    std::string _my_stdout_log_pattern;
    std::string _my_file_log_pattern;
    std::shared_ptr<spdlog::logger> my_logger;
};

inline Spdlogger::Spdlogger(
    std::string my_stdout_log_pattern,
    std::string my_file_log_pattern
)
: 
    _my_stdout_log_pattern(my_stdout_log_pattern),
    _my_file_log_pattern(my_file_log_pattern)
{

    printf("Spdlogger(xx...) start\n");
    // Create a file stdout logger
    auto stdout_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
    stdout_sink->set_level(spdlog::level::debug);
    stdout_sink->set_pattern(_my_stdout_log_pattern);
    stdout_sink->set_color(spdlog::level::info, "\033[32m\033[1m");     // "\033[32m\033[1m" : green + bold, default: stdout_sink->green

    // Create a file rotating logger with 1 MB size max and 3 rotated files
    auto max_size   = 1024 * 1024 * 5;
    auto max_files  = 20;
    auto file_sink  = std::make_shared<spdlog::sinks::rotating_file_sink_mt>("logs/rotating.txt", max_size, max_files);
    file_sink->set_level(spdlog::level::info);
    file_sink->set_pattern(_my_file_log_pattern);

    // Create a multi_sink_logger
    my_logger = std::make_shared<spdlog::logger>("multi_sink_logger", spdlog::sinks_init_list{stdout_sink});
    my_logger->sinks().push_back(file_sink);
    my_logger->set_level(spdlog::level::trace);

    // periodically flush all *registered* loggers every 3 seconds:
    // warning: only use if all your loggers are thread-safe ("_mt" loggers)
    spdlog::flush_every(std::chrono::seconds(3));
    // log（≥info）will be flushed immediately
    spdlog::flush_on(spdlog::level::info);

    SPDLOG_LOGGER_DEBUG(my_logger, "Spdlogger(xx...)");
}

inline Spdlogger::~Spdlogger() {
    SPDLOG_LOGGER_DEBUG(my_logger, "~Spdlogger()");
}

// 定义 log_xxx 函数模板，使用变参模板和完美转发，传递参数时，保留参数的左右值引用属性
template <typename... Args>
void Spdlogger::log_trace(const char* fmt, Args&&... args) {
    SPDLOG_LOGGER_TRACE(my_logger, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void Spdlogger::log_debug(const char* fmt, Args&&... args) {
    SPDLOG_LOGGER_DEBUG(my_logger, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void Spdlogger::log_info(const char* fmt, Args&&... args) {
    SPDLOG_LOGGER_INFO(my_logger, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void Spdlogger::log_warn(const char* fmt, Args&&... args) {
    SPDLOG_LOGGER_WARN(my_logger, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void Spdlogger::log_error(const char* fmt, Args&&... args) {
    SPDLOG_LOGGER_ERROR(my_logger, fmt, std::forward<Args>(args)...);
}

template <typename... Args>
void Spdlogger::log_critical(const char* fmt, Args&&... args) {
    SPDLOG_LOGGER_CRITICAL(my_logger, fmt, std::forward<Args>(args)...);
}

#endif /* __LOGGER_HPP */
