#!/bin/bash

# 检查当前目录是否存在 build 文件夹
if [ -d "build" ]; then
    # 如果存在，删除已有的 build 文件夹
    echo "Build folder already exists. Removing..."
    rm -r build
fi

# 检查当前目录是否存在 logs 文件夹
if [ -d "logs" ]; then
    # 如果存在，删除已有的 logs 文件夹
    echo "Logs folder already exists. Removing..."
    sudo rm -r logs
fi