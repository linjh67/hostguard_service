/*** 
 * @Author: JiaHao
 * @Date: 2024-07-25 09:24:38
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-07-26 13:51:25
 * @FilePath: /hostguard_linux/submodule/unix_ipc/unix_server.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#include "unix_ipc/unix_server.h"

extern Spdlogger logger;
extern volatile bool mainExitingFlag;

////////////////// UnixSocketServer ///////////////////////

volatile bool& UnixSocketServer::exitingFlag_ = mainExitingFlag;

UnixSocketServer::UnixSocketServer(
    const std::string& socketPath
)
:   socketPath_(socketPath),
    serverFd_(-1), 
    clientFd_(-1)
{
    SPDLOG_LOGGER_INFO(logger.my_logger, "[Unix Server] UnixSocketServer(xx). Socket Path: {}", socketPath);
}

UnixSocketServer::~UnixSocketServer() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] ~UnixSocketServer()");
    
    clean();    
}


void UnixSocketServer::cleanClientFd() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] cleanClientFd()");

    if (clientFd_ != -1) {
        close(clientFd_);
        clientFd_ = -1;
    }
}

void UnixSocketServer::cleanServerFd() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] cleanServerFd()");

    if (serverFd_ != -1) {
        close(serverFd_);
        serverFd_ = -1;
    }
}

void UnixSocketServer::clean() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] clean()");

    cleanClientFd();
    cleanServerFd();
}

int UnixSocketServer::createSocket() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] createSocket()");

    serverFd_ = socket(AF_UNIX, SOCK_STREAM, 0);
    if (serverFd_ == -1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Create Unix Socket Error: {}", strerror(errno));
        return -1;
    }
    return 1;
}

int UnixSocketServer::bindAddress() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] bindAddress()");

    memset(&sockAddress_, 0, sizeof(sockAddress_));
    sockAddress_.sun_family = AF_UNIX;

    if (socketPath_.length() + 1 >= sizeof(sockAddress_.sun_path)) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Socket Path Too Long!");
        return -1;
    }

    sockAddress_.sun_path[0] = '\0'; // Use abstract namespace
    strcpy(sockAddress_.sun_path + 1, socketPath_.c_str());
    
    // 第一个“1”：使用抽象命名空间的'\0'，第二个“1”：字符串结束标志
    socklen_t addrlen = sizeof(sockAddress_.sun_family) + 1 + socketPath_.length() + 1; 
    if (bind(serverFd_, reinterpret_cast<struct sockaddr*>(&sockAddress_), addrlen) == -1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Unix Socket Bind Error: {}", strerror(errno));
        return -2;
    }

    SPDLOG_LOGGER_INFO(logger.my_logger, "[Unix Server] Unix Socket Bind Success! Unix Socket Path: {}",  reinterpret_cast<char*> (sockAddress_.sun_path + 1));
    
    return 1;
}

int UnixSocketServer::listenSocket() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] listenSocket()");

    if (listen(serverFd_, 5) == -1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Unix Socket Listen Error: {}", strerror(errno));
        return -1;
    }
    return 1;
}

int UnixSocketServer::acceptConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Unix Server] acceptConnection()");
    
    fd_set readFds;

    while(!exitingFlag_) {
        FD_ZERO(&readFds);
        FD_SET(serverFd_, &readFds);

        /* Timeout */
        struct timeval timeout;
        timeout.tv_sec = 0;
        timeout.tv_usec = 500000;     /* 500ms */

        /* select */
        int readyFdCount = select(serverFd_ + 1, &readFds, nullptr, nullptr, &timeout);
        if (readyFdCount == 0) {
            // SPDLOG_LOGGER_WARN(logger.my_logger, "[Unix Server] Select Timeout");
            continue;
        }

        /* select error */
        if (readyFdCount == -1) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Select Error: {}", strerror(errno));
            return -1;
        } 

        /* check fd is set */
        if (FD_ISSET(serverFd_, &readFds)) {
            
            clientFd_ = accept(serverFd_, nullptr, nullptr);

            /* accept error */
            if (clientFd_ == -1) {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Unix Socket Accept Error: {}", strerror(errno));
                return -2;
            }

            /* accept success */
            SPDLOG_LOGGER_INFO(logger.my_logger, "[Unix Server] New client connected");
            return 1;
        }

    }
    return -3;
}


long UnixSocketServer::receiveMessage(std::vector<char>& buffer, long bufferSize) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] receiveMessage()");

    fd_set readFds;
    
    while(!exitingFlag_) {
        FD_ZERO(&readFds);
        FD_SET(clientFd_, &readFds);

        /* Timeout */
        struct timeval timeout;
        timeout.tv_sec = 0;
        timeout.tv_usec = 500000;     /* 500ms */

        /* select */
        int readyFdCount = select(clientFd_ + 1, &readFds, nullptr, nullptr, &timeout);
        if (readyFdCount == 0) {
            // SPDLOG_LOGGER_WARN(logger.my_logger, "[Unix Server] Select Timeout");
            continue;
        }

        /* select error */
        if (readyFdCount == -1) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Select Error: {}", strerror(errno));
            return -1;
        } 

        /* check fd is set */
        if (FD_ISSET(clientFd_, &readFds)) {
            long readSize = read(clientFd_, buffer.data(), bufferSize);

            if (readSize == 0) {    /* number read, 0 for EOF. */
                SPDLOG_LOGGER_WARN(logger.my_logger, "[Unix Server] Receive Message EOF. Connection Closed by Client.");
                return 0;
            }

            if (readSize == -1) {    /* number read, -1 for errors. */
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Receive Message Error: {}", strerror(errno));
                return -2;
            }

            SPDLOG_LOGGER_INFO(logger.my_logger, "[Unix Server] Receive Message readSize: {}", readSize);
            buffer.resize(readSize);

            return readSize;
        }
    }

    return -3;
}

long UnixSocketServer::sendMessage(const std::string& message) {
    long writeSize = write(clientFd_, message.c_str(), message.size());     /* broken pipe */
    if (writeSize == -1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Send Message Error: {}", strerror(errno));
    }
    return writeSize;
}


int UnixSocketServer::init() {
    if (createSocket() != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Create Socket Error!");
        return -1;
    }

    if (bindAddress() != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Bind Address Error!");
        clean();
        return -2;
    }

    if (listenSocket() != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Unix Server] Listen Socket Error!");
        clean();
        return -3;
    }

    return 1;
}

