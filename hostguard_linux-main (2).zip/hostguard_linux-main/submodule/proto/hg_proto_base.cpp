/*** 
 * @Author: JiaHao
 * @Date: 2024-07-22 14:01:08
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-07-24 11:30:44
 * @FilePath: /hg_proto_stack/hg_proto_stack/hg_proto_base.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#include "proto/hg_proto_base.h"

/* 
    HgPacket 
*/
HgPacket::HgPacket(const HgCode& code) 
:   code_(code)
{
    std::cout << "HgPacket(" << (int)code << ")" << std::endl;
}

void HgPacket::fromJson(const json& rootJson) {
    try {
        
        if (rootJson.contains("id")) {
            id_     = rootJson.at("id").get<unsigned long long>(); 
        } else {
            throw std::invalid_argument("id is required!");
        }

        if (rootJson.contains("type")) {
            type_   = rootJson.at("type").get<HgType>();
        } else {
            throw std::invalid_argument("type is required!");
        }

        if (rootJson.contains("code")) {
            code_    = rootJson.at("code").get<HgCode>(); 
        } else {
            throw std::invalid_argument("code is required!");
        }

        if (rootJson.contains("status")) {
            status_    = rootJson.at("status").get<HgRspStatus>(); 
        } else {
            throw std::invalid_argument("status is required!");
        }
        
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgPacket fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgPacket::toJson() const {
    json rootJson;
    rootJson["id"]      = id_;
    rootJson["type"]    = type_;
    rootJson["code"]    = code_;
    rootJson["status"]  = status_;
    return rootJson;
}

std::stringstream HgPacket::print() const {
    std::stringstream ss;
    ss  << std::left
        << std::setw(20) << "[Id: " << id_ << " ]" << std::endl
        << std::setw(20) << "[Type: " << HgTypeStr[(int)type_] << " (" << (int)type_ << ") ]" << std::endl;

    if (code_ >= HgCode::HG_CODE_DEF && code_ < HgCode::HG_CODE_MAX) {
        ss  << std::setw(20) << "[Packet Code: "    << std::setw(20) << HgCodeStr[(int)code_]       << " (" << (int)code_   << ") ]"  << std::endl;
    } else {
        ss  << std::setw(20) << "[Packet Code: "    << std::setw(20) << "Unknown Code" << " (" << (int)code_   << ") ]"  << std::endl;
    }

    if (status_ >= HgRspStatus::HG_RSP_STATUS_DEF && status_ < HgRspStatus::HG_RSP_STATUS_MAX) {
        ss  << std::setw(20) << "[Response Status: "    << std::setw(20) << HgRspStatusStr[(int)status_]       << " (" << (int)status_   << ") ]"  << std::endl;
    } else {
        ss  << std::setw(20) << "[Response Status: "    << std::setw(20) << "Unknown Status" << " (" << (int)status_   << ") ]"  << std::endl;
    }
    
    
    return ss;
}

HgCode HgPacket::getCode() const {
    return code_;
}

void HgPacket::setCode(const HgCode& code) {
    code_ = code;
}
