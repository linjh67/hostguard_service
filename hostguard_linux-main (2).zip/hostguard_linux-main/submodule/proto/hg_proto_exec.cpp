/*** 
 * @Author: JiaHao
 * @Date: 2024-07-22 19:49:49
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-20 13:54:35
 * @FilePath: /hostguard_linux/submodule/proto/hg_proto_exec.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#include "proto/hg_proto_exec.h"

/* 
    HgExecPacket 
*/
HgExecPacket::HgExecPacket(const HgExecSubCode& subCode) 
:   HgPacket(HgCode::HG_CODE_EXEC),
    subCode_(subCode) 
{
    std::cout << "HgExecPacket(" << (int)subCode << ")" << std::endl;
}

void HgExecPacket::fromJson(const json& rootJson) {
    try {
        HgPacket::fromJson(rootJson);

        if (getCode() != HgCode::HG_CODE_EXEC) {
            throw std::invalid_argument("Code is not HG_CODE_EXEC!");
        }

        if (rootJson.contains("subCode")) { 
            subCode_ = rootJson.at("subCode").get<HgExecSubCode>(); 
        } else { 
            throw std::invalid_argument("subCode is required!");
        }

        if (rootJson.contains("description")) {
            description_ = rootJson.at("description").get<std::string>();
        }
        
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgExecPacket fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgExecPacket::toJson() const {
    json rootJson;
    json upperJson = HgPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }
    rootJson["subCode"]    = subCode_;
    rootJson["description"] = description_;
    return rootJson;
}

std::stringstream HgExecPacket::print() const {
    std::stringstream ss;
    ss  << std::left
        << HgPacket::print().str();

    if (subCode_ >= HgExecSubCode::EXEC_SUBCODE_DEF && subCode_ < HgExecSubCode::EXEC_SUBCODE_MAX) {
        ss  << std::setw(20) << "[Packet SubCode: " << std::setw(20) << HgExecSubCodeStr[(int)subCode_] << " (" << (int)subCode_<< ") ]"  << std::endl;
    } else {
        ss  << std::setw(20) << "[Packet SubCode: " << std::setw(20) << "Unknown SubCode" << " (" << (int)subCode_<< ") ]"  << std::endl;
    }

    ss  << std::setw(20) << "[Description: " << description_ << "]" << std::endl;
    return ss;
}

HgExecSubCode HgExecPacket::getSubCode() const {
    return subCode_;
}



/* 
    HgExecSimplePacket

    HgExecPacketWithPathList
 */

/* HgExecSimplePacket */
HgExecSimplePacket::HgExecSimplePacket(
    const HgExecSubCode& subCode
)
:   HgExecPacket(subCode)
{
    std::cout << "HgExecSimplePacket(" << (int)subCode << ")" << std::endl;
}

void HgExecSimplePacket::fromJson(const json& rootJson) {
    try {
        HgExecPacket::fromJson(rootJson);
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgExecSimplePacket fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgExecSimplePacket::toJson() const {
    json rootJson;
    json upperJson = HgExecPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }
    return rootJson;
}

std::stringstream HgExecSimplePacket::print() const {
    std::stringstream ss;
    ss  << std::left     << HgExecPacket::print().str();
    return ss;
}

/* HgExecDataQueryPacket */
HgExecDataQueryPacket::HgExecDataQueryPacket(
    const HgExecSubCode& subCode,
    const DataQueryRange& range
)
:   HgExecPacket(subCode),
    range_(range)
{
    std::cout << "HgExecDataQueryPacket(" << (int)subCode << ")" << std::endl;
}

void HgExecDataQueryPacket::fromJson(const json& rootJson) {
    try {
        HgExecPacket::fromJson(rootJson);

        if (rootJson.contains("range")) {
            range_.fromJson(rootJson.at("range"));
        } else {
            throw std::invalid_argument("range is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgExecDataQueryPacket fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgExecDataQueryPacket::toJson() const {
    json rootJson;
    json upperJson = HgExecPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }
    rootJson["range"]    = range_.toJson();
    return rootJson;
}

std::stringstream HgExecDataQueryPacket::print() const {
    std::stringstream ss;
    ss  << std::left     << HgExecPacket::print().str()
        << range_.print().str();
    return ss;
}

/* HgExecPacketWithWorkMode */
HgExecPacketWithWorkMode::HgExecPacketWithWorkMode(
    const HgExecSubCode& subCode,
    const HgWorkModeOption& workMode
)
:   HgExecPacket(subCode),
    workMode_(workMode)
{
    std::cout << "HgExecPacketWithWorkMode(" << (int)subCode << ")" << std::endl;
}

void HgExecPacketWithWorkMode::fromJson(const json& rootJson) {
    try {
        HgExecPacket::fromJson(rootJson);

        if (rootJson.contains("workMode")) {
            workMode_ = rootJson.at("workMode").get<HgWorkModeOption>();
        } else {
            throw std::invalid_argument("workMode is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgExecPacketWithWorkMode fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgExecPacketWithWorkMode::toJson() const {
    json rootJson;
    json upperJson = HgExecPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }
    rootJson["workMode"]    = workMode_;
    return rootJson;
}

std::stringstream HgExecPacketWithWorkMode::print() const {
    std::stringstream ss;
    ss  << std::left     << HgExecPacket::print().str();

    if (workMode_ >= HgWorkModeOption::WORK_MODE_OPTION_DEF && workMode_ < HgWorkModeOption::WORK_MODE_OPTION_MAX) {
        ss  << std::setw(20) << "[WorkMode: " << HgWorkModeOptionStr[(int)workMode_] << " (" << (int)workMode_ << ") ]" << std::endl;
    } else {
        ss  << std::setw(20) << "[WorkMode: " << "Unknown WorkMode" << " (" << (int)workMode_ << ") ]" << std::endl;
    }
    
    return ss;
}

/* HgExecPacketWithIdList */
HgExecPacketWithIdList::HgExecPacketWithIdList(
    const HgExecSubCode& subCode,
    const std::vector<unsigned long long>& idList
)
:   HgExecPacket(subCode),
    idList_(idList)
{
    std::cout << "HgExecPacketWithIdList(" << (int)subCode << ")" << std::endl;
}

void HgExecPacketWithIdList::fromJson(const json& rootJson) {
    try {
        HgExecPacket::fromJson(rootJson);

        if (rootJson.contains("idList")) {
            for (const auto& id : rootJson.at("idList")) {
                unsigned long long pathId = id.get<unsigned long long>();
                idList_.emplace_back(pathId);
            }
        } else {
            throw std::invalid_argument("idList is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgExecPacketWithIdList fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgExecPacketWithIdList::toJson() const {
    json rootJson;
    json upperJson = HgExecPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }

    json idListJson;
    for (const auto& id : idList_) {
        idListJson.emplace_back(id);
    }
    rootJson["idList"]    = idListJson;
    return rootJson;
}

std::stringstream HgExecPacketWithIdList::print() const {
    int i = 0;
    std::stringstream ss;
    ss  << std::left
        << HgExecPacket::print().str()
        << std::setw(20) << "[IdList: "    << std::endl;

    for (const auto& id : idList_) {
        ss  << "    [" << i << "]: "    << id << std::endl;
        i++;
    }
    
    ss  << "]" << std::endl;
    
    return ss;
}


/* HgExecPacketWithPathList */
HgExecPacketWithPathList::HgExecPacketWithPathList(
    const HgExecSubCode& subCode,
    const std::vector<ExceptionPathEntry>& pathList
)
:   HgExecPacket(subCode),
    pathList_(pathList)
{
    std::cout << "HgExecPacketWithPathList(" << (int)subCode << ")" << std::endl;
}

void HgExecPacketWithPathList::fromJson(const json& rootJson) {
    try {
        HgExecPacket::fromJson(rootJson);

        if (rootJson.contains("pathList")) {
            for (const auto& path : rootJson.at("pathList")) {
                ExceptionPathEntry pathEntry;
                pathEntry.fromJson(path);
                pathList_.emplace_back(pathEntry);
            }
        } else {
            throw std::invalid_argument("pathList is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgExecPacketWithPathList fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgExecPacketWithPathList::toJson() const {
    json rootJson;
    json upperJson = HgExecPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }

    json pathListJson;
    for (const auto& path : pathList_) {
        pathListJson.emplace_back(path.toJson());
    }
    rootJson["pathList"]    = pathListJson;
    return rootJson;
}

std::stringstream HgExecPacketWithPathList::print() const {
    int i = 0;
    std::stringstream ss;
    ss  << std::left
        << HgExecPacket::print().str()
        << std::setw(20) << "[PathList: "    << std::endl;

    for (const auto& path : pathList_) {
        ss  << "    [" << i << "]: "    << path.print().str()   << std::endl;
        i++;
    }
    
    ss  << "]" << std::endl;
    
    return ss;
}


/* HgExecPacketWithWhiteList */
HgExecPacketWithWhiteList::HgExecPacketWithWhiteList(
    const HgExecSubCode& subCode,
    const DataQueryRange& range,
    const std::vector<ExecRuntimeFilePathEntry>& whiteList
)
:   HgExecPacket(subCode),
    range_(range),
    whiteList_(whiteList)
{
    std::cout << "HgExecPacketWithWhiteList(" << (int)subCode << ")" << std::endl;
}

void HgExecPacketWithWhiteList::fromJson(const json& rootJson) {
    try {
        HgExecPacket::fromJson(rootJson);

        if (rootJson.contains("range")) {
            range_.fromJson(rootJson.at("range"));
        } else {
            throw std::invalid_argument("range is required!");
        }

        if (rootJson.contains("whiteList")) {
            for (const auto& whiteListEntry : rootJson.at("whiteList")) {
                ExecRuntimeFilePathEntry whiteListEntryObj;
                whiteListEntryObj.fromJson(whiteListEntry);
                whiteList_.emplace_back(whiteListEntryObj);
            }
        } else {
            throw std::invalid_argument("whiteList is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgExecPacketWithWhiteList fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgExecPacketWithWhiteList::toJson() const {
    json rootJson;
    json upperJson = HgExecPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }

    json rangeJson = range_.toJson();
    rootJson["range"]    = rangeJson;

    json whiteListJson;
    for (const auto& whiteListEntry : whiteList_) {
        whiteListJson.emplace_back(whiteListEntry.toJson());
    }
    rootJson["whiteList"]    = whiteListJson;
    return rootJson;
}

std::stringstream HgExecPacketWithWhiteList::print() const {
    int i = 0;
    std::stringstream ss;
    ss  << std::left
        << HgExecPacket::print().str()
        << std::setw(20) << "[WhiteList: "    << std::endl;

    for (const auto& whiteListEntry : whiteList_) {
        ss  << "    [" << i << "]: "        << std::endl
            << whiteListEntry.print().str() << std::endl;
        i++;
    }
    
    ss  << "]" << std::endl;
    
    return ss;
}
