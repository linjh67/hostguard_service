/*** 
 * @Author: JiaHao
 * @Date: 2024-08-15 09:56:15
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-20 13:56:51
 * @FilePath: /hostguard_linux/submodule/proto/hg_proto_udisk.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#include "proto/hg_proto_udisk.h"

/* 
    HgUdiskPacket 
*/
HgUdiskPacket::HgUdiskPacket(const HgUdiskSubCode& subCode) 
:   HgPacket(HgCode::HG_CODE_UDISK),
    subCode_(subCode) 
{
    std::cout << "HgUdiskPacket(" << (int)subCode << ")" << std::endl;
}

void HgUdiskPacket::fromJson(const json& rootJson) {
    try {

        HgPacket::fromJson(rootJson);

        if (HgPacket::getCode() != HgCode::HG_CODE_UDISK) {
            throw std::invalid_argument("Code is not HG_CODE_UDISK!");
        }

        if (rootJson.contains("subCode")) { 
            subCode_ = rootJson.at("subCode").get<HgUdiskSubCode>(); 
        } else { 
            throw std::invalid_argument("subCode is required!");
        }
        
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgUdiskPacket fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgUdiskPacket::toJson() const {
    json rootJson;
    json upperJson = HgPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }
    rootJson["subCode"]    = subCode_;
    return rootJson;
}

std::stringstream HgUdiskPacket::print() const {
    std::stringstream ss;
    ss  << std::left
        << HgPacket::print().str();

    if (subCode_ >= HgUdiskSubCode::UDISK_SUBCODE_DEF && subCode_ < HgUdiskSubCode::UDISK_SUBCODE_MAX) {
        ss  << std::setw(20) << "[Packet SubCode: " << std::setw(20) << HgUdiskSubCodeStr[(int)subCode_] << " (" << (int)subCode_<< ") ]"  << std::endl;
    } else {
        ss  << std::setw(20) << "[Packet SubCode: " << std::setw(20) << "Unknown SubCode" << " (" << (int)subCode_<< ") ]"  << std::endl;
    }
    
    return ss;
}

HgUdiskSubCode HgUdiskPacket::getSubCode() const {
    return subCode_;
}


/* 
    HgUdiskSimplePacket

    HgUdiskPacketWithKeyList

    HgUdiskPacketWithDevList
 
 */


/* 
    HgUdiskSimplePacket
 */
HgUdiskSimplePacket::HgUdiskSimplePacket(
    const HgUdiskSubCode& subCode
)
:   HgUdiskPacket(subCode)
{
    std::cout << "HgUdiskSimplePacket(" << (int)subCode << ")" << std::endl;
}

void HgUdiskSimplePacket::fromJson(const json& rootJson) {
    try {
        HgUdiskPacket::fromJson(rootJson);
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgUdiskSimplePacket fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgUdiskSimplePacket::toJson() const {
    json rootJson;
    json upperJson = HgUdiskPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }
    return rootJson;
}

std::stringstream HgUdiskSimplePacket::print() const {
    std::stringstream ss;
    ss  << std::left     << HgUdiskPacket::print().str();
    return ss;
}

/* 
    HgUdiskPacketWithKeyList
 */
HgUdiskPacketWithKeyList::HgUdiskPacketWithKeyList(
    const HgUdiskSubCode& subCode,
    const std::vector<std::string>& udiskKeyList
)
:   HgUdiskPacket(subCode),
    udiskKeyList_(udiskKeyList)
{
    std::cout << "HgUdiskPacketWithKeyList(" << (int)subCode << ")" << std::endl;
}

void HgUdiskPacketWithKeyList::fromJson(const json& rootJson) {
    try {
        HgUdiskPacket::fromJson(rootJson);
        
        if (rootJson.contains("udiskKeyList")) {
            for (const auto& uKey : rootJson["udiskKeyList"]) {
                std::string udiskKey = uKey.get<std::string>();
                udiskKeyList_.emplace_back(udiskKey);
            }
        } else {
            throw std::invalid_argument("udiskKeyList is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgUdiskPacketWithKeyList fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgUdiskPacketWithKeyList::toJson() const {
    json rootJson;
    json upperJson = HgUdiskPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }

    json udiskKeyListJson;
    for (const auto& uKey : udiskKeyList_) {
        udiskKeyListJson.emplace_back(uKey);
    }
    rootJson["udiskKeyList"]    = udiskKeyListJson;
    return rootJson;
}

std::stringstream HgUdiskPacketWithKeyList::print() const {
    int i = 0;
    std::stringstream ss;
    ss  << std::left
        << HgUdiskPacket::print().str()
        << std::setw(20) << "[Packet udiskKeyList: "    << std::endl;

    for (const auto& uKey : udiskKeyList_) {
        ss  << "    [" << i << "]: " << std::endl
            << "        " << uKey    << std::endl;
        i++;
    }
    
    ss  << "]" << std::endl;
    
    return ss;
}

/* 
    HgUdiskPacketWithDevList
 */
HgUdiskPacketWithDevList::HgUdiskPacketWithDevList(
    const HgUdiskSubCode& subCode,
    const std::vector<UdiskDevice>& udiskDeviceList
)
:   HgUdiskPacket(subCode),
    udiskDeviceList_(udiskDeviceList)
{
    std::cout << "HgUdiskPacketWithDevList(" << (int)subCode << ")" << std::endl;
}

void HgUdiskPacketWithDevList::fromJson(const json& rootJson) {
    try {
        HgUdiskPacket::fromJson(rootJson);
        
        if (rootJson.contains("udiskDeviceList")) {
            for (const auto& dev : rootJson["udiskDeviceList"]) {
                UdiskDevice udiskDevice;
                udiskDevice.fromJson(dev);
                udiskDeviceList_.emplace_back(udiskDevice);
            }
        } else {
            throw std::invalid_argument("udiskDeviceList is required!");
        }

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error HgUdiskPacketWithDevList fromJson(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json HgUdiskPacketWithDevList::toJson() const {
    json rootJson;
    json upperJson = HgUdiskPacket::toJson();
    for (auto it = upperJson.begin(); it != upperJson.end(); ++it) {
        rootJson[it.key()] = it.value();
    }

    json udiskDeviceListJson;
    for (const auto& dev : udiskDeviceList_) {
        udiskDeviceListJson.emplace_back(dev.toJson());
    }
    rootJson["udiskDeviceList"]    = udiskDeviceListJson;
    return rootJson;
}

std::stringstream HgUdiskPacketWithDevList::print() const {
    int i = 0;
    std::stringstream ss;
    ss  << std::left
        << HgUdiskPacket::print().str()
        << std::setw(20) << "[Packet UdiskDeviceList: "    << std::endl;

    for (const auto& dev : udiskDeviceList_) {
        ss  << "    ["  << i << "]: " << std::endl
            << dev.print().str();
        i++;
    }
    
    ss  << "]" << std::endl;
    
    return ss;
}

