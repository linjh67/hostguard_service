/*** 
 * @Author: JiaHao
 * @Date: 2024-07-14 14:23:36
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-02 10:09:30
 * @FilePath: /hostguard_linux/submodule/utils/utils.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#include "utils.h"
