/*
 * @Author: JiaHao
 * @Date: 2023-11-14 15:27:47
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-21 09:53:04
 * @FilePath: /hostguard_linux/submodule/bpf-c/exec_monitor.bpf.c
 * @Description:
 *
 * Copyright (c) 2023 by JiaHao, All Rights Reserved.
 */
#define __TARGET_ARCH_x86  // __TARGET_ARCH_x86_64 无效

#include "vmlinux.h"  // must before <bpf/bpf_helpers.h>, or will -> bpf_helper_defs.h:292:95: error: unknown type name '__u64'
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include "monitor/exec_monitor_basic.h"

char LICENSE[] SEC("license") = "Dual BSD/GPL";

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1024*1024);
    __type(key, struct kernel_exec_whitelist_key);
    __type(value, struct kernel_exec_whitelist_value);
}   kernel_exec_whitelist_0 SEC(".maps"),
    kernel_exec_whitelist_1 SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1);
    __type(key, u64);
    __type(value, u64);
} whitelist_id_in_use SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1);
    __type(key, u64);
    __type(value, struct kernel_exec_workmode_value);
} work_mode SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 256 * 1024);
    __type(key, u64);
    __type(value, struct task_info);
} task_info SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key, u32);
    __type(value, struct task_info);    // to tmp store info of the current task, over 512 bytes limit
} tmp_task_info SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 32 * 1024 * 1024);
} rb SEC(".maps");

// const volatile unsigned long long min_duration_ns = 0;

#define MAX_PERCPU_BUFSIZE (1 << 15)  // set by the kernel as an upper bound
#define MAX_STRING_SIZE 4096          // same as PATH_MAX
#define MAX_PATH_COMPONENTS 20
#define MAX_CACHED_PATH_SIZE 64

#define BPF_MAP(_name, _type, _key_type, _value_type, _max_entries) \
    struct {                                                        \
        __uint(type, _type);                                        \
        __uint(max_entries, _max_entries);                          \
        __type(key, _key_type);                                     \
        __type(value, _value_type);                                 \
    } _name SEC(".maps");

#define BPF_PERCPU_ARRAY(_name, _value_type, _max_entries) \
    BPF_MAP(_name, BPF_MAP_TYPE_PERCPU_ARRAY, u32, _value_type, _max_entries)

enum buf_idx_e {
    STRING_BUF_IDX,
    FILE_BUF_IDX,
    MAX_BUFFERS
};

typedef struct simple_buf {
    u8 buf[MAX_PERCPU_BUFSIZE];
} buf_t;

BPF_PERCPU_ARRAY(bufs, buf_t, MAX_BUFFERS);  // percpu global buffer variables

typedef struct file_id {
    dev_t device;
    unsigned long inode;
    u64 ctime;
} file_id_t;

typedef struct file_info {
    union {
        char pathname[MAX_CACHED_PATH_SIZE];
        char* pathname_p;
    };
    file_id_t id;
} file_info_t;

statfunc buf_t* get_buf(int idx) {
    // bpf_printk("get_buf");
    return bpf_map_lookup_elem(&bufs, &idx);
}

statfunc struct qstr get_d_name_from_dentry(struct dentry* dentry) {
    return BPF_CORE_READ(dentry, d_name);
}

statfunc struct mount* real_mount(struct vfsmount* mnt) {
    return container_of(mnt, struct mount, mnt);
}

statfunc struct dentry* get_mnt_root_ptr_from_vfsmnt(struct vfsmount* vfsmnt) {
    return BPF_CORE_READ(vfsmnt, mnt_root);
}

statfunc struct dentry* get_d_parent_ptr_from_dentry(struct dentry* dentry) {
    return BPF_CORE_READ(dentry, d_parent);
}

// Read the file path to the given buffer, returning the start offset of the path.
statfunc size_t get_path_str_buf(struct path* path, buf_t* out_buf) {
    if (path == NULL || out_buf == NULL) {
        return 0;
    }

    struct path f_path;
    bpf_core_read(&f_path, sizeof(struct path), path);
    char slash = '/';
    int zero = 0;
    struct dentry* dentry = f_path.dentry;
    struct vfsmount* vfsmnt = f_path.mnt;
    struct mount* mnt_parent_p;
    struct mount* mnt_p = real_mount(vfsmnt);
    bpf_core_read(&mnt_parent_p, sizeof(struct mount*), &mnt_p->mnt_parent);
    u32 buf_off = (MAX_PERCPU_BUFSIZE >> 1);
    struct dentry* mnt_root;
    struct dentry* d_parent;
    struct qstr d_name;
    unsigned int len;
    unsigned int off;
    int sz;

#pragma unroll
    for (int i = 0; i < MAX_PATH_COMPONENTS; i++) {
        mnt_root = get_mnt_root_ptr_from_vfsmnt(vfsmnt);
        d_parent = get_d_parent_ptr_from_dentry(dentry);
        if (dentry == mnt_root || dentry == d_parent) {
            if (dentry != mnt_root) {
                // We reached root, but not mount root - escaped?
                break;
            }
            if (mnt_p != mnt_parent_p) {
                // We reached root, but not global root - continue with mount point path
                bpf_core_read(&dentry, sizeof(struct dentry*), &mnt_p->mnt_mountpoint);
                bpf_core_read(&mnt_p, sizeof(struct mount*), &mnt_p->mnt_parent);
                bpf_core_read(&mnt_parent_p, sizeof(struct mount*), &mnt_p->mnt_parent);
                vfsmnt = &mnt_p->mnt;
                continue;
            }
            // Global root - path fully parsed
            break;
        }
        // Add this dentry name to path
        d_name = get_d_name_from_dentry(dentry);
        len = (d_name.len + 1) & (MAX_STRING_SIZE - 1);
        off = buf_off - len;
        // Is string buffer big enough for dentry name?
        sz = 0;
        if (off <= buf_off) {  // verify no wrap occurred
            len = len & ((MAX_PERCPU_BUFSIZE >> 1) - 1);
            sz = bpf_core_read_str(
                &(out_buf->buf[off & ((MAX_PERCPU_BUFSIZE >> 1) - 1)]), len, (void*)d_name.name);
        } else {
            break;
        }

        if (sz > 1) {
            buf_off -= 1;  // remove null byte termination with slash sign
            bpf_core_read(&(out_buf->buf[buf_off & (MAX_PERCPU_BUFSIZE - 1)]), 1, &slash);
            buf_off -= sz - 1;
        } else {
            // If sz is 0 or 1 we have an error (path can't be null nor an empty string)
            break;
        }
        dentry = d_parent;
    }
    if (buf_off == (MAX_PERCPU_BUFSIZE >> 1)) {
        // memfd files have no path in the filesystem -> extract their name
        buf_off = 0;
        d_name = get_d_name_from_dentry(dentry);
        bpf_core_read_str(&(out_buf->buf[0]), MAX_STRING_SIZE, (void*)d_name.name);
    } else {
        // Add leading slash
        buf_off -= 1;
        bpf_core_read(&(out_buf->buf[buf_off & (MAX_PERCPU_BUFSIZE - 1)]), 1, &slash);
        // Null terminate the path string
        bpf_core_read(&(out_buf->buf[(MAX_PERCPU_BUFSIZE >> 1) - 1]), 1, &zero);
    }
    return buf_off;
}

statfunc void* get_path_str(struct path* path) {
    // Get per-cpu string buffer
    buf_t* string_p = get_buf(STRING_BUF_IDX);
    if (string_p == NULL)
        return NULL;

    size_t buf_off = get_path_str_buf(path, string_p);
    return &string_p->buf[buf_off];
}

// statfunc file_info_t get_file_info(struct file *file)
// {
// 	bpf_printk("get_file_info");
//     file_info_t file_info = {};
//     if (file) {
//         file_info.pathname_p = get_path_str(__builtin_preserve_access_index(&file->f_path));
//         // file_info.id = get_file_id(file);
//     }
//     // return file_info;
// }


//////////////////////////////////////////////////////

/* get first ancestry task uid, not 0(root) */
statfunc long get_real_launcher(struct task_info* p_task_info) {
    int iter_count = 0;
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    struct task_struct *task = (struct task_struct *)bpf_get_current_task();

    u64 launcher_pid = (u64)BPF_CORE_READ(task, tgid);
    uid_t launcher_uid = BPF_CORE_READ(task, cred, uid).val;
    uid_t launcher_euid = BPF_CORE_READ(task, cred, euid).val;
    
    /* 追溯父进程，查找真正的 UID */
    while (task && iter_count < PARENT_TASK_ITER_MAX_COUNT) {
        uid_t tmp_uid = BPF_CORE_READ(task, cred, uid).val;
        if (tmp_uid != 0) {
            launcher_pid = (u64)BPF_CORE_READ(task, tgid);
            launcher_uid = tmp_uid;
            launcher_euid = BPF_CORE_READ(task, cred, euid).val;            
            break;
        }
        task = BPF_CORE_READ(task, real_parent);
        iter_count++;
    }

    p_task_info->event.launcher.pid = launcher_pid;
    p_task_info->event.launcher.uid = launcher_uid;
    p_task_info->event.launcher.euid = launcher_euid;

    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_real_launcher] [launcher_pid: %lu], [launcher_uid: %u], [launcher_euid: %u], [iter_count: %d]", 
                            pid, launcher_pid, launcher_uid, launcher_euid, iter_count);

    return 0;
}

statfunc long copy_task_info_by_pid(struct task_struct *task, struct task_info* p_dst_task_info, u64 src_pid) {
    
    u64 pid = BPF_CORE_READ(task, tgid);

    /* lookup task_info */
    struct task_info* p_src_task_info = bpf_map_lookup_elem(&task_info, &src_pid);
    if (!p_src_task_info) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [copy_task_info_by_pid] lookup task_info of src_pid [%lu] failed! Entry not exists! return!", pid, src_pid);
        return -1;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [copy_task_info_by_pid] lookup task_info of src_pid [%lu] success.", pid, src_pid);
    }
 
    /* copy from src_pid task_info */
    long ret = bpf_probe_read(p_dst_task_info, sizeof(struct task_info), p_src_task_info);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [copy_task_info_by_pid] copy task_info of src_pid [%lu] to dst_task_info failed, ret %ld, return!", pid, src_pid, ret);
        return -2;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [copy_task_info_by_pid] copy task_info of src_pid [%lu] to dst_task_info success.", pid, src_pid);
    }

    return 0;
}

statfunc long create_task_info(struct task_struct *task) {

    u64 pid = BPF_CORE_READ(task, tgid);

    /* lookup task_info */
    struct task_info* p_task_info = bpf_map_lookup_elem(&task_info, &pid);
    if (p_task_info) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [create_task_info] task_info [%lu] already exists. No need to create, return!", pid, pid);
        return 0;
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [create_task_info] task_info [%lu] not exists! Create one!", pid, pid);
    }

    /* BPF_MAP_TYPE_PERCPU_ARRAY */
    u32 zero = 0;
    struct task_info* p_tmp_task_info = bpf_map_lookup_elem(&tmp_task_info, &zero);
    if (!p_tmp_task_info){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [create_task_info] lookup tmp_task_info failed!", pid);
        return -1;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [create_task_info] lookup tmp_task_info success.", pid);
    }

    /* lookup ppid in task_info */
    u64 ppid = BPF_CORE_READ(task, real_parent, tgid);
    long ret = copy_task_info_by_pid(task, p_tmp_task_info, ppid);
    if (ret == 0) {
        p_tmp_task_info->pid = pid;
        p_tmp_task_info->ppid = ppid;
        p_tmp_task_info->event_history_flag = FLAG_DEFAULT_EXEC_EVENT;
        p_tmp_task_info->start_time_ns = bpf_ktime_get_ns();  
        bpf_get_current_comm(&p_tmp_task_info->args.comm, sizeof(p_tmp_task_info->args.comm));
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [create_task_info] p_tmp_task_info->args.comm: %s", pid, p_tmp_task_info->args.comm);
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [create_task_info] copy from [ppid: %lu] task_info success.", pid, ppid);      
        goto update_task_info;
    }

    /* 
        Failed to copy from parent task_info.
        Need to fill out new task_info from scratch.
    */

    /* seperate the memset to avoid error over limit size */

    /* MEMSET args.argv, first step.
        to avoid clang optimization resulted error: 
        A call to built-in function 'memset' is not supported. 
        because over size of memset.
    */
    for (int i = 0; i < TASK_ARGV_NUM; i++) {
        char* p_argv = &p_tmp_task_info->args.argv[i * TASK_ARGV_LEN];
        p_argv[TASK_ARGV_LEN-1] = '\0';
    }

    /* MEMSET event.abs_filepath */
    __builtin_memset(p_tmp_task_info->event.abs_filepath, 0, 800);  // sizeof(struct task_event) will exceed the limit of memset
    p_tmp_task_info->pid = pid;

    __builtin_memset(p_tmp_task_info->event.abs_filepath + 800, 0, 800);  // sizeof(struct task_event) will exceed the limit of memset
    p_tmp_task_info->ppid = ppid;
    
    __builtin_memset(p_tmp_task_info->event.abs_filepath + 1600, 0, MAX_FILEPATH_LEN - 1600);  // sizeof(struct task_event) will exceed the limit of memset
    p_tmp_task_info->event_history_flag = FLAG_DEFAULT_EXEC_EVENT;
    p_tmp_task_info->start_time_ns = bpf_ktime_get_ns();

    /* MEMSET other parts of event */
    __builtin_memset(&p_tmp_task_info->event, 0, sizeof(struct task_event)-MAX_FILEPATH_LEN);    
    p_tmp_task_info->event.type = DEFAULT_EXEC_EVENT_TYPE;
    p_tmp_task_info->event.react_whitelist = ALLOW_EXEC;    /* check and fill in exec later */
    p_tmp_task_info->event.react_actual = ALLOW_EXEC;       /* check and fill in exec later */

    /* MEMSET args.comm */
    __builtin_memset(&p_tmp_task_info->args.comm, 0, TASK_COMM_LEN);
    bpf_get_current_comm(&p_tmp_task_info->args.comm, sizeof(p_tmp_task_info->args.comm));
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [create_task_info] p_tmp_task_info->args.comm: %s", pid, p_tmp_task_info->args.comm);
    
    /* MEMSET args.argv, second step.
        TASK_ARGV_LEN-1: to avoid clang optimization resulted error: 
        A call to built-in function 'memset' is not supported. 
        because over size of memset.
    */   
    // __builtin_memset(&p_tmp_task_info->args.argv, 0, TASK_ARGV_NUM * TASK_ARGV_LEN);     // error: A call to built-in function 'memset' is not supported.
    for (int i = 0; i < TASK_ARGV_NUM; i++) {
        char* p_argv = &p_tmp_task_info->args.argv[i * TASK_ARGV_LEN];  
        __builtin_memset(p_argv, 0, TASK_ARGV_LEN-1);
    }

update_task_info:
    /* record into map task_info */
    ret = bpf_map_update_elem(&task_info, &pid, p_tmp_task_info, BPF_ANY);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [create_task_info] update task_info failed! ret: %ld", pid, ret);
        return -2;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [create_task_info] update task_info success.", pid);
    }

    return 0;
}

// statfunc int print_task_args(struct task_args* p_args) {
//     for (int i = 0; i < TASK_ARGV_NUM; i++) {
//         const char* ptr = &p_args->argv[i * TASK_ARGV_LEN];
//         if (ptr[0] != '\0') {
//             BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] %s", ptr);
//         } else {
//             break;
//         }
//     }
//     return 0;
// }

/* 手动进行大小端转换 4字节 */
statfunc unsigned int htoni(unsigned int data) {
    unsigned int big_endian_data =
        ((data >> 24) &       0xFF) |
        ((data >> 8)  &     0xFF00) |
        ((data << 8)  &   0xFF0000) |
        ((data << 24) & 0xFF000000);

    return big_endian_data;
}

statfunc long print_hex_array(u8* ima_hash, size_t len) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    int cnt = len/sizeof(unsigned int);
    for (int i = 0; i < cnt; i++) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] hash[%d]: %08lx", 
                    pid,
                    i,
                    htoni(*(u32*)(ima_hash + i*4))
        );
    }
    
    return 0;
}


statfunc long get_ima_file_hash(struct file *p_file, u8* ima_hash) {
    if(!p_file){
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [get_ima_file_hash] p_file: NULL, return!");
        return -1;
    }

    u64 pid = bpf_get_current_pid_tgid() >> 32;
    long hash_algo = bpf_ima_file_hash(p_file, ima_hash, IMA_DIGEST_MAX_SIZE);
    if (hash_algo >= 0) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_ima_file_hash] bpf_ima_file_hash() OK, hash_algo: %ld", pid, hash_algo);        
    }else if(hash_algo == -EOPNOTSUPP){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [get_ima_file_hash] bpf_ima_file_hash() failed, ret:%ld =-EOPNOTSUPP", pid, -EOPNOTSUPP);
    }else if(hash_algo == -EINVAL){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [get_ima_file_hash] bpf_ima_file_hash() failed, ret:%ld =-EINVAL", pid, -EINVAL);
    }else{
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [get_ima_file_hash] bpf_ima_file_hash() failed, ret:%ld", pid, hash_algo);
    }

    return hash_algo;
}

// statfunc long get_real_file_ptr_from_bprm(struct linux_binprm *bprm, struct file** pp_real_file) {
//     u64 pid = bpf_get_current_pid_tgid() >> 32;
//     const char* filename = bprm->filename;
//     const char* interp = bprm->interp;
//     const char* fdpath = bprm->fdpath;
//     BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_real_file_ptr_from_bprm] filename: %s, interp: %s, fdpath: %s", pid, filename, interp, fdpath);

//     struct file* executable = BPF_CORE_READ(bprm, executable);
//     struct file* interpreter = BPF_CORE_READ(bprm, interpreter);
//     struct file* file = BPF_CORE_READ(bprm, file);
//     BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_real_file_ptr_from_bprm] executable: %p, interpreter: %p, file: %p", pid, executable, interpreter, file);

//     if(file){
//         *pp_real_file = file;
//         BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_real_file_ptr_from_bprm] *pp_real_file = bprm->file", pid);
//         return 1;
//     }else if(executable){
//         *pp_real_file = executable;
//         BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_real_file_ptr_from_bprm] *pp_real_file = bprm->executable", pid);
//         return 2;
//     }else if(interpreter){
//         *pp_real_file = interpreter;
//         BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_real_file_ptr_from_bprm] *pp_real_file = bprm->interpreter", pid);
//         return 3;
//     }else {
//         BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [get_real_file_ptr_from_bprm] executable, interpreter, file are all NULL, return!", pid);
//         return -1;
//     }
// }

statfunc long get_abs_filepath_from_file(struct file* p_real_file, char* abs_filepath, int bufferlen) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;

    if(!p_real_file){
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [get_abs_filepath_from_file] p_real_file: NULL, return!", pid);
        return -1;
    }

    long ret = 0;    
    struct path* f_path = &(p_real_file->f_path);
    // 使用bpf_d_path函数获取可执行文件的绝对路径
    ret = bpf_d_path(f_path, abs_filepath, bufferlen);
    if (ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [get_abs_filepath_from_file] bpf_d_path failed: ret %d, return!", pid, ret);
        return -2;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_abs_filepath_from_file] bpf_d_path success.", pid);
    }

    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [get_abs_filepath_from_file] abs_filepath: %s", pid, abs_filepath);
    return 0;
}

/* 比对白名单 IMA_Hash */
statfunc enum exec_reaction filter_by_IMA_hash(u8* IMA_hash) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    
    u64 zero = 0;
    struct kernel_exec_whitelist_key w_key = {0};
    struct kernel_exec_whitelist_value* p_w_value = NULL;

    /* copy digest hash */
    long ret = bpf_probe_read(w_key.ima_hash, IMA_DIGEST_MAX_SIZE, IMA_hash);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [filter_by_IMA_hash] read(w_key.ima_hash, IMA_DIGEST_MAX_SIZE, IMA_hash) failed! ret: %lu", pid, ret);
        return OTHER_REACT_EXEC;
    }

    /* get WhiteListMap Id in use */
    u64* p_whitelist_id_in_use = bpf_map_lookup_elem(&whitelist_id_in_use, &zero);
    if (!p_whitelist_id_in_use) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [filter_by_IMA_hash] lookup whitelist_id_in_use failed! return!", pid);
        return OTHER_REACT_EXEC;
    }

    /* lookup the WhiteListMap */
    u64 whitelist_id = *p_whitelist_id_in_use;
    BPF_LOG(BPF_LOG_INFO, "[ info  ] [pid:%5lu] [filter_by_IMA_hash] whitelist_id: %lu", pid, whitelist_id);
    if (whitelist_id % 2 == 0) {
        p_w_value = bpf_map_lookup_elem(&kernel_exec_whitelist_0, &w_key);
    } else {
        p_w_value = bpf_map_lookup_elem(&kernel_exec_whitelist_1, &w_key);
    }

    /* Not found in kernel whitelist */
    if (!p_w_value) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [filter_by_IMA_hash] lookup ima_hash in whitelist failed! [whitelist id: %lu], [hash: 0x%02x, 0x%02x, 0x%02x, 0x%02x]", 
            pid, whitelist_id, w_key.ima_hash[0], w_key.ima_hash[1], w_key.ima_hash[2], w_key.ima_hash[3]);
        return DENY_EXEC;
    }

    /* Found in kernel whitelist */
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [filter_by_IMA_hash] lookup ima_hash in whitelist success. [whitelist id: %lu], [hash: 0x%02x, 0x%02x, 0x%02x, 0x%02x], w_value.react: %d", 
            pid, whitelist_id, w_key.ima_hash[0], w_key.ima_hash[1], w_key.ima_hash[2], w_key.ima_hash[3], p_w_value->react);

    /* ALLOW_EXEC in whitelist */
    if (p_w_value->react == ALLOW_EXEC) {
        return ALLOW_EXEC;
    }
    
    /* DENY_EXEC in whitelist */
    if (p_w_value->react == DENY_EXEC) {
        return DENY_EXEC;
    }
    
    /* Other in whitelist */
    return OTHER_REACT_EXEC;
}

// statfunc long filter_by_abs_filepath(char* abs_filepath) {
    
//     if(abs_filepath == NULL){
//         BPF_LOG(BPF_LOG_WARNING, "[WARNING] [filter_by_abs_filepath] abs_filepath: NULL");
//         return -2;
//     }

//     /* 获取 tmp_task_info 空间指针 */
//     u32 zero = 0;
//     struct task_info* p_tmp_task_info = NULL;
//     p_tmp_task_info = bpf_map_lookup_elem(&tmp_task_info, &zero);   /* BPF_MAP_TYPE_PERCPU_ARRAY */
//     if (!p_tmp_task_info){
//         BPF_LOG(BPF_LOG_WARNING, "[WARNING] [filter_by_abs_filepath] bpf_map_lookup_elem(&tmp_task_info, &zero) failed");
//         return -3;
//     }

//     /* 复制 abs_filepath 到 p_tmp_task_info->event, 原因：bpf_strncmp 不接受 ringbuf reserve指针，所以复制到 PERCPU_ARRAY */
//     struct task_event* p_event = &p_tmp_task_info->event; 
//     long ret = bpf_probe_read_str(p_event->abs_filepath, sizeof(p_event->abs_filepath), abs_filepath);
//     if(ret < 0){
//         BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [filter_by_abs_filepath] bpf_probe_read_str(p_event->abs_filepath) failed");
//         return -4;
//     }
   
//     /* 比对 abs_filepath */
//     ret = bpf_strncmp(p_event->abs_filepath, 12, "/usr/bin/ls");
//     if(ret == 0){
//         BPF_LOG(BPF_LOG_WARNING, "[WARNING] [filter_by_abs_filepath] /usr/bin/ls rejected");
//         // bpf_send_signal(SIGINT);	    // 直接kill进程 SIGINT:2
//         return -EPERM;                  // 拒绝执行
//     }

//     return 0;
// }

/* clone/fork/vfork */
statfunc long do_handle_newproc(enum exec_event_type type) {
    
    u64 zero = 0;
    long ret = 0;
    enum HgWorkModeOption workmode = WORK_MODE_OPTION_DEF;
    struct task_struct* task = (struct task_struct*)bpf_get_current_task();
    u64 pid = BPF_CORE_READ(task, tgid);
    u64 ppid = BPF_CORE_READ(task, real_parent, tgid);

    /* get kernel WorkMode */
    struct kernel_exec_workmode_value* p_workmode = bpf_map_lookup_elem(&work_mode, &zero);
    if (!p_workmode) {
        workmode = WORK_MODE_OPTION_WARNING;
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] lookup work_mode failed!", pid);
    } else {
        workmode = p_workmode->workmode;
    }
    
    /* check workmode */
    if (workmode == WORK_MODE_OPTION_SILENT) {
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_newproc] work_mode: SILENT, return!", pid);
        return 0;
    }
  
    /* get task_info */
    struct task_info* p_task_info = bpf_map_lookup_elem(&task_info, &pid);
    if (!p_task_info) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] legacy task_info [%lu] not exists. Good.", pid, pid);
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] legacy task_info [%lu] exists. Try to delete it.", pid, pid);
        /* Any way, delete old task_info with the same pid */
        ret = bpf_map_delete_elem(&task_info, &pid);
        if (ret == 0) {
            BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] delete legacy task_info [%lu] success.\n", pid, pid);
        } else if (ret == -ENOENT) {
            BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_newproc] delete legacy task_info [%lu] failed! Entry not exists! ret: %ld\n", pid, pid, ret);
        } else {
            BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_newproc] delete legacy task_info [%lu] failed! ret: %ld. Change info to default info one by one!\n", pid, pid, ret);
            /* Not likely to happen, failed to delete, have to change info in it to default info */
            p_task_info->pid = pid;
            p_task_info->ppid = ppid;
            p_task_info->event_history_flag = FLAG_DEFAULT_EXEC_EVENT;
            p_task_info->start_time_ns = bpf_ktime_get_ns();
            p_task_info->event.type = DEFAULT_EXEC_EVENT_TYPE;
            p_task_info->event.react_whitelist = ALLOW_EXEC;    /* check and fill in exec later */
            p_task_info->event.react_actual = ALLOW_EXEC;       /* check and fill in exec later */
            bpf_get_current_comm(&p_task_info->args.comm, sizeof(p_task_info->args.comm));
            /* MEMSET event.ima_hash */
            __builtin_memset(p_task_info->event.ima_hash, 0, IMA_DIGEST_MAX_SIZE);
        }
    }

    /* New process, create one task_info */
    ret = create_task_info(task);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] create_task_info failed! ret: %ld, return!", pid, ret);
        return -1;
    } else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] create_task_info success.", pid);
    }

    /* get task_info created just now */
    p_task_info = bpf_map_lookup_elem(&task_info, &pid);
    if (!p_task_info) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] lookup task_info failed just after create! return!", pid);
        return -2;
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] lookup task_info created just now success.", pid);
    }

    /* type and react */
    p_task_info->event.type = type;
    p_task_info->event.react_actual = ALLOW_EXEC;
    p_task_info->event.react_whitelist = ALLOW_EXEC;
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_newproc] [type: %d] [react_actual: %d]", pid, type, p_task_info->event.react_actual);

    /* abs_filepath */
    struct file* exe_file = BPF_CORE_READ(task, mm, exe_file);
    if(!exe_file){
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_newproc] task->mm->exe_file: NULL, return!", pid);
        return -4;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] task->mm->exe_file: %p", pid, exe_file);        
    }

    char* pathname_p = get_path_str(__builtin_preserve_access_index(&exe_file->f_path));  // get absolute path
    if(!pathname_p){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] get_path_str failed! return!", pid);
        return -5;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [do_handle_newproc] get_path_str success. abs_filepath: %s", pid, pathname_p);
    }

    ret = bpf_core_read_str(&p_task_info->event.abs_filepath, sizeof(p_task_info->event.abs_filepath), pathname_p);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] read abs_filepath from pathname_p failed! ret: %ld, return!", pid, ret);
        return -6;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] read abs_filepath from pathname_p success.", pid);
    }

    /* get real launcher */
    get_real_launcher(p_task_info);

    /* to tell that CLONE event has been written to p_task_info successfully */
    p_task_info->event_history_flag = p_task_info->event_history_flag | (1<<type);

    /* 
        sent to userspace 
    */

    /* reserve sample from BPF ringbuf */
    struct task_info* p_ringbuf = bpf_ringbuf_reserve(&rb, sizeof(struct task_info), 0);
    if (!p_ringbuf){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] ringbuf_reserve failed! return!", pid);
        return -7;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] ringbuf_reserve success.", pid);
    }

    /* copy task_info to ringbuf */
    ret = bpf_probe_read(p_ringbuf, sizeof(struct task_info), p_task_info);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] copy task_info to ringbuf failed, ret %ld", pid, ret);
        bpf_ringbuf_discard(p_ringbuf, 0);
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_newproc] ringbuf discard and return!", pid);
        return -8;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] copy task_info to ringbuf success.", pid);
    }

    /* successfully submit it to user-space for post-processing */
    bpf_ringbuf_submit(p_ringbuf, 0);
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_newproc] submit ringbuf success.", pid);
    
    return 0;
}

statfunc long do_handle_exec(struct linux_binprm *bprm) {
    
    u64 zero = 0;
    long ret = 0;
    enum HgWorkModeOption workmode = WORK_MODE_OPTION_DEF;
    struct task_struct* task = (struct task_struct*)bpf_get_current_task();
    u64 pid = BPF_CORE_READ(task, tgid);

    /* get kernel WorkMode */
    struct kernel_exec_workmode_value* p_workmode = bpf_map_lookup_elem(&work_mode, &zero);
    if (!p_workmode) {
        workmode = WORK_MODE_OPTION_WARNING;
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] lookup work_mode failed!", pid);
    } else {
        workmode = p_workmode->workmode;
    }
    
    /* check workmode */
    if (workmode == WORK_MODE_OPTION_SILENT) {
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_exec] work_mode: SILENT, return!", pid);
        return 0;
    }

    /* create task_info */
    ret = create_task_info(task);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] create_task_info failed! ret: %ld, return!", pid, ret);
        return -2;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exec] create_task_info success.", pid);
    }
    
    /* lookup task_info */
    struct task_info* p_task_info = bpf_map_lookup_elem(&task_info, &pid);
    if (!p_task_info) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] lookup task_info failed just after create! return!", pid);
        return -3;
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exec] lookup task_info success.", pid);
    }

    /* fill out task event */
    p_task_info->event.type = LSM_EXEC;

    __builtin_memset(p_task_info->event.abs_filepath, 0, 800);  // just in case dirty data

    /* get absolute path of the executable file */
    ret = get_abs_filepath_from_file(bprm->file, p_task_info->event.abs_filepath, sizeof(p_task_info->event.abs_filepath));
    if(ret != 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] get_abs_filepath_from_file failed! ret %d, return!", pid, ret);
        return -5;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [do_handle_exec] get_abs_filepath_from_file success.", pid);
    }

    /* calculate IMA hash of executable file */ 
    u8 ima_hash[IMA_DIGEST_MAX_SIZE] = {0};
    ret = get_ima_file_hash(bprm->file, ima_hash);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] get_ima_file_hash(%s) failed! ret %d, return!", pid, p_task_info->event.abs_filepath, ret);
        return -6;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [do_handle_exec] get_ima_file_hash(%s) success.", pid, p_task_info->event.abs_filepath);
    }
    print_hex_array(ima_hash, IMA_DIGEST_MAX_SIZE);

    /* copy ima hash to p_task_info */
    ret = bpf_probe_read(p_task_info->event.ima_hash, IMA_DIGEST_MAX_SIZE, ima_hash);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] read(w_key.ima_hash, IMA_DIGEST_MAX_SIZE, ima_hash) failed! ret: %lu", pid, ret);
        return -7;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [do_handle_exec]  copy ima hash (%s) to p_task_info success.", pid, p_task_info->event.abs_filepath);
    }

    /* compare with hash whitelist */
    enum exec_reaction reaction_in_whitelist = filter_by_IMA_hash(ima_hash);
    p_task_info->event.react_whitelist = reaction_in_whitelist;
    /* ALLOW */
    if ( reaction_in_whitelist == ALLOW_EXEC ) {
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_exec] Reaction in File IMA_hash Whitelist is ALLOW_EXEC. filepath: %s", pid, p_task_info->event.abs_filepath);
        p_task_info->event.react_actual = ALLOW_EXEC;
    }
    /* DENY */
    if ( reaction_in_whitelist == DENY_EXEC ) {
        if (workmode == WORK_MODE_OPTION_BLOCK) {   /* Block Mode */
            BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_exec] [warning] Reaction in File IMA_hash Whitelist is DENY_EXEC! filepath: %s", pid, p_task_info->event.abs_filepath);
            p_task_info->event.react_actual = DENY_EXEC;
        } else {                                    /* Warning Mode */
            BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_exec] [warning] Reaction in File IMA_hash Whitelist is DENY_EXEC! filepath: %s", pid, p_task_info->event.abs_filepath);
            p_task_info->event.react_actual = WARNING_EXEC;
        }
    }
    /* WARNING || OTHER */
    if (reaction_in_whitelist == WARNING_EXEC || reaction_in_whitelist == OTHER_REACT_EXEC) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_exec] [warning] Reaction in File IMA_hash Whitelist is not ALLOW_EXEC/DENY_EXEC! filepath: %s", pid, p_task_info->event.abs_filepath);
        p_task_info->event.react_actual = WARNING_EXEC;
    }

    /* get real launcher */
    get_real_launcher(p_task_info);

    /* to tell that LSM_EXEC event has been written to p_task_info successfully */
    p_task_info->event_history_flag = p_task_info->event_history_flag | FLAG_LSM_EXEC;

    /* 
        sent to userspace 
    */

    /* reserve sample from BPF ringbuf */
    struct task_info* p_ringbuf = bpf_ringbuf_reserve(&rb, sizeof(struct task_info), 0);
    if (!p_ringbuf){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] ringbuf_reserve failed! return!", pid);
        return -8;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exec] ringbuf_reserve success.", pid);
    }

    ret = bpf_probe_read(p_ringbuf, sizeof(struct task_info), p_task_info);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] copy task_info to ringbuf failed, ret %ld", pid, ret);
        bpf_ringbuf_discard(p_ringbuf, 0);
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exec] ringbuf discard and return!", pid);
        return -9;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exec] copy task_info to ringbuf success.", pid);
    }

    /* successfully submit it to user-space for post-processing */
    bpf_ringbuf_submit(p_ringbuf, 0);
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exec] submit ringbuf success.", pid);
    
    if (p_task_info->event.react_actual == DENY_EXEC) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_exec] [filepath: %s] DENY Exec!\n", pid, p_task_info->event.abs_filepath);
        return -EPERM;
    }

    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_exec] [filepath: %s] ALLOW Exec.\n", pid, p_task_info->event.abs_filepath);
    return 0;
}

statfunc int do_handle_exit(struct task_struct *task) {
    
    u64 zero = 0;
    long ret = 0;
    enum HgWorkModeOption workmode = WORK_MODE_OPTION_DEF;
    u64 pid = BPF_CORE_READ(task, tgid);

    /* get kernel WorkMode */
    struct kernel_exec_workmode_value* p_workmode = bpf_map_lookup_elem(&work_mode, &zero);
    if (!p_workmode) {
        workmode = WORK_MODE_OPTION_WARNING;
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] lookup work_mode failed!", pid);
    } else {
        workmode = p_workmode->workmode;
    }
    
    /* check workmode */
    if (workmode == WORK_MODE_OPTION_SILENT) {
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_exit] work_mode: SILENT, return!", pid);
        return 0;
    }

    /* create task_info */
    ret = create_task_info(task);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] create_task_info failed! ret: %ld", pid, ret);
        return -1;
    } else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] create_task_info success.", pid);
    }

    /* lookup task_info created just now */
    struct task_info* p_task_info = bpf_map_lookup_elem(&task_info, &pid);
    if (p_task_info) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] lookup task_info success.", pid);        
    } else {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] lookup task_info created just now failed! return!", pid);
        return -2;
    }

    p_task_info->event.type = EXIT;
    p_task_info->event.exit_code = (BPF_CORE_READ(task, exit_code) >> 8) & 0xff;
    p_task_info->event.react_actual = ALLOW_EXEC;
    
    /* reserve sample from BPF ringbuf */
    struct task_info* p_ringbuf = bpf_ringbuf_reserve(&rb, sizeof(struct task_info), 0);
    if (!p_ringbuf) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] bpf_ringbuf_reserve failed!", pid);
        goto clear_task_info;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] bpf_ringbuf_reserve success.", pid);
    }
    
    /* if this task_info was successfully processed by previous CLONE/LSM_EXEC events */
    if(p_task_info->event_history_flag != FLAG_DEFAULT_EXEC_EVENT){
        /* duration_us */
        p_task_info->event.duration_us = (bpf_ktime_get_ns() - p_task_info->start_time_ns)/1000;
        
        /* to tell that EXIT event has been written to p_task_info successfully */
        p_task_info->event_history_flag = p_task_info->event_history_flag | FLAG_EXIT;
       
        ret = bpf_probe_read(p_ringbuf, sizeof(struct task_info), p_task_info);
        if(ret < 0){
            BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] copy task_info to ringbuf failed, ret %ld", pid, ret);
        }else{
            BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] copy task_info to ringbuf success.", pid);
            goto submit_and_clear;
        }
    }


    /* 
        If this task_info was newly created by this exit event.
        Need to fill out new task_info from scratch.
    */

    p_task_info->start_time_ns = 0;        // we don't know start_time_ns, set to 0
    p_task_info->event.duration_us = 0;

    /* get exe_file ptr and abs_filepath */
    struct file* exe_file = BPF_CORE_READ(task, mm, exe_file);
    if(!exe_file){
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] task->mm->exe_file: NULL", pid);
        bpf_ringbuf_discard(p_ringbuf, 0);
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] ringbuf discard, clear task info and return!", pid);
        goto clear_task_info;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] task->mm->exe_file: %p", pid, exe_file);        
    }

    char* pathname_p = get_path_str(__builtin_preserve_access_index(&exe_file->f_path));  // get absolute path
    if(!pathname_p){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] get_path_str failed!", pid);
        bpf_ringbuf_discard(p_ringbuf, 0);
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] ringbuf discard, clear task info and return!", pid);
        goto clear_task_info;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [do_handle_exit] get_path_str success. abs_filepath: %s", pid, pathname_p);
    }

    ret = bpf_core_read_str(&p_task_info->event.abs_filepath, sizeof(p_task_info->event.abs_filepath), pathname_p);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] read abs_filepath from pathname_p failed! ret: %ld", pid, ret);
        bpf_ringbuf_discard(p_ringbuf, 0);
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] ringbuf discard, clear task info and return!", pid);
        goto clear_task_info;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] read abs_filepath from pathname_p success.", pid);
    }

    /* get real launcher */
    get_real_launcher(p_task_info);

    /* to tell that EXIT event has been written to p_task_info successfully */
    p_task_info->event_history_flag = p_task_info->event_history_flag | FLAG_EXIT;
    
    ret = bpf_probe_read(p_ringbuf, sizeof(struct task_info), p_task_info);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] copy task_info to ringbuf failed, ret %ld", pid, ret);
        bpf_ringbuf_discard(p_ringbuf, 0);
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] ringbuf discard and return!", pid);
        goto clear_task_info;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] copy task_info to ringbuf success.", pid);
        goto submit_and_clear;
    }

submit_and_clear:
    /* send data to user-space for post-processing */
    bpf_ringbuf_submit(p_ringbuf, 0);
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] submit ringbuf success.", pid);

clear_task_info:
    /* delete record from map task_info */
    ret = bpf_map_delete_elem(&task_info, &pid);
    if (ret == 0) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_exit] delete task_info success.", pid);
    } else if (ret == -ENOENT) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_exit] delete task_info failed! Entry not exists! ret: %ld", pid, ret);
    } else {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_exit] delete task_info failed! ret: %ld", pid, ret);
    }

    return 0;       // exit probe, return value is not important
}

///////////////////////////////////////////////////////////////////
///////////////////////////  execve  //////////////////////////////

/* 
sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_enter_execve/format
name: sys_enter_execve
ID: 729
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:const char * filename;	offset:16;	size:8;	signed:0;
	field:const char *const * argv;	offset:24;	size:8;	signed:0;
	field:const char *const * envp;	offset:32;	size:8;	signed:0;

print fmt: "filename: 0x%08lx, argv: 0x%08lx, envp: 0x%08lx", ((unsigned long)(REC->filename)), ((unsigned long)(REC->argv)), ((unsigned long)(REC->envp))
 */
struct my_syscalls_enter_execve {
    unsigned short common_type;
    unsigned char common_flags;
    unsigned char common_preempt_count;
    int common_pid;

    int syscall_nr;
    void* filename_ptr;
    const char* const* argv_ptr;
    const char* const* envp_ptr;
};

statfunc long record_start_args(const struct my_syscalls_enter_execve* ctx) {

    long ret = 0;
    struct task_struct* task = (struct task_struct*)bpf_get_current_task();
    u64 pid = BPF_CORE_READ(task, tgid);

    /* create task_info */
    ret = create_task_info(task);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [record_start_args] create_task_info failed! ret: %ld, return!", pid, ret);
        return -1;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [record_start_args] create_task_info success.", pid);
    }

    /* lookup task_info */
    struct task_info* p_task_info = bpf_map_lookup_elem(&task_info, &pid);
    if (!p_task_info) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [record_start_args] lookup task_info created just now failed!", pid);
        return -2;
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [record_start_args] lookup task_info success.", pid);
    }

    /* update event type */
    p_task_info->event.type = EXECVE;

    /* update new comm in task_args */
    struct task_args* p_args = &p_task_info->args;
    __builtin_memset(p_args->comm, 0, TASK_COMM_LEN);  
    ret = bpf_probe_read_user_str(p_args->comm, sizeof(p_args->comm), ctx->filename_ptr);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [record_start_args] read comm failed! ret: %ld, return!", pid, ret);
        return -3;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [record_start_args] read comm success. comm: %s", pid, p_args->comm);
    }

    /* update new argv in task_args */
    const char* const* argv_ptr = ctx->argv_ptr;
    const char* ptr = NULL;    
    // __builtin_memset(p_args->argv, 0, TASK_ARGV_NUM * TASK_ARGV_LEN);   // over size of memset func
    for (int i = 0; i < TASK_ARGV_NUM; i++) {  // for verifier
        ptr = NULL;
        __builtin_memset(&p_args->argv[i * TASK_ARGV_LEN], 0, TASK_ARGV_LEN);
        
        ret = bpf_probe_read_user(&ptr, sizeof(ptr), &argv_ptr[i]);
        if (ret < 0) {
            BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [record_start_args] get argv_ptr failed! ret: %ld", pid, ret);
            break;
        } else {
            BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [record_start_args] get argv_ptr success! ptr: %p", pid, ptr);
        }

        if (ptr == NULL)
            break;

        ret = bpf_probe_read_user_str(&p_args->argv[i * TASK_ARGV_LEN], TASK_ARGV_LEN, ptr);
        if(ret < 0){
            BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [record_start_args] read argv failed! ret: %ld", pid, ret);
            break;
        }else{
            BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [record_start_args] read argv success. argv[%d]: %s", pid, i, &p_args->argv[i * TASK_ARGV_LEN]);
        }
    }

    /* lookup again for check*/
    // p_task_info = bpf_map_lookup_elem(&task_info, &pid);
    // if (!p_task_info) {
    //     bpf_printk("[pid:%5lu] [record_start_args] lookup task_info failed! return!", pid);
    //     return -1;
    // } else {
    //     bpf_printk("[pid:%5lu] [record_start_args] lookup task_info success.", pid);
    //     // print_task_args(&p_task_info->args);
    // }

    return 0;
}


/*
    y: process start args
    n: absolute path (too early to get it's abs path, can only get parent abs path)
 */
SEC("tp/syscalls/sys_enter_execve")
int tp_sys_enter_execve(struct my_syscalls_enter_execve* ctx) {
    u64 uid = bpf_get_current_uid_gid()&0xffffffff;
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;

    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_enter_execve] [uid: %lu], [tid: %lu]", pid, uid, tid);

    long ret = record_start_args(ctx);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [tp_sys_enter_execve] record_start_args failed! ret: %ld\n", pid, ret);
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [tp_sys_enter_execve] record_start_args success.\n", pid);
    }
    return 0;
}


/* 
sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_exit_execve/format
name: sys_exit_execve
ID: 728
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:long ret;	offset:16;	size:8;	signed:1;

print fmt: "0x%lx", REC->ret
 */

struct my_syscalls_exit_execve {
    unsigned short common_type;
    unsigned char common_flags;
    unsigned char common_preempt_count;
    int common_pid;

    int syscall_nr;
    long ret;           // execve 调用返回 -2 通常表示所指定的可执行文件路径不存在或无法访问，可能是由于文件路径错误、文件被删除、权限问题等引起的
};

SEC("tp/syscalls/sys_exit_execve")
int tp_sys_exit_execve(struct my_syscalls_exit_execve* ctx) {
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_execve] tid: %lu, ret: %ld\n", pid, tid, ctx->ret);
    return 0;
}


/* 
sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_enter_execveat/format
name: sys_enter_execveat
ID: 727
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:int fd;	offset:16;	size:8;	signed:0;
	field:const char * filename;	offset:24;	size:8;	signed:0;
	field:const char *const * argv;	offset:32;	size:8;	signed:0;
	field:const char *const * envp;	offset:40;	size:8;	signed:0;
	field:int flags;	offset:48;	size:8;	signed:0;

print fmt: "fd: 0x%08lx, filename: 0x%08lx, argv: 0x%08lx, envp: 0x%08lx, flags: 0x%08lx", ((unsigned long)(REC->fd)), ((unsigned long)(REC->filename)), ((unsigned long)(REC->argv)), ((unsigned long)(REC->envp)), ((unsigned long)(REC->flags))
 */

struct my_syscalls_enter_execveat {
    unsigned short common_type;
    unsigned char common_flags;
    unsigned char common_preempt_count;
    int common_pid;

    int syscall_nr;
    void* filename_ptr;
    const char* const* argv_ptr;
    const char* const* envp_ptr;
    unsigned long flags;
};

SEC("tp/syscalls/sys_enter_execveat")
int tp_sys_enter_execveat(struct my_syscalls_enter_execveat* ctx) {
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_enter_execveat] tid: %lu\n", pid, tid);
    return 0;
}


/* 
sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_exit_execveat/format
name: sys_exit_execveat
ID: 726
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:long ret;	offset:16;	size:8;	signed:1;

print fmt: "0x%lx", REC->ret
 */
struct my_syscalls_exit_execveat {
    unsigned short common_type;
    unsigned char common_flags;
    unsigned char common_preempt_count;
    int common_pid;

    int syscall_nr;
    long ret;
};

SEC("tp/syscalls/sys_exit_execveat")
int tp_sys_exit_execveat(struct my_syscalls_exit_execveat* ctx) {
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_execveat] tid: %lu, ret: %ld\n", pid, tid, ctx->ret);
    return 0;
}




/* 
yf@ubuntu:~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_exit_fork/format
name: sys_exit_fork
ID: 127
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:long ret;	offset:16;	size:8;	signed:1;

print fmt: "0x%lx", REC->ret
 */
struct my_syscalls_exit_fork {
    unsigned short common_type;
	unsigned char common_flags;
	unsigned char common_preempt_count;
	int common_pid;

	int __syscall_nr;
	long ret;
};

/* Triggered by new process only */
SEC("tp/syscalls/sys_exit_fork")
int tp_sys_exit_fork(struct my_syscalls_exit_fork *ctx) {
    u64 uid = bpf_get_current_uid_gid()&0xffffffff;
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;

    /* create process or thread ? */
    if (pid != tid) {       // create thread        
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_fork] [uid: %lu] Child thread create. [tid: %lu]", pid, uid, tid);
        return 0;
    } else {                // create process
        // BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_fork] [uid: %lu] Child process create. [tid: %lu]", pid, uid, tid);
    }

    /* create process */
    if(ctx->ret > 0){           // parent process
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_fork] [tid: %lu] [uid: %lu], [Parent], [subprocess pid: %ld].", pid, tid, uid, ctx->ret);
        return 0;
    }else if(ctx->ret == 0){    // child process
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_fork] [tid: %lu] [uid: %lu], [Son].", pid, tid, uid);
    }

    /* son process */
    long ret = do_handle_newproc(FORK);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [tp_sys_exit_fork] do_handle_newproc [FORK] failed! ret %ld\n", pid, ret);
        return -1;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [tp_sys_exit_fork] do_handle_newproc [FORK] success.\n", pid);
    }

    return 0;
}

/* 
yf@ubuntu:~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_exit_vfork/format
name: sys_exit_vfork
ID: 125
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:long ret;	offset:16;	size:8;	signed:1;

print fmt: "0x%lx", REC->ret
 */

struct my_syscalls_exit_vfork {
    unsigned short common_type;
	unsigned char common_flags;
	unsigned char common_preempt_count;
	int common_pid;

	int __syscall_nr;
	long ret;
};

/* Triggered by new process only */
SEC("tp/syscalls/sys_exit_vfork")
int tp_sys_exit_vfork(struct my_syscalls_exit_vfork *ctx) {
    u64 uid = bpf_get_current_uid_gid()&0xffffffff;
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;

    /* create process or thread ? */
    if (pid != tid) {       // create thread        
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_vfork] [uid: %lu] Child thread create. [tid: %lu]", pid, uid, tid);
        return 0;
    } else {                // create process
        // BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_vfork] [uid: %lu] Child process create. [tid: %lu]", pid, uid, tid);
    }

    /* create process */
    if(ctx->ret > 0){           // parent process
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_vfork] [tid: %lu] [uid: %lu], [Parent], [subprocess pid: %ld].", pid, tid, uid, ctx->ret);
        return 0;
    }else if(ctx->ret == 0){    // child process
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_vfork] [tid: %lu] [uid: %lu], [Son].", pid, tid, uid);
    }

    /* son process */
    long ret = do_handle_newproc(VFORK);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [tp_sys_exit_vfork] do_handle_newproc [VFORK] failed! ret %ld\n", pid, ret);
        return -1;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [tp_sys_exit_vfork] do_handle_newproc [VFORK] success.\n", pid);
    }

    return 0;
}


/* 
yf@ubuntu:~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_enter_clone/format
name: sys_enter_clone
ID: 124
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:unsigned long clone_flags;	offset:16;	size:8;	signed:0;
	field:unsigned long newsp;	offset:24;	size:8;	signed:0;
	field:int * parent_tidptr;	offset:32;	size:8;	signed:0;
	field:int * child_tidptr;	offset:40;	size:8;	signed:0;
	field:unsigned long tls;	offset:48;	size:8;	signed:0;

print fmt: "clone_flags: 0x%08lx, newsp: 0x%08lx, parent_tidptr: 0x%08lx, child_tidptr: 0x%08lx, tls: 0x%08lx", ((unsigned long)(REC->clone_flags)), ((unsigned long)(REC->newsp)), ((unsigned long)(REC->parent_tidptr)), ((unsigned long)(REC->child_tidptr)), ((unsigned long)(REC->tls))

yf@ubuntu:~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_exit_clone/format
name: sys_exit_clone
ID: 123
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:long ret;	offset:16;	size:8;	signed:1;

print fmt: "0x%lx", REC->ret


 */


struct my_syscalls_exit_clone {
    unsigned short common_type;
	unsigned char common_flags;
	unsigned char common_preempt_count;
	int common_pid;

	int __syscall_nr;
	long ret;
};

/* Triggered by new process only */
SEC("tp/syscalls/sys_exit_clone")
int tp_sys_exit_clone(struct my_syscalls_exit_clone *ctx) {
    u64 uid = bpf_get_current_uid_gid()&0xffffffff;
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;
    
    /* create process or thread ? */
    if (pid != tid) {       // create thread        
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_clone] [uid: %lu] Child thread create. [tid: %lu]", pid, uid, tid);
        return 0;
    } else {                // create process
        // BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_clone] [uid: %lu] Child process create. [tid: %lu]", pid, uid, tid);
    }

    /* create process */
    if(ctx->ret > 0){           // parent process
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_clone] [tid: %lu] [uid: %lu], [Parent], [subprocess pid: %ld].", pid, tid, uid, ctx->ret);
        return 0;
    }else if(ctx->ret == 0){    // child process
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sys_exit_clone] [tid: %lu] [uid: %lu], [Son].", pid, tid, uid);
    }

    /* son process */
    long ret = do_handle_newproc(CLONE);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [tp_sys_exit_clone] do_handle_newproc [CLONE] failed! ret %ld\n", pid, ret);
        return -1;
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [tp_sys_exit_clone] do_handle_newproc [CLONE] success.\n", pid);
    }

    return 0;
}

/*
    n: process start args
    y: absolute path
 */
// SEC("tp/sched/sched_process_exec")
// SEC("raw_tp/sched_process_exec")
// int tp_sched_sched_process_exec(struct trace_event_raw_sched_process_exec* ctx) {
// // int BPF_PROG(tp_sched_sched_process_exec, u32 __data_loc_filename, pid_t pid_0) {
//     // u64 id = bpf_get_current_pid_tgid();
//     // u64 pid = id >> 32;
//     // u64 tid = id & 0xffffffff;
//     // bpf_printk("Entering tp_sched_sched_process_exec, pid %lu", pid);
//     // get_abs_path_by_bpf_d_path("tp_sched_sched_process_exec");       // error: call bpf_d_path#147: helper call is not allowed in probe
//     // do_handle_exec("tp_sched_sched_process_exec");
//     return 0;
// }


/*  Triggered by new process or new thread.
    Unable to distinguish between process and thread.
*/
SEC("tp/sched/sched_process_fork")
// SEC("raw_tp/sched_process_fork")
int tp_sched_sched_process_fork(struct trace_event_raw_sched_process_fork* fork_ctx) {
// int BPF_PROG(tp_sched_sched_process_fork, struct trace_event_raw_sched_process_fork* fork_ctx) {
    u64 uid = bpf_get_current_uid_gid()&0xffffffff;
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;

    /* [tp_sched_sched_process_fork] [tid: 7916] [uid: 1000]. [parent_pid: 7916, comm: test_semaphore] [child_pid: 7917, comm: test_semaphore] */
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [tp_sched_sched_process_fork] [tid: %lu] [uid: %lu]. [parent_tid: %ld, comm: %s] [child_tid: %ld, comm: %s]", 
                pid, tid, uid, fork_ctx->parent_pid, fork_ctx->parent_comm, fork_ctx->child_pid, fork_ctx->child_comm);

    return 0;
}


/////////////////////////////////////////////////////////////////
///////////////////////////  LSM   //////////////////////////////

// 监视进程执行 lsm.s表示 sleepable LSM， bpf_ima_file_hash函数需要
SEC("lsm.s/bprm_creds_for_exec")
int BPF_PROG(bpf_lsm_bprm_creds_for_exec, struct linux_binprm *bprm) {
    u64 uid = bpf_get_current_uid_gid()&0xffffffff;
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;
    
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [bpf_lsm_bprm_creds_for_exec] tid: %lu, uid: %lu", pid, tid, uid);

    long ret = do_handle_exec(bprm);
    if(ret == -EPERM){
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [bpf_lsm_bprm_creds_for_exec] do_handle_exec() ret %ld: Execute reject!\n", pid, ret);
        return -EPERM;
    }else if(ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [bpf_lsm_bprm_creds_for_exec] do_handle_exec() failed, ret %ld\n", pid, ret);
    }else{
        BPF_LOG(BPF_LOG_SUCCESS, "[SUCCESS] [pid:%5lu] [bpf_lsm_bprm_creds_for_exec] do_handle_exec() ret %ld: Execute OK!\n", pid, ret);
    }

    return 0;
}

// SEC("lsm/task_free")
// int BPF_PROG(bpf_lsm_task_free, struct task_struct *task) {
//     u64 uid = (u64)task->cred->uid.val;
//     u64 tid = BPF_CORE_READ(task, pid);
//     u64 pid = BPF_CORE_READ(task, tgid);

//     /* Child thread exits */
//     if (pid != tid) {
//         BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [bpf_lsm_task_free] [uid: %lu] Child thread exits. [tid: %lu]", pid, uid, tid);
//         return 0;
//     }

//     /* Main thread exits */
//     BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [bpf_lsm_task_free] [uid: %lu] Main thread exiting. [tid: %lu]", pid, uid, tid);
//     do_handle_exit(task);
//     BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [bpf_lsm_task_free] do_handle_exit end.\n", pid);

//     return 0;
// }



// SEC("lsm.s/task_alloc")
// int BPF_PROG(bpf_lsm_task_alloc, struct task_struct *task, unsigned long clone_flags) {
//     u64 uid = bpf_get_current_uid_gid()&0xffffffff;
//     u64 id = bpf_get_current_pid_tgid();
//     u64 pid = id >> 32;
//     u64 tid = id & 0xffffffff;
    
//     bpf_printk("[pid:%5lu] [bpf_lsm_task_alloc] tid: %lu, uid: %lu", pid, tid, uid);

//     return 0;
// }



/////////////////////////////////////////////////////////////////
///////////////////////////  exit  //////////////////////////////

/*
    note: struct pt_regs *ctx 从未成功使用 :(
 */

/* 官方推荐， fentry_do_exit 总是紧跟在 kprobe_do_exit 之后触发
    y: absolute path
*/
SEC("fentry/do_exit")
int BPF_PROG(fentry_do_exit) {
    struct task_struct *task = (struct task_struct *)bpf_get_current_task();
    u64 uid = bpf_get_current_uid_gid()&0xffffffff;
    u64 id = bpf_get_current_pid_tgid();
    u64 pid = id >> 32;
    u64 tid = id & 0xffffffff;

    /* Child thread exits */
    if (pid != tid) {
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [fentry_do_exit] [uid: %lu] Child thread exits. [tid: %lu]", pid, uid, tid);
        return 0;
    }

    /* Main thread exits */
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [fentry_do_exit] [uid: %lu] Main thread exiting. [tid: %lu]", pid, uid, tid);
    do_handle_exit(task);
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [fentry_do_exit] do_handle_exit end.\n", pid);

    return 0;
}














































/////////////////////////////////////////////////////////////////
///////////////////////////  packet xmit   //////////////////////////////
// #include <linux/if_ether.h>
// #include <linux/ip.h>
// #include <arpa/inet.h>
// #define ETH_P_IP	0x0800		/* Internet Protocol packet	*/
// #ifndef MY_IF_ETHER_H
// #define MY_IF_ETHER_H
// #include <linux/if_ether.h>
// #include <arpa/inet.h>

// SEC("fentry/__dev_queue_xmit")
// // int kprobe__dev_queue_xmit(struct pt_regs *ctx) {
// int BPF_PROG(kprobe__dev_queue_xmit, struct sk_buff *pskb, struct net_device *sb_dev) {    // 使用 BPF_PROG/BPF_KPROBE，直接获取参数

//     // return 0;

//     // struct sk_buff *pskb = (struct sk_buff *)PT_REGS_PARM1(ctx);
//     u32 pid = bpf_get_current_pid_tgid() >> 32;

//     bpf_printk("PID %u sent a packet, pskb: %p\n", pid, pskb);

//     if (NULL == pskb) {     // 在访问 skb 数据之前执行空指针检查
//         bpf_printk("pskb is NULL\n");
//         return 0;
//     }
//     // 现在可以安全地访问 skb->data   
     
//     struct ethhdr* pkt_data = NULL;
//     pkt_data = (struct ethhdr *)pskb->data;     // 在fentry类型下可以使用->运算符，通过结构体指针，直接访问结构体中的成员；kprobe类型下不行，必须通过 BPF_CORE_READ
//     // if (BPF_CORE_READ_INTO(&pkt_data, pskb, data) != 0) {   // bpf_probe_read_kernel((void *)(&pkt_data), sizeof(*(&pkt_data)), (const void *)__builtin_preserve_access_index(&((typeof((pskb)))((pskb)))->data));
//     //     bpf_printk("从用户空间读取 pskb->data 指针数值 失败\n");
//     //     return 0;
//     // }

//     // ethernet layer
//     struct ethhdr eth = {};
//     if (bpf_core_read(&eth, sizeof(eth), pkt_data) != 0) {
//         bpf_printk("从用户空间读取 pkt_data 指向的数据内容 失败\n");
//         return 0;
//     }
    
//     // bpf_printk("eth.h_proto = 0x%04x, %02x %02x %02x %02x %02x %02x ->\n", eth.h_proto,  
//     //             eth.h_source[0], eth.h_source[1], eth.h_source[2], eth.h_source[3], eth.h_source[4], eth.h_source[5]);

//     // bpf_printk("%02x %02x %02x %02x %02x %02x\n", 
//     //             eth.h_dest[0], eth.h_dest[1], eth.h_dest[2], eth.h_dest[3], eth.h_dest[4], eth.h_dest[5]);
    
//     if (eth.h_proto != 0x0008) {
//         // bpf_printk("PID %u sent a non-IP packet\n", pid);
//         return 0;
//     } 
    
//     // ip layer
//     struct iphdr *ip = (struct iphdr *)(pkt_data + 1);
//     u8 protocol = BPF_CORE_READ(ip, protocol);
//     u32 saddr = BPF_CORE_READ(ip, saddr);
//     u32 daddr = BPF_CORE_READ(ip, daddr);
//     if(protocol == IPPROTO_ICMP) {
//         bpf_printk("PID %u sent an IP packet, %08x --> %08x, Protocol: %u\n", pid, saddr, daddr, protocol);
//     }
    
//     return 0;
// }
// #endif




/////////////////////////////////////////////////////////////////
///////////////////////////  uprobe   ///////////////////////////

// #define TASK_COMM_LEN 16
// #define MAX_LINE_SIZE 80

// /* Format of u[ret]probe section definition supporting auto-attach:
//  * u[ret]probe/binary:function[+offset]
//  *
//  * binary can be an absolute/relative path or a filename; the latter is resolved to a
//  * full binary path via bpf_program__attach_uprobe_opts.
//  *
//  * Specifying uprobe+ ensures we carry out strict matching; either "uprobe" must be
//  * specified (and auto-attach is not possible) or the above format is specified for
//  * auto-attach.
//  */
// SEC("uretprobe//bin/bash:readline")
// int BPF_KRETPROBE(printret, const void *ret)
// {
//  char str[MAX_LINE_SIZE];
//  char comm[TASK_COMM_LEN];
//  u32 pid;

//  if (!ret)
//   return 0;

//  bpf_get_current_comm(&comm, sizeof(comm));

//  pid = bpf_get_current_pid_tgid() >> 32;
//  bpf_probe_read_user_str(str, sizeof(str), ret);

//  bpf_printk("PID %d (%s) read: %s ", pid, comm, str);

//  return 0;
// };



/////////////////////////////////////////////////////////////////
////////////////////////// tail calls ///////////////////////////
// SEC("raw_tracepoint/sys_exit")
// int prog1(struct bpf_raw_tracepoint_args *ctx) {
//     int id = ctx->args[1];      // syscall number
//     if(id == 59){               // execve
//         bpf_printk("Entering prog1 syscall id: %d", id);
//     }
//     return 0;
// }

// SEC("kprobe/__x64_sys_execve")
// int prog1(struct my_do_execve *ctx) {
//     bpf_printk("Entering prog1");
//     return 0;
// }

// SEC("tp/syscalls/sys_enter_execve")
// int prog1(struct my_syscalls_enter_execve* ctx) {
//     bpf_printk("Entering prog1");
//     return 0;
// }

// SEC("fentry/do_exit")
// int prog1(struct pt_regs *ctx) {
//     bpf_printk("Entering prog1");
//     return 0;
// }

// SEC("ksyscall/exit")
// int prog1(void* ctx) {
//     bpf_printk("Entering prog1");
//     return 0;
// }

