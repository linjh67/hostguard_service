/*
 * @Author: JiaHao
 * @Date: 2024-05-13 14:32:42
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-06-21 15:33:22
 * @FilePath: /hostguard_linux/submodule/bpf-c/udisk_monitor.bpf.c
 * @Description: 
 * 
 * Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#include "vmlinux.h"  // must before <bpf/bpf_helpers.h>, or will -> bpf_helper_defs.h:292:95: error: unknown type name '__u64'
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include "monitor/udisk_monitor_basic.h"

char LICENSE[] SEC("license") = "Dual BSD/GPL";


struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key, u32);
    __type(value, struct mount_info);    // to tmp store info of the current mount, over 512 bytes limit
} tmp_mount_info SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1024);
    __type(key, u64);
    __type(value, struct mount_info);
} mount_info SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1024*1024);
    __type(key, struct kernel_udisk_whitelist_key);
    __type(value, struct kernel_udisk_whitelist_value);
} kernel_udisk_whitelist SEC(".maps");


struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 32 * 1024 * 1024);
} rb SEC(".maps");



struct my_syscalls_enter_mount {
    unsigned short common_type;
    unsigned char common_flags;
    unsigned char common_preempt_count;
    int common_pid;

    int syscall_nr;
    char * dev_name;
    char * dir_name;
    char * type;
    unsigned long flags;
    void * data;
};

struct my_syscalls_exit_mount {
    unsigned short common_type;
	unsigned char common_flags;
	unsigned char common_preempt_count;
	int common_pid;

	int __syscall_nr;
	long ret;
};

struct my_syscalls_enter_umount {
    unsigned short common_type;
	unsigned char common_flags;
	unsigned char common_preempt_count;
	int common_pid;

	int __syscall_nr;
	char * name;
	int flags;
};

struct my_syscalls_exit_umount {
    unsigned short common_type;
	unsigned char common_flags;
	unsigned char common_preempt_count;
	int common_pid;

	int __syscall_nr;
	long ret;
};



statfunc long print_mount_info(struct mount_info* p_mount_info) {

    /* mount syscall args */
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [print_mount_info] [dev_name: %s], [path_name: %s], [type: %s], [flags: 0x%08lx]", 
        p_mount_info->pid, 
        p_mount_info->args.dev_name, 
        p_mount_info->args.path_str, 
        p_mount_info->args.mount_type, 
        p_mount_info->args.flags
    );

    /* mount event info */
    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [print_mount_info] [event_type: %d], [mode_in_request: %d], [mode_in_udisk_whitelist: %d], [isLegal: %d], [react: %d], [syscall_ret: %ld]", 
        p_mount_info->pid, 
        p_mount_info->event.event_type, 
        p_mount_info->event.mode_in_request, 
        p_mount_info->event.mode_in_udisk_whitelist, 
        p_mount_info->event.isLegal, 
        p_mount_info->event.react,
        p_mount_info->event.syscall_ret
    );
    
    return 0;
}


/* get first ancestry task uid, not 0(root) */
statfunc long get_real_launcher(struct mount_info* p_mount_info) {
    int iter_count = 0;
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    struct task_struct *task = (struct task_struct *)bpf_get_current_task();

    u64 launcher_pid = (u64)BPF_CORE_READ(task, tgid);
    uid_t launcher_uid = BPF_CORE_READ(task, cred, uid).val;
    uid_t launcher_euid = BPF_CORE_READ(task, cred, euid).val;
    
    /* 追溯父进程，查找真正的 UID */
    while (task && iter_count < PARENT_TASK_ITER_MAX_COUNT) {
        uid_t tmp_uid = BPF_CORE_READ(task, cred, uid).val;
        if (tmp_uid != 0) {
            launcher_pid = (u64)BPF_CORE_READ(task, tgid);
            launcher_uid = tmp_uid;
            launcher_euid = BPF_CORE_READ(task, cred, euid).val;            
            break;
        }
        task = BPF_CORE_READ(task, real_parent);
        iter_count++;
    }

    p_mount_info->event.launcher.pid = launcher_pid;
    p_mount_info->event.launcher.uid = launcher_uid;
    p_mount_info->event.launcher.euid = launcher_euid;

    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [get_real_launcher] [launcher_pid: %lu], [launcher_uid: %u], [launcher_euid: %u], [iter_count: %d]", 
                            pid, launcher_pid, launcher_uid, launcher_euid, iter_count);

    return 0;
}

/* 比对白名单 */
statfunc bool filter_mount(struct mount_info* p_mount_info) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    
    p_mount_info->event.react = DENY_MOUNT;
    p_mount_info->event.isLegal = false;    
    
    /* fill whitelist_key */
    struct kernel_udisk_whitelist_key w_key = {0};
    long ret = bpf_probe_read_str(w_key.dev_name, sizeof(w_key.dev_name), p_mount_info->args.dev_name);
    if(ret < 0){      
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [filter_mount] read dev_name FAILED! ret: %ld", pid, ret);
        return false;
    }

    /* lookup whitelist_value */
    struct kernel_udisk_whitelist_value* p_w_value = bpf_map_lookup_elem(&kernel_udisk_whitelist, &w_key);
    if (!p_w_value) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [filter_mount] lookup [dev: %s] in kernel_udisk_whitelist FAILED!", pid, w_key.dev_name);
        return false;
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [filter_mount] lookup [dev: %s] in kernel_udisk_whitelist SUCCESS. w_value.mode: %d", pid, w_key.dev_name, p_w_value->mode);
    }

    /* record mode_in_udisk_whitelist */
    p_mount_info->event.mode_in_udisk_whitelist = p_w_value->mode;

    /* compare modes in request & whitelist. RW=2, RO=1 */
    if (p_mount_info->event.mode_in_request <= p_w_value->mode) {

        p_mount_info->event.react = ALLOW_MOUNT;
        p_mount_info->event.isLegal = true;
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [filter_mount] [dev_name: %s] Mount mode is legal. [Req: %d] <= [Whitelist: %d]", 
            pid, p_mount_info->args.dev_name, p_mount_info->event.mode_in_request, p_mount_info->event.mode_in_udisk_whitelist
        );
        return true;
    } else {
        p_mount_info->event.react = DENY_MOUNT;
        p_mount_info->event.isLegal = false;
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [filter_mount] [dev_name: %s] Mount mode not legal! [Req: %d] > [Whitelist: %d]. DENY_MOUNT!", 
            pid, p_mount_info->args.dev_name, p_mount_info->event.mode_in_request, p_mount_info->event.mode_in_udisk_whitelist
        );
        return false;
    }
}

/* 比对白名单 */
statfunc bool filter_umount(struct mount_info* p_mount_info) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;

    p_mount_info->event.mode_in_udisk_whitelist = DEFAULT_MOUNT_MODE;
    p_mount_info->event.react = WARNING_UMOUNT;
    p_mount_info->event.isLegal = false;
    
    /* fill whitelist_key */
    struct kernel_udisk_whitelist_key w_key = {0};
    long ret = bpf_probe_read_str(w_key.dev_name, sizeof(w_key.dev_name), p_mount_info->args.dev_name);
    if(ret < 0){    
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [filter_umount] read dev_name FAILED! ret: %ld", pid, ret);
        return false;
    }

    /* lookup whitelist_value */
    struct kernel_udisk_whitelist_value* p_w_value = bpf_map_lookup_elem(&kernel_udisk_whitelist, &w_key);
    if (!p_w_value) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [filter_umount] lookup [dev: %s] in kernel_udisk_whitelist FAILED!", pid, w_key.dev_name);
        return false;
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [filter_umount] lookup [dev: %s] in kernel_udisk_whitelist SUCCESS. w_value.mode: %d", pid, w_key.dev_name, p_w_value->mode);
    }

    /* record mode_in_udisk_whitelist */
    p_mount_info->event.mode_in_udisk_whitelist = p_w_value->mode;
    p_mount_info->event.react = ALLOW_UMOUNT;
    p_mount_info->event.isLegal = true;
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [filter_umount] [dev_name: %s] Mount mode is legal. [Req: %d] <= [Whitelist: %d]", 
        pid, p_mount_info->args.dev_name, p_mount_info->event.mode_in_request, p_mount_info->event.mode_in_udisk_whitelist
    );

    return true;
}

statfunc long do_handle_lsm_mount(const char *dev_name, const struct path *path, 
                                const char *type, unsigned long flags, void *data) {
    long ret = 0;
    u64 pid_tid = bpf_get_current_pid_tgid();
    u64 pid = pid_tid >> 32;

    /* check */
    if (dev_name == NULL) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] [dev_name: NULL], return!", pid);
        return -2;
    }
    
    /* /dev/sdx */
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] [dev_name: %s]", pid, dev_name);     
    
    /* BPF_MAP_TYPE_PERCPU_ARRAY */
    u32 zero = 0;
    struct mount_info* p_tmp_mount_info = bpf_map_lookup_elem(&tmp_mount_info, &zero);
    if (!p_tmp_mount_info){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_mount] lookup tmp_mount_info FAILED!", pid);
        return -3;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] lookup tmp_mount_info SUCCESS.", pid);
    }

    /* clear memory */
    __builtin_memset(p_tmp_mount_info, 0, sizeof(struct mount_info));
    p_tmp_mount_info->pid = pid;
    p_tmp_mount_info->event.event_type = MOUNT;
    p_tmp_mount_info->event.isLegal = false;
    p_tmp_mount_info->event.mode_in_request = DEFAULT_MOUNT_MODE;
    p_tmp_mount_info->event.mode_in_udisk_whitelist = DEFAULT_MOUNT_MODE;
    p_tmp_mount_info->event.react = DENY_MOUNT;
    p_tmp_mount_info->event.syscall_ret = -MOUNT_EPERM;        /* 0:SUCCESS    1:EPERM（操作不允许）  2:ENOENT（文件或目录不存在）*/
    p_tmp_mount_info->args.flags = flags;

    /* copy dev_name */
    ret = bpf_core_read_str(p_tmp_mount_info->args.dev_name, sizeof(p_tmp_mount_info->args.dev_name), dev_name);
    if (ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_mount] read dev_name FAILED: ret %d, return!", pid, ret);
        return -4;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] read dev_name SUCCESS: ret %d, [dev_name_str: %s]", pid, ret, p_tmp_mount_info->args.dev_name);
    }   

    /* check if it is U disk: /dev/sd* (必须要复制到内核空间，否则无法strncmp) */
    ret = bpf_strncmp(p_tmp_mount_info->args.dev_name, 7, "/dev/sd");
    if(ret != 0){
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] [dev_name: %s] is not a udisk, return!", pid, p_tmp_mount_info->args.dev_name);
        return -MOUNT_ENOTUDISK;
    }

    /* get abs_path */
    ret = bpf_d_path(path, p_tmp_mount_info->args.path_str, sizeof(p_tmp_mount_info->args.path_str));
    if (ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_mount] get path_str FAILED: ret %d", pid, ret);
        // return -6;
    } else {        
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] get path_str SUCCESS: ret %d, [path_str: %s]", pid, ret, p_tmp_mount_info->args.path_str);
    }

    /* get mount type */
    if (type != NULL) {
        ret = bpf_core_read_str(p_tmp_mount_info->args.mount_type, sizeof(p_tmp_mount_info->args.mount_type), type);
        if (ret < 0) {
            BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_mount] read mount_type FAILED: ret %d, return!", pid, ret);
            // return -7;
        }else{
            BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] read mount_type SUCCESS: ret %d, [mount_type: %s]", pid, ret, p_tmp_mount_info->args.mount_type);
        }
    }
    
    /* get readonly flag */
    p_tmp_mount_info->event.mode_in_request = (flags & MS_RDONLY) ? MOUNT_READ_ONLY : MOUNT_READ_WRITE;

    /* compare with udisk whitelist */
    filter_mount(p_tmp_mount_info);

    /* get real launcher */
    get_real_launcher(p_tmp_mount_info);

    /* print mount info */
    // print_mount_info(p_tmp_mount_info);

    /* record into map mount_info */
    ret = bpf_map_update_elem(&mount_info, &pid_tid, p_tmp_mount_info, BPF_ANY);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_mount] update mount_info FAILED! ret: %ld", pid, ret);
        return -8;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_mount] update mount_info SUCCESS.", pid);
    }

    /* check react */
    if (p_tmp_mount_info->event.react == DENY_MOUNT) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [do_handle_lsm_mount] [dev_name: %s] [mode: %d], Mount DENY!", pid, p_tmp_mount_info->args.dev_name, p_tmp_mount_info->event.mode_in_request);
        return -MOUNT_EPERM;
    }

    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_lsm_mount] [dev_name: %s] [mode: %d]: Mount ALLOW.", pid, p_tmp_mount_info->args.dev_name, p_tmp_mount_info->event.mode_in_request);
    return 0;
}


statfunc long do_handle_lsm_umount(struct vfsmount *mnt, int flags) {
    long ret = 0;
    u64 pid_tid = bpf_get_current_pid_tgid();
    u64 pid = pid_tid >> 32;
    const char *dev_name = BPF_CORE_READ(mnt, mnt_sb, s_id);    /* sdx, not include prefix "/dev/" */

    /* check */
    if (dev_name == NULL) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_umount] [dev_name: NULL], return!", pid);
        return -2;
    }

    /* sdx */
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_umount] [dev_name: %s]", pid, dev_name);
    
    /* BPF_MAP_TYPE_PERCPU_ARRAY */
    u32 zero = 0;
    struct mount_info* p_tmp_mount_info = bpf_map_lookup_elem(&tmp_mount_info, &zero);
    if (!p_tmp_mount_info){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_umount] lookup tmp_mount_info FAILED!", pid);
        return -3;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_umount] lookup tmp_mount_info SUCCESS.", pid);
    }

    /* clear memory */
    __builtin_memset(p_tmp_mount_info, 0, sizeof(struct mount_info));
    p_tmp_mount_info->pid = pid;
    p_tmp_mount_info->event.event_type = UMOUNT;
    p_tmp_mount_info->event.isLegal = false;
    p_tmp_mount_info->event.mode_in_request = DEFAULT_MOUNT_MODE;
    p_tmp_mount_info->event.mode_in_udisk_whitelist = DEFAULT_MOUNT_MODE;
    p_tmp_mount_info->event.react = WARNING_UMOUNT;
    p_tmp_mount_info->event.syscall_ret = UMOUNT_EPERM;        /* 0:SUCCESS    1:EPERM（操作不允许）  2:ENOENT（文件或目录不存在）*/
    p_tmp_mount_info->args.flags = flags;

    /* 挂载的设备名称 (sdx, add prefix "/dev/") */
    p_tmp_mount_info->args.dev_name[0] = '/';
    p_tmp_mount_info->args.dev_name[1] = 'd';
    p_tmp_mount_info->args.dev_name[2] = 'e';
    p_tmp_mount_info->args.dev_name[3] = 'v';
    p_tmp_mount_info->args.dev_name[4] = '/';
    ret = bpf_core_read_str(&p_tmp_mount_info->args.dev_name[5], sizeof(p_tmp_mount_info->args.dev_name)-5, dev_name);
    if (ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_umount] read dev_name FAILED: ret %d, return!", pid, ret);
        return -4;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_umount] read dev_name SUCCESS: ret %d, dev_name_str: %s", pid, ret, p_tmp_mount_info->args.dev_name);
    }   

    /* 检查挂载的设备是否为 U 盘: /dev/sd*   (必须要复制到内核空间，否则无法strncmp) */
    ret = bpf_strncmp(p_tmp_mount_info->args.dev_name, 7, "/dev/sd");
    if(ret != 0){
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_umount] [dev_name: %s] is not a udisk, return!", pid, p_tmp_mount_info->args.dev_name);
        return -UMOUNT_ENOTUDISK;
    }

    /* check if follow symlink on umount or not */
    if (flags == UMOUNT_NOFOLLOW) {
        /* NOT real UMOUNT */
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_umount] [dev_name: %s] [flags: UMOUNT_NOFOLLOW], return!", pid, p_tmp_mount_info->args.dev_name);
        return -UMOUNT_ENOFOLLOW;
    }

    /* compare with udisk whitelist */
    filter_umount(p_tmp_mount_info);

    /* get real launcher */
    get_real_launcher(p_tmp_mount_info);

    /* print mount info */
    // print_mount_info(p_tmp_mount_info);

    /* record into map mount_info */
    ret = bpf_map_update_elem(&mount_info, &pid_tid, p_tmp_mount_info, BPF_ANY);
    if (ret != 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_lsm_umount] update mount_info FAILED! ret: %ld", pid, ret);
        return -6;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_lsm_umount] update mount_info SUCCESS.", pid);
    }

    BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [do_handle_lsm_umount] [dev_name: %s]: Umount ALLOW!", pid, p_tmp_mount_info->args.dev_name);

    return 0;
}

statfunc long send_mount_info_to_user_space(struct mount_info* p_mount_info) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    long ret = 0;

    /* reserve sample from BPF ringbuf */
    struct mount_info* p_ringbuf = bpf_ringbuf_reserve(&rb, sizeof(struct mount_info), 0);
    if (!p_ringbuf){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [send_mount_info_to_user_space] ringbuf_reserve FAILED! return!", pid);
        return -1;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [send_mount_info_to_user_space] ringbuf_reserve SUCCESS.", pid);
    }

    ret = bpf_probe_read(p_ringbuf, sizeof(struct mount_info), p_mount_info);
    if(ret < 0){
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [send_mount_info_to_user_space] copy mount_info to ringbuf FAILED, ret %ld", pid, ret);
        bpf_ringbuf_discard(p_ringbuf, 0);
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [send_mount_info_to_user_space] ringbuf discard and return!", pid);
        return -2;
    }else{
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [send_mount_info_to_user_space] copy mount_info to ringbuf SUCCESS.", pid);
    }

    /* successfully submit it to user-space for post-processing */
    bpf_ringbuf_submit(p_ringbuf, 0);
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [send_mount_info_to_user_space] submit ringbuf SUCCESS.", pid);

    return 0;
}

statfunc long clear_mount_info(u64 pid_tid) {
    u64 pid = pid_tid >> 32;
    long ret = 0;

    /* delete record from map mount_info */
    ret = bpf_map_delete_elem(&mount_info, &pid_tid);
    if (ret == 0) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [clear_mount_info] delete mount_info success.", pid);
    } else if (ret == -MOUNT_ENOENT) {
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [clear_mount_info] delete mount_info failed! Entry not exists! ret: %ld", pid, ret);
    } else {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [clear_mount_info] delete mount_info failed! ret: %ld", pid, ret);
    }

    return 0;
}

statfunc long do_handle_syscall_exit_mount(struct my_syscalls_exit_mount *ctx) { 

    long ret = 0;
    u64 pid_tid = bpf_get_current_pid_tgid();
    u64 pid = pid_tid >> 32;

    /* lookup mount_info created by lsm_mount */
    struct mount_info* p_mount_info = bpf_map_lookup_elem(&mount_info, &pid_tid);
    if (p_mount_info) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_syscall_exit_mount] lookup mount_info created by lsm_mount SUCCESS.", pid);        
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_syscall_exit_mount] lookup mount_info created by lsm_mount FAILED! return!", pid);
        return -MOUNT_ENOENT;
    }

    p_mount_info->event.syscall_ret = ctx->ret;

    /* print mount info */
    print_mount_info(p_mount_info);

    /* send mount info to user space */
    ret = send_mount_info_to_user_space(p_mount_info);
    if (ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_syscall_exit_mount] send_mount_info_to_user_space FAILED! ret: %ld", pid, ret);
    }

    /* clear entry in mount_info */
    ret = clear_mount_info(pid_tid);
    if (ret < 0 && ret != -MOUNT_ENOENT) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_syscall_exit_mount] clear_mount_info FAILED! ret: %ld", pid, ret);
    }

    return 0;
}


statfunc long do_handle_syscall_exit_umount(struct my_syscalls_exit_umount *ctx) { 

    long ret = 0;
    u64 pid_tid = bpf_get_current_pid_tgid();
    u64 pid = pid_tid >> 32;

    /* lookup mount_info created by lsm_umount */
    struct mount_info* p_mount_info = bpf_map_lookup_elem(&mount_info, &pid_tid);
    if (p_mount_info) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_syscall_exit_umount] lookup mount_info created by lsm_umount SUCCESS.", pid);        
    } else {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [do_handle_syscall_exit_umount] lookup mount_info created by lsm_umount FAILED! return!", pid);
        return -UMOUNT_ENOENT;
    }

    p_mount_info->event.syscall_ret = ctx->ret;

    /* print mount info */
    print_mount_info(p_mount_info);

    /* send mount info to user space */
    ret = send_mount_info_to_user_space(p_mount_info);
    if (ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_syscall_exit_umount] send_mount_info_to_user_space FAILED! ret: %ld", pid, ret);
    }

    /* clear entry in mount_info */
    ret = clear_mount_info(pid_tid);
    if (ret < 0 && ret != -MOUNT_ENOENT) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [do_handle_syscall_exit_umount] clear_mount_info FAILED! ret: %ld", pid, ret);
    }
    
    return 0;
}


SEC("lsm/sb_mount")
int BPF_PROG(bpf_lsm_sb_mount, const char *dev_name, const struct path *path, 
                                const char *type, unsigned long flags, void *data) {

    u64 pid = bpf_get_current_pid_tgid() >> 32;
    if (dev_name == NULL) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [bpf_lsm_sb_mount] [dev_name: NULL], return!", pid);
        return 0;
    }

    long ret = do_handle_lsm_mount(dev_name, path, type, flags, data);

    /* allow udisk mount */
    if(ret == 0) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [bpf_lsm_sb_mount] do_handle_lsm_mount() ret %ld: [dev_name: %s] Mount ALLOW!", pid, ret, dev_name);
        return 0;
    }

    /* not udisk dev */
    if(ret == -MOUNT_ENOTUDISK){
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [bpf_lsm_sb_mount] do_handle_lsm_mount() ret %ld(-MOUNT_ENOTUDISK), [dev_name: %s] not a udisk dev.", pid, ret, dev_name);
        return 0;
    }

    /* reject udisk mount */
    if(ret == -MOUNT_EPERM){
        BPF_LOG(BPF_LOG_WARNING, "[WARNING] [pid:%5lu] [bpf_lsm_sb_mount] do_handle_lsm_mount() ret %ld(-MOUNT_EPERM): [dev_name: %s] Mount reject!", pid, ret, dev_name);
        return -MOUNT_EPERM;
        // return 0;
    }

    /* real errors */
    if(ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [bpf_lsm_sb_mount] do_handle_lsm_mount() FAILED, ret %ld: [dev_name: %s]", pid, ret, dev_name);
        return 0;
    }

    return 0;
}



SEC("lsm/sb_umount")
int BPF_PROG(bpf_lsm_sb_umount, struct vfsmount *mnt, int flags) {

    long ret = 0;
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    
    const char *dev_name = BPF_CORE_READ(mnt, mnt_sb, s_id);
    if (dev_name == NULL) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [bpf_lsm_sb_umount] [dev_name: NULL], return!", pid);
        return 0;
    }

    ret = do_handle_lsm_umount(mnt, flags);
    
    /* allow udisk umount */
    if(ret == 0) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [bpf_lsm_sb_umount] do_handle_lsm_umount() [ret: %ld] Umount ALLOW!", pid, ret);
        return 0;
    }

    /* not udisk dev */
    if (ret == -MOUNT_ENOTUDISK) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [bpf_lsm_sb_umount] do_handle_lsm_umount() [ret: %ld (-MOUNT_ENOTUDISK)], not a udisk dev.", pid, ret);
        return 0;
    }

    /* Not follow symlink when umount */
    if(ret == -UMOUNT_ENOFOLLOW) {   
        BPF_LOG(BPF_LOG_INFO, "[  INFO ] [pid:%5lu] [bpf_lsm_sb_umount] do_handle_lsm_umount() [ret: %ld (-UMOUNT_ENOFOLLOW)]", pid, ret);
        return 0;
    }

    /* real errors */
    if(ret < 0) {
        BPF_LOG(BPF_LOG_ERROR, "[ ERROR ] [pid:%5lu] [bpf_lsm_sb_umount] do_handle_lsm_umount() FAILED, [ret: %ld]", pid, ret);
        return 0;
    }

    return 0;
}


///////////////////////////// Tracepoints /////////////////////////////////////

SEC("tp/syscalls/sys_enter_mount")
int tp_sys_enter_mount(struct my_syscalls_enter_mount *ctx) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;

    if (ctx->dev_name == NULL) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_enter_mount] [dev_name: NULL], return!", pid);
        return 0;
    }

    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_enter_mount] [name: %s] [path: %s] [type: %s] [flags: %lu]", 
                            pid, ctx->dev_name, ctx->dir_name, ctx->type, ctx->flags);
    return 0;
}

SEC("tp/syscalls/sys_exit_mount")
int tp_sys_exit_mount(struct my_syscalls_exit_mount *ctx) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_exit_mount] [ SYSCALL_MOUNT return: %d]", pid, ctx->ret);

    long ret = do_handle_syscall_exit_mount(ctx);
    if(ret == -MOUNT_ENOENT){    /* No such entry in map */
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_exit_mount] do_handle_syscall_exit_mount() ret %ld(-MOUNT_ENOENT): No such mount_info entry created by lsm_umount previously in map.", pid, ret);
    }

    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_exit_mount] MOUNT EVENT END!\n", pid); 

    return 0;
}


SEC("tp/syscalls/sys_enter_umount")
int tp_sys_enter_umount(struct my_syscalls_enter_umount *ctx) {

    u64 pid = bpf_get_current_pid_tgid() >> 32;
    if (ctx->name == NULL) {
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_enter_umount] [dev_name: NULL], return!", pid);
        return 0;
    }

    /* note: 
        1. ctx->name may be devname or path.
        2. However, since the a devname may be mounted at multiple paths at the same time, 
            usually programs should convert the devname to path before calling umount(2) to tell kernel explicitly
            which mount point should be umount.  
        3. Only when the devname is not mounted at any path, the ctx->name will be the devname.     
    */
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_enter_umount] [name: %s]", pid, ctx->name);
    return 0;
}

SEC("tp/syscalls/sys_exit_umount")
int tp_sys_exit_umount(struct my_syscalls_exit_umount *ctx) {
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_exit_umount] [ SYSCALL_UMOUNT return: %d]", pid, ctx->ret);

    long ret = do_handle_syscall_exit_umount(ctx);
    if(ret == -UMOUNT_ENOENT){       /* No such entry in map */
        BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_exit_umount] do_handle_syscall_exit_umount() ret %ld(-UMOUNT_ENOENT): No such mount_info entry created by lsm_umount previously in map.", pid, ret);
    }

    BPF_LOG(BPF_LOG_DEBUG, "[ DEBUG ] [pid:%5lu] [tp_sys_exit_umount] UMOUNT EVENT END!\n", pid); 

    return 0;
}





















/////////////////////////////////////////////////////////////////
///////////////////////////  mount //////////////////////////////

/* 
~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_enter_mount/format
name: sys_enter_mount
ID: 795
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:char * dev_name;	offset:16;	size:8;	signed:0;
	field:char * dir_name;	offset:24;	size:8;	signed:0;
	field:char * type;	offset:32;	size:8;	signed:0;
	field:unsigned long flags;	offset:40;	size:8;	signed:0;
	field:void * data;	offset:48;	size:8;	signed:0;

print fmt: "dev_name: 0x%08lx, dir_name: 0x%08lx, type: 0x%08lx, flags: 0x%08lx, data: 0x%08lx", ((unsigned long)(REC->dev_name)), ((unsigned long)(REC->dir_name)), ((unsigned long)(REC->type)), ((unsigned long)(REC->flags)), ((unsigned long)(REC->data))
 */

// struct my_syscalls_enter_mount {
//     unsigned short common_type;
//     unsigned char common_flags;
//     unsigned char common_preempt_count;
//     int common_pid;

//     int syscall_nr;
//     char * dev_name;
//     char * dir_name;
//     char * type;
//     unsigned long flags;
//     void * data;
// };



// SEC("tp/syscalls/sys_enter_mount")
// int tp_sys_enter_mount(struct my_syscalls_enter_mount *ctx)
// {
// #define MS_RDONLY	 1	/* Mount read-only */

//     bpf_printk("tp_sys_enter_mount: enter\n");

//     // 获取系统调用参数
//     char *dev_name = ctx->dev_name;
//     char *dir_name = ctx->dir_name;
//     char *type = ctx->type;
//     unsigned long flags = ctx->flags;
//     void *data = ctx->data;

//     char dev_name_str[100] = {0};
//     int ret = bpf_core_read_user_str(dev_name_str, 100, dev_name);
//     if (ret < 0) {
//         bpf_printk("tp_sys_enter_mount: bpf_core_read_user_str dev_name FAILED: ret %d\n", ret);
//         // ret = bpf_core_read_str(dev_name_str, 100, dev_name);
//         // if (ret < 0) {
//         //     bpf_printk("bpf_core_read_str dev_name FAILED: ret %d\n", ret);
//         // }else{
//         //     bpf_printk("bpf_core_read_str dev_name SUCCESS: ret %d\n", ret);
//         // }
//     }else{
//         bpf_printk("tp_sys_enter_mount: bpf_core_read_user_str dev_name SUCCESS: ret %d\n", ret);
//     }

//     char dir_name_str[100] = {0};
//     ret = bpf_core_read_user_str(dir_name_str, 100, dir_name);
//     if (ret < 0) {
//         bpf_printk("tp_sys_enter_mount: bpf_core_read_user_str dir_name FAILED: ret %d\n", ret);
//         // ret = bpf_core_read_str(dir_name_str, 100, dir_name);
//         // if (ret < 0) {
//         //     bpf_printk("bpf_core_read_str dir_name FAILED: ret %d\n", ret);
//         // }else{
//         //     bpf_printk("bpf_core_read_str dir_name SUCCESS: ret %d\n", ret);
//         // }
//     }else{
//         bpf_printk("tp_sys_enter_mount: bpf_core_read_user_str dir_name SUCCESS: ret %d\n", ret);
//     }

//     // 在这里对系统调用参数进行处理，可以使用打印语句进行调试
//     bpf_printk("tp_sys_enter_mount: dev_name: %s, dir_name: %s, type: 0x%08lx, flags: 0x%08lx, data: 0x%08lx\n",
//                dev_name, dir_name, type, flags, data);


//     // Modify the flags parameter
//     ret=bpf_strncmp(dev_name_str, 9, "/dev/sdb1");
//     if(ret!=0){
//         // Return 0 to continue executing the original function
//         return 0;
//     }

//     // bpf_printk("dev_name_str: %s, bpf_strncmp(dev_name_str, 9, \"/dev/sdb1\") = %d\n", dev_name_str, ret);
//     // flags = flags|MS_RDONLY; // For example, adding the MS_RDONLY flag
//     // ret = bpf_probe_write_user(&ctx->flags, &flags, sizeof(flags));
//     // if (ret != 0) {
//     //     bpf_printk("bpf_probe_write_user flags: 0x%08lx FAILED: ret %d\n", flags, ret);
//     // }else{
//     //     bpf_printk("bpf_probe_write_user flags: 0x%08lx SUCCESS: ret %d\n", flags, ret);
//     // }

//     // Return 0 to continue executing the original function
//     return 0;
// }


/* 
JiaHao@JiaHao-pc:~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_exit_mount/format
name: sys_exit_mount
ID: 833
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:long ret;	offset:16;	size:8;	signed:1;

print fmt: "0x%lx", REC->ret

 */

// struct my_syscalls_exit_mount {
//     unsigned short common_type;
// 	unsigned char common_flags;
// 	unsigned char common_preempt_count;
// 	int common_pid;

// 	int __syscall_nr;
// 	long ret;
// };
// SEC("tp/syscalls/sys_exit_mount")
// int tp_sys_exit_mount(struct pt_regs *ctx)
// {
//     bpf_printk("tp_sys_exit_mount: exit\n");
//     return 0;
// }

/* 
JiaHao@JiaHao-pc:~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_enter_umount/format
name: sys_enter_umount
ID: 838
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:char * name;	offset:16;	size:8;	signed:0;
	field:int flags;	offset:24;	size:8;	signed:0;

print fmt: "name: 0x%08lx, flags: 0x%08lx", ((unsigned long)(REC->name)), ((unsigned long)(REC->flags))
 */



// SEC("tp/syscalls/sys_enter_umount")
// int tp_sys_enter_umount(struct pt_regs *ctx)
// {
//     bpf_printk("tp_sys_enter_umount: entry\n");
//     return 0;
// }


/* 
JiaHao@JiaHao-pc:~$ sudo cat /sys/kernel/debug/tracing/events/syscalls/sys_exit_umount/format
[sudo] password for JiaHao: 
name: sys_exit_umount
ID: 837
format:
	field:unsigned short common_type;	offset:0;	size:2;	signed:0;
	field:unsigned char common_flags;	offset:2;	size:1;	signed:0;
	field:unsigned char common_preempt_count;	offset:3;	size:1;	signed:0;
	field:int common_pid;	offset:4;	size:4;	signed:1;

	field:int __syscall_nr;	offset:8;	size:4;	signed:1;
	field:long ret;	offset:16;	size:8;	signed:1;

print fmt: "0x%lx", REC->ret

 */

// SEC("tp/syscalls/sys_exit_umount")
// int tp_sys_exit_umount(struct pt_regs *ctx)
// {
//     bpf_printk("tp_sys_exit_umount: exit\n");
//     return 0;
// }

// SEC("kprobe/do_mount")
// int kprobe_do_mount(struct pt_regs *ctx)
// {
//     bpf_printk("kprobe_do_mount: enter\n");

//     // Return 0 to continue executing the original function
//     return 0;
// }

// // 无法挂载到 do_mount_root函数: libbpf: prog 'kprobe_do_mount_root': FAILED to create kprobe 'do_mount_root+0x0' perf event: Invalid argument
// SEC("kprobe/do_mount_root")
// int kprobe_do_mount_root(struct pt_regs *ctx)
// {
//     bpf_printk("kprobe_do_mount_root: enter\n");

//     // Return 0 to continue executing the original function
//     return 0;
// }


// SEC("kprobe/path_mount")
// int kprobe_path_mount(struct pt_regs *ctx)
// {
//     bpf_printk("kprobe_path_mount: enter\n");

//     // Return 0 to continue executing the original function
//     return 0;
// }

// SEC("kretprobe/path_mount")
// int BPF_KRETPROBE(kretprobe_path_mount, int ret)
// {
//     bpf_printk("kretprobe_path_mount: exit ret: %d\n", ret);

//     // Return 0 to continue executing the original function
//     return 0;
// }

// SEC("kprobe/path_umount")
// int kprobe_path_umount(struct pt_regs *ctx)
// {
//     bpf_printk("kprobe_path_umount: enter\n");

//     // Return 0 to continue executing the original function
//     return 0;
// }

// SEC("kretprobe/path_umount")
// int BPF_KRETPROBE(kretprobe_path_umount, int ret)
// {
//     bpf_printk("kretprobe_path_umount: exit ret: %d\n", ret);

//     // Return 0 to continue executing the original function
//     return 0;
// }


