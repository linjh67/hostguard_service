/***
 * @Author: JiaHao
 * @Date: 2023-11-29 10:38:51
 * @LastEditors: JiaHao
 * @LastEditTime: 2023-12-04 17:27:30
 * @FilePath: /hostguard_linux/submodule/whitelist/exec_whitelist.cpp
 * @Description:
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved.
 */

// clang++ whitelist_4.cpp -std=c++17 -lspdlog -lfmt -lssl -lcrypto -lmysqlcppconn -fsanitize=address -fno-omit-frame-pointer -fno-optimize-sibling-calls -O1

#include "whitelist/exec_whitelist.h"

using namespace sql;

extern Spdlogger logger;
extern volatile bool mainExitingFlag;

////////////////// ExceptionPathList ///////////////////////
volatile bool& ExceptionPathList::exitingFlag_ = mainExitingFlag;

ExceptionPathList::ExceptionPathList(
    MySQLConnectionPool* pConnectionPool,
    const std::string& database, 
    const std::string& tableName
)
:   pConnectionPool_(pConnectionPool),
    database_(database),
    tableName_(tableName)
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] ExceptionPathList(xx...)");
}

ExceptionPathList::~ExceptionPathList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] ~ExceptionPathList()");
    releaseConnection();
}

int ExceptionPathList::initConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] initConnection()");

    std::shared_ptr<sql::Connection> connection = pConnectionPool_->getConnection();
    if (nullptr == connection) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Failed to getConnection: execExceptionPathList.connection_ == nullptr !");
        return -1;
    }

    connection_ = connection;
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExceptionPathList] connection_: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection_.get()));
    return 1;
}

void ExceptionPathList::releaseConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] releaseConnection()");

    if (nullptr != connection_) {
        pConnectionPool_->releaseConnection(connection_);
        connection_ = nullptr;
    }
}

int ExceptionPathList::createDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] createDatabase()");

    try {
        pConnectionPool_->createDatabase(connection_, database_);
        // throw std::runtime_error("[ExceptionPathList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExceptionPathList::deleteTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] deleteTable()");

    try {
        bool exists = pConnectionPool_->hasTable(connection_, tableName_);
        if (exists) {
            pConnectionPool_->deleteTable(connection_, tableName_);
        }
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExceptionPathList] Table deleted: {}", tableName_);
        // throw std::runtime_error("[ExceptionPathList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExceptionPathList::createTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] createTable()");

    try {
        const std::string sql = "CREATE TABLE IF NOT EXISTS " + tableName_ +
                                " ("
                                "     id        BigInt AUTO_INCREMENT PRIMARY KEY, "
                                "     time      TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "  // automatic generate time
                                "     path      VARCHAR(512) UNIQUE"
                                " )";
        pConnectionPool_->createTable(connection_, sql);
        // throw std::runtime_error("[ExceptionPathList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExceptionPathList::deleteData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] deleteData()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement("DELETE FROM " + tableName_));

        pConnectionPool_->deleteData(connection_, pstmt);
        // throw std::runtime_error("[ExceptionPathList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
        return -1;
    }
}

std::map<std::string, bool> ExceptionPathList::upsertEntryListInDB(const std::vector<ExceptionPathEntry>& pathList) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] upsertEntryListInDB()");

    std::map<std::string, bool> result = {};
    std::unique_ptr<sql::PreparedStatement> pstmt(
        connection_->prepareStatement(
            "INSERT INTO " + tableName_ + " (path) "
                                            "VALUES (?) "
                                            "ON DUPLICATE KEY UPDATE "
                                            "time = CURRENT_TIMESTAMP "
    ));

    for (const auto& path : pathList) {
        try {
            pstmt->setString(1, path.path_);
            pConnectionPool_->upsertData(connection_, pstmt);
            result.emplace(path.path_, true);
            // throw std::runtime_error("[ExceptionPathList] test runtime_error");
        } catch (const std::runtime_error& e) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
            result.emplace(path.path_, false);
        }
    }
    return result;
}

std::map<unsigned long long, bool> ExceptionPathList::deleteEntryListInDB(const std::vector<unsigned long long>& idList) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] deleteEntryListInDB()");

    std::map<unsigned long long, bool> result = {};
    std::unique_ptr<sql::PreparedStatement> pstmt(
        connection_->prepareStatement(
            "DELETE FROM " + tableName_ + " WHERE id = ?"
    ));

    for (const auto& id : idList) {
        try {
            pstmt->setUInt64(1, id);
            pConnectionPool_->deleteData(connection_, pstmt);
            result.emplace(id, true);
            // throw std::runtime_error("[ExceptionPathList] test runtime_error");
        } catch (const std::runtime_error& e) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
            result.emplace(id, false);
        }
    }
    return result;
}

int ExceptionPathList::retrieveData(int pageSize, int pageId) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] retrieveData()");

    std::chrono::_V2::system_clock::time_point start;
    std::vector<std::string> exceptionPathListTmp = {};

    start = getTimePoint();
    try {
        std::unique_ptr<sql::ResultSet> result(nullptr);
        const std::string sql = "SELECT * FROM " + tableName_ + " LIMIT " + std::to_string(pageSize) + " OFFSET " + std::to_string(pageId * pageSize);
        pConnectionPool_->selectData(connection_, sql, result);

        // Handle result set
        while (result->next()) {
            exceptionPathListTmp.emplace_back(result->getString("path"));
        }

        // throw std::runtime_error("[ExceptionPathList] test selectData");
        // return 1;

    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
        return -1;
    }

    /* duration */
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExceptionPathList] Retrieve Data Finish. [size : {}], [duration: {} seconds].", exceptionPathListTmp.size(), duration.count() / 1000000.0);

    return 1;
}

int ExceptionPathList::reloadExceptionPathList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] reloadExceptionPathList()");

    int currentPageId = 0;
    int pageSize = 10000;
    std::chrono::_V2::system_clock::time_point start;
    std::vector<ExceptionPathEntry> exceptionPathListTmp = {};

    start = getTimePoint();
    try {

        while (!exitingFlag_) {
            std::unique_ptr<sql::ResultSet> result(nullptr);
            const std::string sql = "SELECT * FROM " + tableName_ + " LIMIT " + std::to_string(pageSize) + " OFFSET " + std::to_string(currentPageId * pageSize);
            pConnectionPool_->selectData(connection_, sql, result);

            // Handle result set
            while (result->next()) {
                ExceptionPathEntry exceptionPathEntry = {
                    result->getString("path"),
                    result->getUInt64("id"),
                    result->getString("time")
                };
                exceptionPathListTmp.emplace_back(exceptionPathEntry);
            }

            /* reach the end ? */
            if (result->rowsCount() < pageSize) {
                break;
            }

            currentPageId++;
        }

        // throw std::runtime_error("[ExceptionPathList] test selectData");
        // return 1;

    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] MySQL error: {}", e.what());
        return -1;
    }

    /* 
        safely update exceptionPathList_
     */
    std::unique_lock<std::mutex> lock(exceptionPathListMutex_);
    exceptionPathList_.clear();
    exceptionPathList_ = exceptionPathListTmp;
    lock.unlock();

    /* duration */
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExceptionPathList] Reload ExceptionPathList Finish. [size : {}], [duration: {} seconds].", exceptionPathList_.size(), duration.count() / 1000000.0);

    /* print exceptionPathList */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExceptionPathList] ExceptionPathList: \n{}", printExceptionPathList().str().c_str());

    return 1;
}


int ExceptionPathList::initDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] initDatabase()");

    int ret = -1;

    ret = createDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Create Database Failed.");
        return -1;
    }

    ret = deleteTable();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Delete Table Failed.");
        return -1;
    }

    ret = createTable();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Create Table Failed.");
        return -1;
    }

    // ret = deleteData();
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Delete Data Failed.");
    //     return -1;
    // }

    std::vector<ExceptionPathEntry> pathList = {
        {"ExceptionPath1"},
        {"ExceptionPath2"},
        {"ExceptionPath3"},
        {"ExceptionPath3"},
        {"ExceptionPath4"},
        {"ExceptionPath5"},
        };
    auto resultMap = upsertEntryListInDB(pathList);
    for (const auto& [path, result] : resultMap) {
        if (!result) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Upsert ExceptionPath Failed. [path: {}]", path.c_str());
            return -1;
        }
    }

    return 1;
}

std::stringstream ExceptionPathList::printExceptionPathList() {
    std::stringstream ss;
    ss << "ExceptionPathList: \n";
    int i = 0;
    for (const auto& path : exceptionPathList_) {
        ss  << "    [" << i << "] " 
            << "[path: "    << path.path_   << "], "
            << "[id: "      << path.id_     << "] " << std::endl;
        i++;
    }
    return ss;
}

int ExceptionPathList::init() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExceptionPathList] init()");

    int ret = -1;

    ret = initConnection();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Init Connection Failed.");
        return -1;
    }

    ret = initDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExceptionPathList] Init Database Failed.");
        return -2;
    }

    return 1;
}




////////////////// ExecWhiteList ///////////////////////

volatile bool& ExecWhiteList::exitingFlag_ = mainExitingFlag;

ExecWhiteList::ExecWhiteList(
    MySQLConnectionPool* pConnectionPool,
    const EVP_MD* pEVP_MD,
    const std::string& database,
    const std::string& tableName
)
:   pConnectionPool_(pConnectionPool),
    fileDigestCalculator_(pEVP_MD),             /* 用所需的哈希函数替换 EVP_sha256，例如 EVP_sha1、EVP_sha512 等 */
    database_(database),
    tableName_(tableName),
    scanExceptionPathList_(pConnectionPool, database, "exception_path_list")
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] ExecWhiteList(xx...)");

    forbiddenPathList_ =    {  
                                "/proc", "/sys", "/dev", "/run", 
                                "/mnt", "/media", "/lost+found",
                                "/tmp", "/var/tmp", "/dev/shm", 
                                // "/sys/kernel/debug", "/sys/kernel/tracing",
                                "/var/log", "/var/run", "/var/lock", "/var/cache"
                            };

    resetStartTimeAndCount();
}

ExecWhiteList::~ExecWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] ~ExecWhiteList()");
    releaseConnection();
}

//////////////////////////////////////////////////////////////////////
void ExecWhiteList::resetCount() {
    scannedFileCount_.store(0);
    candidateFileCount_.store(0);
    fileProcessRequestCount_.store(0);
    fileRecordRequestCount_.store(0);
}

void ExecWhiteList::resetStartTime() {
    start_ = getTimePoint();
}

void ExecWhiteList::resetStartTimeAndCount() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] resetStartTimeAndCount()");
    resetCount();
    resetStartTime();    
}

int ExecWhiteList::initConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] initConnection()");

    std::shared_ptr<sql::Connection> connection = pConnectionPool_->getConnection();
    if (nullptr == connection) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Failed to getConnection: execWhiteList.connection_ == nullptr !");
        return -1;
    }

    try {
        pConnectionPool_->setIsolationLevel(connection, sql::enum_transaction_isolation::TRANSACTION_READ_UNCOMMITTED);
    } catch (const std::exception& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error setting isolation level: {}", e.what());
        return -1;
    }
    
    connection_ = connection;
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] connection_: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection_.get()));
    return 1;
}

void ExecWhiteList::releaseConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] releaseConnection()");

    if (nullptr != connection_) {
        pConnectionPool_->releaseConnection(connection_);
        connection_ = nullptr;
    }
}

inline std::vector<unsigned char> ExecWhiteList::getFileDigest(const std::string& filePath) {
    std::vector<unsigned char> fileDigest = {};

    try {
        // 计算 File Digest
        fileDigest = fileDigestCalculator_.calculateFileDigest(filePath);

        // 将哈希值转换为十六进制字符串并打印结果
        // SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] File: {}", filePath.c_str());
        // SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList]   fileDigest: {}", toHexString(fileDigest).c_str());
        return fileDigest;

    } catch (const std::exception& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error: {}", e.what());
        return {};
    }
}

/* isRegularFile */
inline bool ExecWhiteList::isRegularFile(const std::string& filepath) {
    struct stat path_stat;
    if (stat(filepath.c_str(), &path_stat) != 0) {
        std::string errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error getting file stat isRegularFile:  {}", errorMsg.c_str());
        return false;
    }
    return S_ISREG(path_stat.st_mode);
}

/* isEmptyFile */
inline bool ExecWhiteList::isEmptyFile(const std::string& filepath) {
    struct stat fileStat;
    if (stat(filepath.c_str(), &fileStat) != 0) {
        std::string errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error getting file stat isEmptyFile: {}. {}", filepath.c_str(), errorMsg.c_str());
        return true;
    }
    return fileStat.st_size == 0;
}


// Function to check if a file is in executable mode
inline bool ExecWhiteList::isExecutableMode(const std::string& filepath) {
    struct stat fileStat;
    if (stat(filepath.c_str(), &fileStat) == 0) {
        return (fileStat.st_mode & S_IXUSR) != 0;
    }
    SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error getting file stat isXMode:  {}", filepath.c_str());
    return false;
}

// Function to check if a file is an ELF type
inline bool ExecWhiteList::isELF(const std::string& filepath) {
    struct stat fileStat;
    int ret = stat(filepath.c_str(), &fileStat);
    if (ret != 0) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error getting file stat isELF:  {}", filepath.c_str());
        return false;
    }

    if (fileStat.st_size < 4) {  // 防止遇到没有内容的文件被阻塞住，例如：trace_pipe
        // SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] File size less than 4 bytes:  {}", filepath.c_str());
        return false;
    }

    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error opening file:  {}", filepath.c_str());
        return false;
    }

    // Read the first four bytes (magic number) from the file
    std::vector<unsigned char> magic(4);
    file.read(reinterpret_cast<char*>(magic.data()), 4);
    file.close();

    // Check if the magic number indicates an ELF file
    bool isELF = (magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F');
    return isELF;
}

std::string ExecWhiteList::getCanonicalPath(const std::string& path) {
    try {
        auto canonical_path = std::filesystem::canonical(path);  // -std=c++17
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Input_path: {}, Canonical_path:  {}", path.c_str(), canonical_path.string().c_str());
        return canonical_path.string();

    } catch (const std::exception& ex) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Canonical path for {} threw exception: {}", path.c_str(), ex.what());
        return "";
    }
}

inline void ExecWhiteList::checkMilestone() {
    if (0 == scannedFileCount_.load() % scanStepLen_
        || 1 == candidateFileCount_.load() % scanStepLen_) {
        auto duration = getDuration_us(start_);
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] [scannedFileCount: {}], [candidateFileCount: {}], [duration: {} seconds].", scannedFileCount_.load(), candidateFileCount_.load(), duration.count() / 1000000.0);
    }
}

inline bool ExecWhiteList::isPath(const std::string& path) {
    for (const auto& forbiddenPath : forbiddenPathList_) {
        if (path == forbiddenPath) {
            return true;
        }
    }
    return false;
}

inline bool ExecWhiteList::isExceptionPath(const std::string& path) {
    std::unique_lock<std::mutex> lock(scanExceptionPathList_.exceptionPathListMutex_);
    for (const auto& exceptionPath : scanExceptionPathList_.exceptionPathList_) {
        if (path == exceptionPath.path_) {
            return true;
        }
    }
    return false;
}

inline int ExecWhiteList::processFile(const std::string& filepath) {
    
    bool isELF_File = isELF(filepath);
    bool isExe_Mode = isExecutableMode(filepath);
    if (!isELF_File && !isExe_Mode) {
        // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] File is not ELF and not Executable! [filepath: {}]", filepath.c_str());
        return 1;
    }

    bool isEmpty    = isEmptyFile(filepath);
    if (isEmpty) {       /* avoid file read blocked, such as: /sys/kernel/tracing/trace_pipe */
        // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] File is empty! [filepath: {}]", filepath.c_str());
        return 1;
    }
    
    /* get File Digest */
    std::vector<unsigned char> fileDigest = getFileDigest(filepath);
    if (fileDigest.empty()) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] FileDigest is empty! [filepath: {}]", filepath.c_str());
        return -1;
    }

    /* filePathEntry */
    ExecRuntimeFilePathEntry filePathEntry = {filepath, isELF_File, isExe_Mode, toHexString(fileDigest), exec_reaction::ALLOW_EXEC, true, false, candidateFileCount_.fetch_add(1)};
    
    /* push to record RequestQueue & tell reacord thread to work */
    {
        std::unique_lock<std::mutex> lock(recordRequestQueueMutex_);  
        recordRequestQueue_.emplace(fileRecordRequestCount_.load(), filePathEntry);
        lock.unlock();

        recordRequestSemaphore_.release();
        fileRecordRequestCount_.fetch_add(1);
    }

    checkMilestone();

    return 1;
}

inline int ExecWhiteList::readDirFiles(std::stack<std::string>& scanDirStack) {
    
    /* get top dir */
    const std::string currentDir = scanDirStack.top();
    scanDirStack.pop();
    
    /* check dir path */
    if (isForbiddenPath(currentDir) || isExceptionPath(currentDir)) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] {} is ForbiddenPath or ExceptionPath", currentDir.c_str());
        return 1;
    }
    
    /* open dir */
    DIR* dir = opendir(currentDir.c_str());
    if (!dir) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error opening directory:  {}", currentDir.c_str());
        return -1;
    }

    /* read files in dir */
    struct dirent* entry;
    while (!exitingFlag_ && !scanNeedToStopFlag_.load() && (entry = readdir(dir)) != nullptr) {

        std::string filename = entry->d_name;
        if (filename == "." || filename == "..") {
            continue;
        }

        std::string filepath = {};
        if (currentDir == "/") {
            filepath = "/" + filename;
        } else {
            filepath = currentDir + "/" + filename;
        }

        if (entry->d_type == DT_DIR) {
            // Push sub dir into the stack
            scanDirStack.push(filepath);
            continue;
        }
        
        /* check scan mile stone */
        {
            scannedFileCount_.fetch_add(1);
            checkMilestone();
            // SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] [scannedFileCount: {}], [candidateFileCount: {}], [filepath: {}].", scannedFileCount_.load(), candidateFileCount_.load(), filepath.c_str());
        }
        
        if (entry->d_type == DT_REG) {

            /* Use ThreadPool */
            {
                std::unique_lock<std::mutex> lock(fileProcessRequestQueueMutex_);
                fileProcessRequestQueue_.emplace(fileProcessRequestCount_.load(), filepath);
                lock.unlock();

                fileProcessRequestSemaphore_.release();
                fileProcessRequestCount_.fetch_add(1);
            }
            
            /* Use Single Thread */
            // {
            //     int ret = processFile(filepath);
            //     if (1 != ret) {
            //         SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Error processing file:  {}", filepath.c_str());
            //     }
            // }
            

            continue;
        }

    }

    closedir(dir);
    return 1;
}

// Function to scan directory non-recursively
bool ExecWhiteList::scanDirectory(const std::string& path) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] scanDirectory()");

    /* scan flags */
    scanRunningFlag_.store(true);
    scanNeedToStopFlag_.store(false);
    
    /* reset time & file count */
    resetStartTimeAndCount();
    
    /* scan dir & hash calc & record into DB */
    {
        std::stack<std::string> scanDirStack = {};
        scanDirStack.push(path);
        
        while (!exitingFlag_ && !scanNeedToStopFlag_.load() && !scanDirStack.empty()) {
            readDirFiles(scanDirStack);
        }

        auto duration = getDuration_us(start_);
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] [scannedFileCount: {}], [candidateFileCount: {}], [duration: {} seconds]. ALL Dir Traverse Finish!", scannedFileCount_.load(), candidateFileCount_.load(), duration.count() / 1000000.0);
    }
    
    
    /* wait for file Process threads all work finish */
    {
        for (int i = 0; i < fileProcessRequestCount_.load(); i++) {
            fileProcessFinishSemaphore_.acquire();
            if (exitingFlag_) {
                break;
            }

            /* check each response */
            {
                std::unique_lock<std::mutex> lock(fileProcessResponseQueueMutex_);
                if (fileProcessResponseQueue_.empty()) {
                    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] File Process Response Queue is empty!");
                    continue;
                }
                FileProcessResponse response = fileProcessResponseQueue_.front();
                fileProcessResponseQueue_.pop();
                lock.unlock();

                if (!response.isSuccess_) {
                    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Process Failed. [File: {}]", response.filepath_.c_str());
                }
            }
        }

        auto duration = getDuration_us(start_);
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] [scannedFileCount: {}], [candidateFileCount: {}], [duration: {} seconds]. All File Hash Process Finish!", scannedFileCount_.load(), candidateFileCount_.load(), duration.count() / 1000000.0);
    }

    /* wait for file Record thread work finish */
    {
        for (int i = 0; i < fileRecordRequestCount_.load(); i++) {
            recordFinishSemaphore_.acquire();
            if (exitingFlag_) {
                break;
            }

            /* check each response */
            {
                std::unique_lock<std::mutex> lock(recordResponseQueueMutex_);
                if (recordResponseQueue_.empty()) {
                    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Record Response Queue is empty!");
                    continue;
                }
                ExecWhiteListRecordResponse response = recordResponseQueue_.front();
                recordResponseQueue_.pop();
                lock.unlock();

                if (!response.isSuccess_) {
                    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Record Failed. [File: {}]", response.filePathEntry_.filepath_.c_str());
                }
            }
        }

        auto duration = getDuration_us(start_);
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] [scannedFileCount: {}], [candidateFileCount: {}], [duration: {} seconds]. All File Entry Record into DataBase Finish!", scannedFileCount_.load(), candidateFileCount_.load(), duration.count() / 1000000.0);
    }

    /* scan running flag -> false */
    scanRunningFlag_.store(false);

    /* check if interrupted by command  */
    if (scanNeedToStopFlag_.load()) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Scan Stop Flag Detected! [scanNeedToStopFlag: True]");
        return false;
    }

    return true;
}


int ExecWhiteList::stopScan() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] stopScan()");

    /* set scan stop flag */
    scanNeedToStopFlag_.store(true);
    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Scan Stop Flag Set [scanNeedToStopFlag: True]!");

    /* wait for scan stop */
    {
        std::unique_lock<std::mutex> scanLock(scanMutex_);
        while(scanRunningFlag_.load() == true) {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Waiting for Scan Stop...");
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Scan Stopped!");
    }

    return 1;
}

int ExecWhiteList::beginTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] beginTransaction()");
    try {
        pConnectionPool_->beginTransaction(connection_);
        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::createDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] createDatabase()");

    try {
        pConnectionPool_->createDatabase(connection_, database_);
        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::deleteTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] deleteTable()");

    try {
        bool exists = pConnectionPool_->hasTable(connection_, tableName_);
        if (exists) {
            pConnectionPool_->deleteTable(connection_, tableName_);
        }
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] Table deleted: {}", tableName_);
        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::createTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] createTable()");

    try {
        const std::string sql = "CREATE TABLE IF NOT EXISTS " + tableName_ +
                                " ("
                                "     id            BigInt AUTO_INCREMENT PRIMARY KEY, "
                                "     time          TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "  // automatic generate time
                                "     filepath      VARCHAR(512) UNIQUE, "
                                "     isELF         BOOLEAN, "
                                "     isXmode       BOOLEAN, "
                                "     fileDigest    VARCHAR(256), "             /* [sha1: 20 bytes -> 40 hex char] / [sha512: 64 bytes -> 128 hex char] */
                                "     reaction      INT, "
                                "     isCandidate   BOOLEAN DEFAULT TRUE, "     /* candidate flag */
                                "     isFormal      BOOLEAN DEFAULT FALSE "     /* formal flag */
                                " )";
        pConnectionPool_->createTable(connection_, sql);
        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::deleteData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] deleteData()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement("DELETE FROM " + tableName_));

        pConnectionPool_->deleteData(connection_, pstmt);
        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::upsertData(const ExecRuntimeFilePathEntry& filePathEntry) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] upsertData()");

        try {
            std::unique_ptr<sql::PreparedStatement> pstmt(
                connection_->prepareStatement(
                    "INSERT INTO " + tableName_ + " ("
                    // "REPLACE INTO " + tableName_ + " ("
                                                        "filepath, "
                                                        "isELF, "
                                                        "isXmode, "
                                                        "fileDigest, "
                                                        "reaction, "
                                                        "isCandidate, "
                                                        "isFormal "
                                                    ") "
                                                    "VALUES (?, ?, ?, ?, ?, ?, ?) "
                                                    "ON DUPLICATE KEY UPDATE "
                                                    "isELF          = VALUES(isELF), "
                                                    "isXmode        = VALUES(isXmode), "
                                                    "fileDigest     = VALUES(fileDigest), "
                                                    "reaction       = VALUES(reaction), "
                                                    "isCandidate    = VALUES(isCandidate), "
                                                    "time           = CURRENT_TIMESTAMP "
            ));
            pstmt->setString(1, filePathEntry.filepath_);
            pstmt->setBoolean(2, filePathEntry.isELF_);
            pstmt->setBoolean(3, filePathEntry.isXmode_);
            pstmt->setString(4, filePathEntry.fileDigest_);
            pstmt->setInt(5, static_cast<int>(filePathEntry.reaction_));
            pstmt->setBoolean(6, filePathEntry.isCandidate_);
            pstmt->setBoolean(7, filePathEntry.isFormal_);

            pConnectionPool_->upsertData(connection_, pstmt);
            // throw std::runtime_error("[ExecWhiteList] test runtime_error");
            // return 1;
        } catch (const std::runtime_error& e) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
            return -1;
        }
    
    return 1;
}

std::map<unsigned long long, bool> ExecWhiteList::deleteEntryListInDB(const std::vector<unsigned long long>& idList) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] deleteEntryListInDB()");

    std::map<unsigned long long, bool> result = {};
    std::unique_ptr<sql::PreparedStatement> pstmt(
        connection_->prepareStatement(
            "DELETE FROM " + tableName_ + " WHERE id = ?"
    ));

    for (const auto& id : idList) {
        try {
            pstmt->setUInt64(1, id);
            pConnectionPool_->deleteData(connection_, pstmt);
            result.emplace(id, true);

            // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        } catch (const std::runtime_error& e) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
            result.emplace(id, false);
        }
    }
    return result;
}

int ExecWhiteList::deleteNonCandidateEntryInDB() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] deleteNonCandidateEntryInDB()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement(
                "DELETE FROM " + tableName_ + " WHERE isCandidate = FALSE"
        ));

        pConnectionPool_->deleteData(connection_, pstmt);

        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::setCandidateFlagFalseInDB() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] setCandidateFlagFalseInDB()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement(
                "UPDATE " + tableName_ + " SET isCandidate = FALSE"
        ));

        pConnectionPool_->upsertData(connection_, pstmt);

        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::setFormalFlagTrueInDB() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] setFormalFlagTrueInDB()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement(
                "UPDATE " + tableName_ + " SET isFormal = TRUE"
        ));

        pConnectionPool_->upsertData(connection_, pstmt);

        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

// int ExecWhiteList::getLastIdInDB() {
//     SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] getLastIdInDB()");

//     try {
//         std::unique_ptr<sql::ResultSet> result(nullptr);
//         const std::string sql = "SELECT MAX(id) FROM " + tableName_;
//         pConnectionPool_->selectData(connection_, sql, result);

//         // Handle result set
//         if (result->next()) {
//             lastIdInDB_.store(result->getUInt64(1));
//         }

//         // throw std::runtime_error("[ExecWhiteList] test selectData");
//         return 1;

//     } catch (const std::runtime_error& e) {
//         SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
//         return -1;
//     }
// }

// int ExecWhiteList::deleteEntryUnderLastIdInDB() {
//     SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] deleteEntryUnderLastIdInDB()");

//     try {
//         std::unique_ptr<sql::PreparedStatement> pstmt(
//             connection_->prepareStatement(
//                 "DELETE FROM " + tableName_ + " WHERE id <= ?"
//         ));
//         pstmt->setUInt64(1, lastIdInDB_.load());

//         pConnectionPool_->deleteData(connection_, pstmt);

//         // throw std::runtime_error("[ExecWhiteList] test runtime_error");
//         return 1;
//     } catch (const std::runtime_error& e) {
//         SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
//         return -1;
//     }

// }

int ExecWhiteList::retrieveData(int pageSize, int pageId) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] retrieveData()");

    std::chrono::_V2::system_clock::time_point start;
    std::unordered_map<std::string, ExecWhiteListEntry> whiteListRuntimeMapTmp = {};

    start = getTimePoint();
    try {
        std::unique_ptr<sql::ResultSet> result(nullptr);
        const std::string sql = "SELECT * FROM " + tableName_ + " LIMIT " + std::to_string(pageSize) + " OFFSET " + std::to_string(pageId * pageSize);
        pConnectionPool_->selectData(connection_, sql, result);

        // Handle result set
        while (!exitingFlag_ && result->next()) {
            ExecRuntimeFilePathEntry filePathEntry = {
                result->getString("filepath"),
                result->getBoolean("isELF"),
                result->getBoolean("isXmode"),
                result->getString("fileDigest"),
                static_cast<exec_reaction>(result->getInt("reaction")), 
                result->getBoolean("isCandidate"),
                result->getBoolean("isFormal"),
                result->getUInt64("id"),
                result->getString("time")
            };

            std::stringstream ss;
            ss  << filePathEntry.print().str();  
            
            SPDLOG_LOGGER_INFO(logger.my_logger, "{}", ss.str().c_str());
        }
       
        // throw std::runtime_error("[ExecWhiteList] test selectData");
        
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }

    /* duration */
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Retrieve Data Finish. [duration: {} seconds].", duration.count() / 1000000.0);

    return 1;
}

int ExecWhiteList::rollbackTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] rollbackTransaction()");

    try {
        pConnectionPool_->rollbackTransaction(connection_);
        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::endTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] endTransaction()");

    try {
        pConnectionPool_->endTransaction(connection_);
        // throw std::runtime_error("[ExecWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecWhiteList::initDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] initDatabase()");

    int ret = -1;

    ret = beginTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Begin Transaction Failed.");
        return -1;
    }

    ret = createDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Create Database Failed.");
        return -1;
    }

    // ret = deleteTable();
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Delete Table Failed.");
    //     return -1;
    // }

    ret = createTable();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Create Table Failed.");
        return -1;
    }

    // ret = deleteData();
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Delete Data Failed.");
    //     return -1;
    // }

    // ExecRuntimeFilePathEntry filePathEntry = {"testFilepath", true, true, "0102030405060708090a0b0c0d0e0f1011121314", exec_reaction::ALLOW_EXEC, false, true};

    // ret = upsertData(filePathEntry);
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Upsert Data Failed.");
    //     return -1;
    // }

    ret = retrieveData();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Retrieve Data Failed.");
        return -1;
    }

    ret = endTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] End Transaction Failed.");
        return -1;
    }

    return 1;
}

int ExecWhiteList::reloadFormalListMap() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] reloadFormalListMap()");

    int serialId = 0;
    int currentPageId = 0;
    int pageSize = 10000;
    std::chrono::_V2::system_clock::time_point start;
    std::unordered_map<unsigned long long, ExecRuntimeFilePathEntry> formalListMapTmp = {};

    start = getTimePoint();
    try {

        while (!exitingFlag_) {
            std::unique_ptr<sql::ResultSet> result(nullptr);
            const std::string sql = "SELECT * FROM " + tableName_ 
                                    + " WHERE isFormal = True "
                                    + " ORDER BY id ASC"
                                    + " LIMIT "     + std::to_string(pageSize) 
                                    + " OFFSET "    + std::to_string(currentPageId * pageSize);
                                    
            pConnectionPool_->selectData(connection_, sql, result);

            // Handle result set
            while (!exitingFlag_ && result->next()) {
                ExecRuntimeFilePathEntry filePathEntry = {
                    result->getString("filepath"),
                    result->getBoolean("isELF"),
                    result->getBoolean("isXmode"),
                    result->getString("fileDigest"),
                    static_cast<exec_reaction>(result->getInt("reaction")),
                    result->getBoolean("isCandidate"),
                    result->getBoolean("isFormal"),
                    result->getUInt64("id"),
                    result->getString("time")
                };
                /* insert to formalListMap */
                formalListMapTmp.emplace(serialId, filePathEntry);
                serialId++;
            }

            /* reach the end ? */
            if (result->rowsCount() < pageSize) {
                break;
            }

            currentPageId++;
        }

        // throw std::runtime_error("[ExecWhiteList] test selectData");
        // return 1;

    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] MySQL error: {}", e.what());
        return -1;
    }

    /* 
        safely update formalListMap_
     */
    std::unique_lock<std::mutex> lock(formalListMapMutex_);
    formalListMap_.clear();
    formalListMap_ = formalListMapTmp;
    lock.unlock();

    /* duration */
    auto duration = getDuration_us(start);      /* [size : 26705], [duration: 2.537179 seconds] */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Reload FormalList Map Finish. [size : {}], [duration: {} seconds].", formalListMap_.size(), duration.count() / 1000000.0);

    /* print formalListMap */
    // SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] FormalList Map: \n{}", printFormalListMap().str().c_str());

    return 1;
}


int ExecWhiteList::reloadWhiteListRuntimeMap() {

    std::chrono::_V2::system_clock::time_point start = {};
    std::unordered_map<std::string, ExecWhiteListEntry> whiteListRuntimeMapTmp = {};

    int ret = reloadFormalListMap();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Reload WhiteListMap Failed.");
        return -1;
    }

    start = getTimePoint();
    {
        /* formalListMap -> whiteListRuntimeMap */
        std::unique_lock<std::mutex> lock(formalListMapMutex_);
        for(const auto& pair : formalListMap_) {
            const ExecRuntimeFilePathEntry& filePathEntry = pair.second;
            /* update WhiteList Runtime Map */
            upsertFilePathEntryInRuntimeMap(whiteListRuntimeMapTmp, filePathEntry);
        }
    }
    auto duration = getDuration_us(start);      /* [size : 21984], [duration: 4.524593 seconds] */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Upsert WhiteListRuntimeMapTmp Finish. [size : {}], [duration: {} seconds].", whiteListRuntimeMapTmp.size(), duration.count() / 1000000.0);
    

    /* 
        safely update pWhiteListRuntimeMap_
     */
    start = getTimePoint();
    /* update pWhiteListRuntimeMap_ */
    std::unique_lock<std::mutex> lock(whiteListRuntimeMapMutex_);   /* [duration: 4e-05 seconds] */
    whiteListRuntimeMapB_ = whiteListRuntimeMapTmp;               /* copy the newest MapTmp to MapB, [duration: 0.566918 seconds] */
    pWhiteListRuntimeMap_.store(&whiteListRuntimeMapB_);            /* point to MapB temporarily since it is the newest, [duration: 4e-05 seconds] */
    lock.unlock();

    /* wait for all read operation using MapA finish */
    std::this_thread::sleep_for(std::chrono::milliseconds(runtimeMapSwitchWaitTimeMS_));    

    /* copy MapB to MapA, may take some time */
    lock.lock();
    whiteListRuntimeMapA_ = whiteListRuntimeMapB_;
    pWhiteListRuntimeMap_.store(&whiteListRuntimeMapA_);            /* back to use MapA */
    lock.unlock();

    /* duration */
    duration = getDuration_us(start);           /* [size : 21984], [duration: 1.504429 seconds] */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Update WhiteListRuntimeMaps Finish. [size : {}], [duration: {} seconds].", pWhiteListRuntimeMap_.load()->size(), duration.count() / 1000000.0);

    /* print whiteListRuntimeMap */
    // SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] WhiteListRuntimeMap: \n{}", printWhiteListRuntimeMap().str().c_str());

    return 1;
}

/* uapi */
std::stringstream ExecWhiteList::printFormalListMap() {
    int i = 0;
    std::stringstream ss;
    std::unique_lock<std::mutex> lock(formalListMapMutex_);

    for (const auto& pair : formalListMap_) {
        const ExecRuntimeFilePathEntry& filePathEntry = pair.second;
        ss  << std::left << std::setw(8) << ("[" + std::to_string(pair.first) + "]")
            << filePathEntry.print().str() << std::endl;
    }
    // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] FormalListMap: \n{}", ss.str().c_str());
    return ss;
}

std::stringstream ExecWhiteList::printWhiteListRuntimeMap() {
    int i = 0;
    std::stringstream ss;
    std::unique_lock<std::mutex> lock(whiteListRuntimeMapMutex_);
    std::unordered_map<std::string, ExecWhiteListEntry>& whiteListRuntimeMap = *pWhiteListRuntimeMap_.load();

    for (const auto& pair : whiteListRuntimeMap) {
        ss  << std::left << std::setw(8) << ("[" + std::to_string(i++) + "]")
            << pair.second.print().str() << std::endl;
    }
    // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] WhiteListRuntimeMap: \n{}", ss.str().c_str());
    return ss;
}

std::stringstream ExecWhiteList::printRecordRequestQueue() {
    int i = 0;
    std::stringstream ss;
    std::unique_lock<std::mutex> lock(recordRequestQueueMutex_);
    std::queue<ExecWhiteListRecordRequest> tmpQueue = recordRequestQueue_;
    lock.unlock();

    while (!tmpQueue.empty()) {
        ss  << std::left << std::setw(8) << ("[" + std::to_string(tmpQueue.front().id_) + "]")
            << tmpQueue.front().filePathEntry_.print().str() << std::endl;
        tmpQueue.pop();
    }
    // SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] RecordQueue: \n{}", ss.str().c_str());
    return ss;
}


int ExecWhiteList::upsertFilePathEntryInRuntimeMap(std::unordered_map<std::string, ExecWhiteListEntry>& whiteListRuntimeMap, const ExecRuntimeFilePathEntry& filePathEntry) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] upsertFilePathEntryInRuntimeMap()");

    /* whiteListRuntimeMapTmp, no need lock */
    const std::string& fileDigest   = filePathEntry.fileDigest_;
    const exec_reaction& reaction   = filePathEntry.reaction_;
    const std::string& filepath     = filePathEntry.filepath_;

    if (whiteListRuntimeMap.find(fileDigest) != whiteListRuntimeMap.end()) {

        auto pair = whiteListRuntimeMap[fileDigest].filePaths_.emplace(filepath, filePathEntry);   // 移动构造
        if (!pair.second) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Insert File Paths failed, key already exists: {}", pair.first->first.c_str());
            return -1;
        }
        SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] Upsert FilePathEntry In RuntimeMap OK. [FileDigest: {}], [Filepath: {}], [Reaction: {}]", 
                                                fileDigest.c_str(), filepath.c_str(), static_cast<int>(whiteListRuntimeMap[fileDigest].reaction_));
        return 1;

    } else {

        ExecWhiteListEntry whiteListEntry = {};
        whiteListEntry.filePaths_.emplace(filePathEntry.filepath_, filePathEntry);
        whiteListEntry.fileDigest_  = filePathEntry.fileDigest_;
        whiteListEntry.reaction_    = filePathEntry.reaction_;

        auto pair = whiteListRuntimeMap.emplace(fileDigest, whiteListEntry);
        if (!pair.second) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Insert whiteListRuntimeMap failed, key already exists: {}", pair.first->first.c_str());
            return -2;
        }
        SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] FileDigest not in WhiteListRuntimeMap. Upsert FilePathEntry In RuntimeMap OK. [fileDigest: {}], [filepath: {}], [Reaction: {}]", 
                                                fileDigest.c_str(), filepath.c_str(), static_cast<int>(whiteListRuntimeMap[fileDigest].reaction_));
        return 2;
    }
}

int ExecWhiteList::deleteFilePathEntryInRuntimeMap(std::unordered_map<std::string, ExecWhiteListEntry>& whiteListRuntimeMap, const std::string& fileDigest, const std::string& filePath) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] deleteFilePathEntryInRuntimeMap()");

    /* find execKey in RuntimeMap_ */
    if (whiteListRuntimeMap.find(fileDigest) != whiteListRuntimeMap.end()) {

        /* delete FilePath in RuntimeFilePaths */
        int removedNum = whiteListRuntimeMap[fileDigest].filePaths_.erase(filePath);        
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] Delete FilePathEntry In RuntimeMap OK. [FileDigest: {}], [FilePath: {}], [removedNum: {}]", 
                                                fileDigest.c_str(), filePath.c_str(), removedNum);

        if (whiteListRuntimeMap[fileDigest].filePaths_.empty()) {
            
            /* delete entry without any FilePath left in RuntimeMap */
            removedNum = whiteListRuntimeMap.erase(fileDigest);
            SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecWhiteList] Delete ExecWhiteListEntry In RuntimeMap OK. [FileDigest: {}], [removedNum: {}]", 
                                                    fileDigest.c_str(), removedNum);
        }
        return 1;

    } else {

        SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Delete FilePathEntry In RuntimeMap Failed. [FileDigest: {}], [FilePath: {}]: FileDigest not in ExecWhiteListRuntimeMap!", 
                                                fileDigest.c_str(), filePath.c_str());
        return -1;

    }
}

/* Data Record Thread */
int ExecWhiteList::runDataRecordThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] runDataRecordThread()");

    bool isSuccess = true;
    ExecWhiteListRecordRequest request = {};
    std::chrono::_V2::system_clock::time_point start = {};

    /* process ExecWhiteListEntry comming */
    while(!exitingFlag_) {

        /* wait for Semaphore */
        recordRequestSemaphore_.acquire();     
        
        /* sub thread should exit now */
        if (exitingFlag_) {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Break Data Record While Loop.");
            break;
        }

        /* lock & pop from queue */
        {
            std::unique_lock<std::mutex> lock(recordRequestQueueMutex_);
            if (!recordRequestQueue_.empty()) {
                request = recordRequestQueue_.front();
                recordRequestQueue_.pop();
            } else {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] RecordQueue is empty!");
                continue;
            }
        }

        /* work start */
        isSuccess = true;
        start = getTimePoint();

        /* scan need to stop now */
        if (scanNeedToStopFlag_.load()) {
            isSuccess = false;
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Scan Need To Stop Flag is True. Notify Record Finish.");
            goto response;
        }

        /* Insert to mysql, 0.008211s in Transaction */
        {
            int ret = upsertData(request.filePathEntry_);
            if (1 != ret) {
                isSuccess = false;
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Upsert whiteListEntry failed! [filepath: {}]", request.filePathEntry_.filepath_.c_str());
            }
        }
        
response:
        /* push to response queue & pop request queue */
        {
            std::unique_lock<std::mutex> lock(recordResponseQueueMutex_);
            recordResponseQueue_.emplace(request.id_, request.filePathEntry_, isSuccess);
        }

        /* notify work finish */
        recordFinishSemaphore_.release();

        /* duration */
        auto duration = getDuration_us(start);
        // SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] upsertData finish [duration: {} seconds].", duration.count() / 1000000.0);
    }

end:
    /* notify record finish */
    recordFinishSemaphore_.release();
    exitingFlag_ = true;
    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Sub Thread Exec WhiteList Data Record end. Set [exitingFlag: true]!");

    return 0;
}

/* File Scan Thread */
int ExecWhiteList::runFileScanThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] runFileScanThread()");

    ScanPathRequest request = {};

    /* process inputPath comming */
    while(!exitingFlag_) {

        /* wait for Semaphore */
        scanRequestSemaphore_.acquire();
        
        /* sub thread should exit now */
        if (exitingFlag_) {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Break File Scan While Loop.");
            break;
        }

        /* lock & pop from queue */
        {
            std::unique_lock<std::mutex> lock(scanRequestQueueMutex_);
            if (!scanPathRequestQueue_.empty()) {
                request = scanPathRequestQueue_.front();
                scanPathRequestQueue_.pop();
            } else {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] ScanPath Queue is empty!");
                continue;
            }
        }

        /* work start */
        bool isSuccess = true;
        auto start = getTimePoint();
        
        /* get Canonical Path */
        std::string path = getCanonicalPath(request.path_);
        if ("" == path) {
            isSuccess = false;      /* invalid path */
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Path {} not exists. Scan Operation Cancel..", request.path_);
            goto response;
        }
        
        /* path valid, begin scan */
        {
            std::unique_lock<std::mutex> scanLock(scanMutex_);
            isSuccess = scanDirectory(path);
        }

response:
        /* push to scan response queue & pop request queue */
        {
            auto duration = getDuration_us(start);
            std::unique_lock<std::mutex> lock(scanResponseQueueMutex_);
            scanPathResponseQueue_.emplace(request.id_, request.path_, isSuccess, scannedFileCount_.load(), candidateFileCount_.load(), duration.count());
        }

        /* notify work finish */
        scanFinishSemaphore_.release();

        /* duration */
        auto duration = getDuration_us(start);
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Path Scan Finish.  [path: {}], [scannedFileCount: {}], [candidateFileCount: {}], [duration: {} seconds].", path, scannedFileCount_.load(), candidateFileCount_.load(), duration.count() / 1000000.0);
    }

end:
    exitingFlag_ = true;
    /* notify scan finish */
    scanFinishSemaphore_.release();
    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] Sub Thread Exec WhiteList File Scan end. Set [exitingFlag: true]!");

    return 0;
}

int ExecWhiteList::runFileProcessThread(int id) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] runFileProcessThread[{}] Start!", id);
    
    bool isSuccess = true;              /* important for mitigate speed loss caused by thread competition */
    FileProcessRequest request = {};
    std::atomic<unsigned long long> count = 0;
    std::chrono::_V2::system_clock::time_point start = {};

    /* process inputPath comming */
    while(!exitingFlag_) {

        /* wait for Semaphore */
        fileProcessRequestSemaphore_.acquire();
        count++;
        // SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] FileProcessRequestSemaphore Get by FileProcess Thread[{}].", id);
        
        /* sub thread should exit now */
        if (exitingFlag_) {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Break FileProcess Thread[{}] While Loop.", id);
            break;
        }

        /* lock & pop from queue */
        {
            std::unique_lock<std::mutex> lock(fileProcessRequestQueueMutex_);
            if (!fileProcessRequestQueue_.empty()) {
                request = fileProcessRequestQueue_.front();
                fileProcessRequestQueue_.pop();
            } else {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] FileProcess Thread[{}] Queue is empty!", id);
                continue;
            }
        }

        /* work start */
        isSuccess = true;
        start = getTimePoint();

        /* scan need to stop now */
        if (scanNeedToStopFlag_.load()) {
            isSuccess = false;
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] FileProcess Thread[{}] Scan Need To Stop Flag is True.", id);
            goto response;
        }

        /* work */
        {
            int ret = processFile(request.filepath_);
            if (1 != ret) {
                isSuccess = false;
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] FileProcess Thread[{}] Error processing file:  {}", request.id_, request.filepath_.c_str());
            }
        }
        
response:
        /* push to response queue & pop request queue */
        {
            std::unique_lock<std::mutex> lock(fileProcessResponseQueueMutex_);
            fileProcessResponseQueue_.emplace(request.id_, request.filepath_, isSuccess);
        }

        /* notify process finish */
        fileProcessFinishSemaphore_.release();

        /* duration */
        auto duration = getDuration_us(start);  /* important for mitigate speed loss caused by thread competition */
        // SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] FileProcess Thread[{}] Process File Finish.  [path: {}], [scannedFileCount: {}], [candidateFileCount: {}], [duration: {} seconds].", id, filepath, scannedFileCount_.load(), candidateFileCount_.load(), duration.count() / 1000000.0);
    }

end:
    exitingFlag_ = true;
    /* notify process finish */
    fileProcessFinishSemaphore_.release();
    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] File Process Thread[{}] end. [count: {}] Set [exitingFlag: true]!", id, count.load());
    return 0;
}


int ExecWhiteList::startSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] startSubThreads()");

    /* Check exiting flag */
    if (exitingFlag_) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecWhiteList] ExitingFlag is True. No Need to Start Sub Threads. Exit..");
        return -1;
    }

    /* WhiteList Sub Threads */

    /* data record sub thread */
    try{
        std::thread dataRecordThread = std::thread([this](){ this->runDataRecordThread(); });
        subThreadsMap_.emplace(
            ExecWhiteListSubThreadId::SUB_THREAD_RECORD,
            std::move(dataRecordThread)     // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Sub Thread Exec WhiteList Data Record Running...");
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Failed to run Sub Thread Exec WhiteList Data Record. Error: {}. Set [exitingFlag: true]!", e.what());
        return -2;
    }

    /* file scan sub thread */
    try{
        std::thread fileScanThread = std::thread([this](){ this->runFileScanThread(); });
        subThreadsMap_.emplace(
            ExecWhiteListSubThreadId::SUB_THREAD_SCAN,
            std::move(fileScanThread)     // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Sub Thread Exec WhiteList File Scan Running...");
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Failed to run Sub Thread Exec WhiteList File Scan. Error: {}. Set [exitingFlag: true]!", e.what());
        return -3;
    }

    /* file process threadpool */
    try {
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Hardware [Concurrency: {}].", fileProcessThreadNum_);
        for (int i = 0; i < fileProcessThreadNum_; ++i) {
            fileProcessThreads_.emplace_back(
                [this, i](){
                    this->runFileProcessThread(i);
                }
            );
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Sub Thread Exec WhiteList File Process Thread[{}] Running...", i);
        }
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Failed to run Sub Thread Exec WhiteList File Process Thread. Error: {}. Set [exitingFlag: true]!", e.what());
        return -4;
    }

    return 1;
}

int ExecWhiteList::stopSubThreads() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecWhiteList] Exec WhiteList SubThreads Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;

    /* stop file process threadpool */
    for (auto& fileProcessThread : fileProcessThreads_) {
        fileProcessRequestSemaphore_.release();
    }

    /* stop scan & record thread */
    scanRequestSemaphore_.release();
    recordRequestSemaphore_.release();
    return 1;
}

int ExecWhiteList::joinSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] joinSubThreads()");

    /* join file process threadpool */
    int i = 0;
    for (auto& fileProcessThread : fileProcessThreads_) {
        if (fileProcessThread.joinable()) {
            fileProcessThread.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] File Process Thread [{}] joined...", i);
        }
        i++;
    }

    /* join whitelist sub threads */
    for (auto& pair : subThreadsMap_) {
        if (pair.second.joinable()) {
            pair.second.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] Sub Thread [{}] joined...", static_cast<int>(pair.first));
        }
    }

    return 1;
}


int ExecWhiteList::runMainThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] runMainThread()");

    int ret = -1;

    /* Start threads */
    ret = startSubThreads();
    if (1 != ret) {
        stopSubThreads();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Start Exec WhiteList Sub Threads Failed. Set [exitingFlag: true]!Exit..");
    }

    /* join whitelist sub threads */
    joinSubThreads();

end:
    exitingFlag_ = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecWhiteList] Exec WhiteList Main Thread End. Set [exitingFlag: true]!");
    return 1;
}


int ExecWhiteList::stopMainThread(){
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecWhiteList] Exec WhiteList Main Thread Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;
    stopSubThreads();
    return 1;
}


int ExecWhiteList::reloadExceptionPathList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] reloadExceptionPathList()");

    int ret = scanExceptionPathList_.reloadExceptionPathList();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Reload ExceptionPathList Failed.");
        return -1;
    }
    return 1;
}

int ExecWhiteList::initExceptionPathList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] initExceptionPathList()");

    int ret = scanExceptionPathList_.init();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Init ExceptionPathList Failed.");
        return -1;
    }
    return 1;
}


// uapi
int ExecWhiteList::init() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] init()");

    int ret = initConnection();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Init Connection Failed. Exit..");
        return -1;
    }

    ret = initDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Init Database Failed. Exit..");
        return -2;
    }

    ret = reloadWhiteListRuntimeMap();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Reload WhiteListRuntimeMap Failed. Exit..");
        return -3;
    }

    ret = initExceptionPathList();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Init ExceptionPathList Failed. Exit..");
        return -4;
    }

    ret = reloadExceptionPathList();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecWhiteList] Reload ExceptionPathList Failed. Exit..");
        return -5;
    }

    return 1;
}
