/*** 
 * @Author: JiaHao
 * @Date: 2024-05-24 14:52:21
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-22 10:28:33
 * @FilePath: /hostguard_linux/submodule/whitelist/udisk_whitelist.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */
#include "whitelist/udisk_whitelist.h"

using namespace sql;
extern Spdlogger logger;
extern volatile bool mainExitingFlag;


////////////////// UdiskRuntimeDevNodeEntry ///////////////////////
UdiskRuntimeDevNodeEntry::UdiskRuntimeDevNodeEntry(
    const std::string& devNode,
    const std::map<std::string, UdiskMountPoint>& mountPoints,
    bool isPluggedIn,
    int  mountRefCnt,
    const std::string& pluggedInTime
)
:   
    devNode_(devNode),
    mountPoints_(mountPoints),
    isPluggedIn_(isPluggedIn),
    mountRefCnt_(mountRefCnt),
    pluggedInTime_(pluggedInTime)
    
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] UdiskRuntimeDevNodeEntry(xx)");
}

UdiskRuntimeDevNodeEntry::~UdiskRuntimeDevNodeEntry(){
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] ~UdiskRuntimeDevNodeEntry()");
}

std::stringstream UdiskRuntimeDevNodeEntry::print() const {
    int i = 0;
    std::stringstream ss;
    ss  << "            "
        << "[DevNode: "         << std::left << std::setw(9) << devNode_   << "], "
        << "[isPluggedIn: "     << isPluggedIn_     << "], "
        << "[mountRefCnt: "     << mountRefCnt_     << "], "
        << "[pluggedInTime: "   << pluggedInTime_   << "]"  
        << std::endl << std::endl;

    for (const auto& pair : mountPoints_) {
        ss  << "                [" << i++ << "] "
            << "[PathStr: "         << std::left << std::setw(4) << pair.second.pathStr       << "], "
            << "[MountType: "       << std::left << std::setw(8) << pair.second.mountType     << "], "
            << "[MountFlags: "      << std::left << std::setw(6) << pair.second.mountFlags    << "]"            
            << std::endl;
    }

    // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskRuntimeDevNodeEntry] \n{}", ss.str().c_str());
    return ss;
}


////////////////// UdiskWhiteListEntry ///////////////////////
UdiskWhiteListEntry::UdiskWhiteListEntry(
    const UdiskDevice& device,
    const std::map<std::string, UdiskRuntimeDevNodeEntry>& runtimeDevNodes,
    const mount_mode& mountMode,
    int id,
    const std::string& time
)
:   
    device_(device),
    runtimeDevNodes_(runtimeDevNodes),
    mountMode_(mountMode),
    id_(id),
    time_(time)
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] UdiskWhiteListEntry(xx)");
}

UdiskWhiteListEntry::~UdiskWhiteListEntry(){
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] ~UdiskWhiteListEntry()");
}

std::stringstream UdiskWhiteListEntry::print() const {
    std::stringstream ss;
    ss  << "[udiskKey: "  << device_.udiskKey_  << "], "
        << "[vendorId: "  << device_.vendorId_  << "], "
        << "[productId: " << device_.productId_ << "], "
        << "[serialId: "  << device_.serialId_  << "], "
        << "[mountMode: " << mountMode_ << "]" << std::endl << std::endl;
    
    for (const auto& pairDevNode : runtimeDevNodes_) {
        ss  << pairDevNode.second.print().str() << std::endl;
    }
    // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskWhiteListEntry] \n{}", ss.str().c_str());
    return ss;
}


////////////////// UdiskWhiteList ///////////////////////

volatile bool& UdiskWhiteList::exitingFlag_ = mainExitingFlag;

UdiskWhiteList::UdiskWhiteList(
    MySQLConnectionPool* pConnectionPool, 
    const std::string& database, 
    const std::string& tableName
)
: 
    pConnectionPool_(pConnectionPool), 
    database_(database), 
    tableName_(tableName) 
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] UdiskWhiteList(xx...)");
}

UdiskWhiteList::~UdiskWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] ~UdiskWhiteList()");
    releaseConnection();
}

int UdiskWhiteList::initConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] initConnection()");
    
    std::shared_ptr<sql::Connection> connection = pConnectionPool_->getConnection();
    if (nullptr == connection) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Failed to getConnection: udiskWhiteList.connection_ == nullptr !");
        return -1;
    }

    connection_ = connection;
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskWhiteList] connection_: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection_.get()));
    return 1;
}

void UdiskWhiteList::releaseConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] releaseConnection()");
    if (nullptr != connection_) {
        pConnectionPool_->releaseConnection(connection_);
        connection_ = nullptr;
    }
}


int UdiskWhiteList::beginTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] beginTransaction()");

    try {
        pConnectionPool_->beginTransaction(connection_);
        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskWhiteList::createDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] createDatabase()");

    try {
        pConnectionPool_->createDatabase(connection_, database_);
        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskWhiteList::deleteTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] deleteTable()");

    try {
        bool exists = pConnectionPool_->hasTable(connection_, tableName_);
        if (exists) {
            pConnectionPool_->deleteTable(connection_, tableName_);
        }
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskWhiteList] Table deleted: {}", tableName_);
        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskWhiteList::createTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] createTable()");

    try {
        const std::string sql = "CREATE TABLE IF NOT EXISTS " + tableName_ +
                                " ("
                                "     id            INT AUTO_INCREMENT PRIMARY KEY, "
                                "     time          TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "  // automatic generate time
                                "     udiskKey      VARCHAR(512) UNIQUE, "
                                "     vendorId      VARCHAR(128), "
                                "     productId     VARCHAR(128), "
                                "     serialId      VARCHAR(256), "
                                "     mountMode     INT "
                                " )";
        pConnectionPool_->createTable(connection_, sql);
        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskWhiteList::deleteData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] deleteData()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement("DELETE FROM " + tableName_));

        pConnectionPool_->deleteData(connection_, pstmt);
        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskWhiteList::upsertData(const UdiskWhiteListEntry& whiteListEntry) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] upsertData()");
    
    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement(
                "INSERT INTO " + tableName_ +   "( "
                                                    "udiskKey, "
                                                    "vendorId, "
                                                    "productId, "
                                                    "serialId, "
                                                    "mountMode "
                                                ") "
                                                "VALUES (?, ?, ?, ?, ?) "
                                                "ON DUPLICATE KEY UPDATE mountMode = VALUES(mountMode)"
            )
        );
        pstmt->setString(1, whiteListEntry.device_.udiskKey_);
        pstmt->setString(2, whiteListEntry.device_.vendorId_);
        pstmt->setString(3, whiteListEntry.device_.productId_);
        pstmt->setString(4, whiteListEntry.device_.serialId_);
        pstmt->setInt(5, whiteListEntry.mountMode_);

        pConnectionPool_->upsertData(connection_, pstmt);

        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskWhiteList::retrieveData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] retrieveData()");

    try {
        std::unique_ptr<sql::ResultSet> result(nullptr);
        const std::string sql = "SELECT * FROM " + tableName_ + " LIMIT 4 OFFSET 0";
        pConnectionPool_->selectData(connection_, sql, result);

        // Handle result set
        while (!exitingFlag_ && result->next()) {
            UdiskWhiteListEntry  udiskWhiteListEntry = {};
            udiskWhiteListEntry.id_ = result->getInt("id");
            udiskWhiteListEntry.device_.udiskKey_ = result->getString("udiskKey");
            udiskWhiteListEntry.device_.vendorId_ = result->getString("vendorId");
            udiskWhiteListEntry.device_.productId_ = result->getString("productId");
            udiskWhiteListEntry.device_.serialId_ = result->getString("serialId");
            udiskWhiteListEntry.mountMode_=(mount_mode)result->getInt("mountMode");

            std::stringstream ss;
            ss  << "[UdiskWhiteList] [udiskKey: "  << udiskWhiteListEntry.device_.udiskKey_ 
                << "], [vendorId: "    << udiskWhiteListEntry.device_.vendorId_ 
                << "], [productId: "   << udiskWhiteListEntry.device_.productId_
                << "], [serialId: "    << udiskWhiteListEntry.device_.serialId_ 
                << "], [mountMode: "   << udiskWhiteListEntry.mountMode_ << "]";
                
            SPDLOG_LOGGER_INFO(logger.my_logger, "{}", ss.str().c_str());
        }

        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskWhiteList::endTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] endTransaction()");

    try {
        pConnectionPool_->endTransaction(connection_);
        // throw std::runtime_error("[UdiskWhiteList] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }
}


int UdiskWhiteList::initDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] initDatabase()");
    
    int ret = -1;

    ret = beginTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Begin Transaction Failed.");
        return -1;
    }

    ret = createDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Create Database Failed.");
        return -1;
    }

    // ret = deleteTable();
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Delete Table Failed.");
    //     return -1;
    // }

    ret = createTable();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Create Table Failed.");
        return -1;
    }

    ret = deleteData();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Delete Data Failed.");
        return -1;
    }

    UdiskWhiteListEntry udiskWhiteListEntryList[] = {
        {
            {"0951_1665_001BFC31A1C7E331194B69BD", "0951", "1665", "001BFC31A1C7E331194B69BD"},     /* xj */
            {}, 
            MOUNT_READ_WRITE
            // MOUNT_READ_ONLY
        },
        {
            {"17ef_3898_", "17ef", "3898", ""},     /* lenovo */
            {}, 
            // MOUNT_READ_WRITE
            MOUNT_READ_ONLY
        },
        // {
        //     {"0bda_9210_012345678906", "0bda", "9210", "012345678906"},     /* 移动硬盘盒 */
        //     {}, 
        //     // MOUNT_READ_WRITE
        //     MOUNT_READ_ONLY
        // },
        // {
        //     {"3535_6300_381C7636EFEBB7E0", "3535", "6300", "381C7636EFEBB7E0"},     /* zzc */
        //     {}, 
        //     MOUNT_READ_WRITE
        //     // MOUNT_READ_ONLY
        // }
    };

    for (const auto& udiskWhiteListEntry : udiskWhiteListEntryList) {
        ret = upsertData(udiskWhiteListEntry);
        if (1 != ret) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Upsert Data Failed.");
            return -1;
        }
    }

    ret = retrieveData();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Retrieve Data Failed.");
        return -1;
    }

    ret = endTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] End Transaction Failed.");
        return -1;
    }

    return 1;
}


int UdiskWhiteList::reloadWhiteListRuntimeMap() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] reloadWhiteListRuntimeMap()");

    int currentPageId = 0;
    int pageSize = 10000;
    std::map<std::string, UdiskWhiteListEntry> whiteListRuntimeMapTmp = {};

    auto start = getTimePoint();

    try {
        // 执行查询等操作
        while (!exitingFlag_) {
            std::unique_ptr<sql::ResultSet> result(nullptr);
            const std::string sql = "SELECT * FROM " + tableName_ + " LIMIT " + std::to_string(pageSize) + " OFFSET " + std::to_string(currentPageId * pageSize);
            pConnectionPool_->selectData(connection_, sql, result);
            
            // Handle result set
            while (!exitingFlag_ && result->next()) {
                UdiskWhiteListEntry whiteListEntry = {};
                whiteListEntry.id_ = result->getInt("id");
                whiteListEntry.device_.udiskKey_ = result->getString("udiskKey");
                whiteListEntry.device_.vendorId_ = result->getString("vendorId");
                whiteListEntry.device_.productId_ = result->getString("productId");
                whiteListEntry.device_.serialId_ = result->getString("serialId");
                whiteListEntry.mountMode_=(mount_mode)result->getInt("mountMode");
                
                /* update WhiteList Runtime MapTmp first */
                auto pair = whiteListRuntimeMapTmp.emplace(whiteListEntry.device_.udiskKey_, whiteListEntry);
                if (!pair.second) {
                    SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Insert Udisk WhiteListEntry failed, key already exists: {}", pair.first->first.c_str());
                }
            }

            // 检查是否还有更多数据
            if (result->rowsCount() < pageSize) {
                break;
            }

            currentPageId++;
        }

        // throw std::runtime_error("[UdiskWhiteList] test selectData");
        // return 1;

    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] MySQL error: {}", e.what());
        return -1;
    }

    /* 
        copy whiteListEntry from MapA, if the udisk dev has been plugged in. (WhiteListEntry & DevNodes & mountPoints)
    */
    std::unique_lock<std::mutex> lock(whiteListRuntimeMapMutex_);
    for (auto pair : whiteListRuntimeMapA_) {
        if (!pair.second.runtimeDevNodes_.empty()) {    /* if any udisk dev has been plugged in */
            if (whiteListRuntimeMapTmp.find(pair.first) != whiteListRuntimeMapTmp.end()) {
                /* copy runtimeDevNodes from MapA -> MapB */
                whiteListRuntimeMapTmp[pair.first].runtimeDevNodes_ = pair.second.runtimeDevNodes_;
            } else {
                /* copy WhiteListEntry from MapA -> MapB */
                whiteListRuntimeMapTmp[pair.first] = pair.second;
                whiteListRuntimeMapTmp[pair.first].mountMode_ = DEFAULT_MOUNT_MODE;
            }
        }
    }
    
    /* update pWhiteListRuntimeMap_ */
    whiteListRuntimeMapB_ = whiteListRuntimeMapTmp;                 /* copy the newest MapTmp to MapB */
    pWhiteListRuntimeMap_.store(&whiteListRuntimeMapB_);            /* point to MapB temporarily since it is the newest */
    lock.unlock();

    /* wait for all read operation using MapA finish */
    std::this_thread::sleep_for(std::chrono::milliseconds(runtimeMapSwitchWaitTimeMS_));    

    /* copy MapB to MapA, may take some time */
    lock.lock();
    whiteListRuntimeMapA_ = whiteListRuntimeMapB_;                  
    pWhiteListRuntimeMap_.store(&whiteListRuntimeMapA_);            /* back to use MapA */
    lock.unlock();
    
    /*  */
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskWhiteList] Reload WhiteListRuntimeMap Finish. [size : {}], [duration: {} seconds].", pWhiteListRuntimeMap_.load()->size(), duration.count() / 1000000.0);        
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskWhiteList] UdiskWhiteListRuntimeMap: \n{}", printWhiteListRuntimeMap().str().c_str());

    return 1;
}


/* uapi */
std::stringstream UdiskWhiteList::printWhiteListRuntimeMap() {
    int i = 0;
    std::stringstream ss;
    std::unique_lock<std::mutex> lock(whiteListRuntimeMapMutex_);
    std::map<std::string, UdiskWhiteListEntry>& whiteListRuntimeMap = *pWhiteListRuntimeMap_.load();

    for (const auto& pair : whiteListRuntimeMap) {
        ss  << std::left << std::setw(8) << ("[" + std::to_string(i++) + "]")
            << pair.second.print().str() << std::endl;
    }
    // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskWhiteList] UdiskWhiteListRuntimeMap: \n{}", ss.str().c_str());
    return ss;
}

int UdiskWhiteList::upsertDevNodeEntryInRuntimeMap(const UdiskDevice& device, const UdiskRuntimeDevNodeEntry& runtimeDevNodeEntry) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] upsertDevNodeEntryInRuntimeMap()");

    const std::string& udiskKey     = device.udiskKey_;
    const std::string& udiskDevNode = runtimeDevNodeEntry.devNode_;

    std::unique_lock<std::mutex> lock(whiteListRuntimeMapMutex_);
    std::map<std::string, UdiskWhiteListEntry>& whiteListRuntimeMap = *pWhiteListRuntimeMap_.load();

    /* find udiskKey in RuntimeMap_ */
    if (whiteListRuntimeMap.find(udiskKey) != whiteListRuntimeMap.end()) {

        auto pair = whiteListRuntimeMap[udiskKey].runtimeDevNodes_.emplace(udiskDevNode, runtimeDevNodeEntry);   // 移动构造
        if (!pair.second) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Insert RuntimeDevNodeEntry failed, key already exists: {}", pair.first->first.c_str());
            return -1;
        }

        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskWhiteList] Upsert DevNodeEntry In RuntimeMap OK. [udiskKey: {}], [DevNode: {}], [Mode: {}]", 
                                                udiskKey.c_str(), udiskDevNode.c_str(), whiteListRuntimeMap[udiskKey].mountMode_);
        return 1;

    } else {

        UdiskWhiteListEntry udiskWhiteListEntry = {
            device, 
            {
                {udiskDevNode, runtimeDevNodeEntry}
            }, 
            DEFAULT_MOUNT_MODE
        };
        
        auto pair = whiteListRuntimeMap.emplace(udiskKey, udiskWhiteListEntry);        
        if (!pair.second) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Insert WhiteListEntry failed, key already exists: {}", pair.first->first.c_str());
            return -2;
        }

        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskWhiteList] UdiskKey not in UdiskWhiteListRuntimeMap. Upsert DevNodeEntry In RuntimeMap OK. [udiskKey: {}], [DevNode: {}], [Mode: {}]", 
                                                udiskKey.c_str(), udiskDevNode.c_str(), DEFAULT_MOUNT_MODE);
        return 2;

    }
}


int UdiskWhiteList::deleteDevNodeEntryInRuntimeMap(const std::string& udiskKey, const std::string& devNode) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] deleteDevNodeEntryInRuntimeMap()");

    /* sleep 150ms ( In case force remove before umount, info still needed by kernel to check and by user space to record umount event ) */
    std::this_thread::sleep_for(std::chrono::milliseconds(150));  

    std::unique_lock<std::mutex> lock(whiteListRuntimeMapMutex_);  
    std::map<std::string, UdiskWhiteListEntry>& whiteListRuntimeMap = *pWhiteListRuntimeMap_.load();
    
    /* find udiskKey in RuntimeMap_ */
    if (whiteListRuntimeMap.find(udiskKey) != whiteListRuntimeMap.end()) {
        
        /* delete DevNode in RuntimeDevNodes */
        int removedNum = whiteListRuntimeMap[udiskKey].runtimeDevNodes_.erase(devNode);        
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskWhiteList] Delete DevNodeEntry In RuntimeMap OK. [udiskKey: {}], [DevNode: {}], [removedNum: {}]", 
                                                udiskKey.c_str(), devNode.c_str(), removedNum);

        if (whiteListRuntimeMap[udiskKey].mountMode_ == DEFAULT_MOUNT_MODE 
                && whiteListRuntimeMap[udiskKey].runtimeDevNodes_.empty()) {
            
            /* delete DEFAULT_MOUNT_MODE entry without any DevNode left in RuntimeMap */
            removedNum = whiteListRuntimeMap.erase(udiskKey);
            SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskWhiteList] Delete UdiskWhiteListEntry In RuntimeMap OK. [udiskKey: {}], [removedNum: {}]", 
                                                    udiskKey.c_str(), removedNum);
        }
        return 1;

    } else {

        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskWhiteList] Delete DevNodeEntry In RuntimeMap Failed. [udiskKey: {}], [DevNode: {}]: udiskKey not in UdiskWhiteListRuntimeMap", 
                                                udiskKey.c_str(), devNode.c_str());
        return -1;

    }
}



int UdiskWhiteList::init() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskWhiteList] init()");

    int ret = initConnection();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Init Connection Failed. Exit..");
        return -1;
    }

    ret = initDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Init Database Failed. Exit..");
        return -2;
    }
    
    ret = reloadWhiteListRuntimeMap();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Init WhiteListMap Failed. Exit..");
        return -3;
    }

    return 1;
}
