/*** 
 * @Author: JiaHao
 * @Date: 2024-07-04 13:35:36
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-23 09:42:52
 * @FilePath: /hostguard_linux/submodule/manager/exec_manager.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#include "manager/exec_manager.h"

extern Spdlogger logger;
extern volatile bool mainExitingFlag;

static std::vector<std::vector<std::string>> getJsonStringLists();

////////////////// ExecManager ///////////////////////

volatile bool& ExecManager::exitingFlag_ = mainExitingFlag;

ExecManager::ExecManager(
    MySQLConnectionPool* pConnectionPool
)
:
    pConnectionPool_(pConnectionPool)
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecManager] ExecManager(xx)");
}

ExecManager::~ExecManager() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecManager] ~ExecManager()");
}

// void ExecManager::signalHandler(int sig) {
//     exitingFlag_ = true;
//     SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecManager] signalHandler: exitingFlag_ = True."); 
// }

int ExecManager::startSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecManager] startSubThreads()");

    /* Check exiting flag */
    if (exitingFlag_) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecManager] ExitingFlag is True. No Need to Start Sub Threads. Exit..");
        return -1;
    }

    /* Exec WhiteList thread */
    try{

        std::thread execWhiteListMainThread = std::thread([this]() {
            this->pWhiteList_->runMainThread(); 
        });

        subThreadsMap_.emplace(
            ManagerSubThreadId::SUB_THREAD_WHITELIST_MAIN_THREAD,
            std::move(execWhiteListMainThread)       // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Exec WhiteList Main Thread Running...");

    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Failed to start Exec WhiteList Main Thread: {}. Set [exitingFlag: true]! Exit..", e.what());
        return -2;
    }

    /* Exec Monitor thread */
    try{

        std::thread execMonitorMainThread = std::thread([this]() {
            this->pMonitor_->runMainThread(); 
        });

        subThreadsMap_.emplace(
            ManagerSubThreadId::SUB_THREAD_MONITOR_MAIN_THREAD,
            std::move(execMonitorMainThread)       // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Exec Monitor Main Thread Running...");

    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Failed to start Exec Monitor Main Thread: {}. Set [exitingFlag: true]! Exit..", e.what());
        return -3;
    }

    return 1;
}

int ExecManager::stopSubThreads() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecManager] Exec Manager SubThreads Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;
    serviceRequestSemaphore_.release();
    // recordRequestSemaphore_.release();

    if (pMonitor_) {
        pMonitor_->stopMainThread();        /* monitor */
    }
    
    if (pWhiteList_) {
        pWhiteList_->stopMainThread();      /* whitelist */
    }    
    return 1;
}


int ExecManager::joinSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecManager] joinSubThreads()");

    /* join sub threads */
    for (auto& pair : subThreadsMap_) {
        if (pair.second.joinable()) {
            pair.second.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Sub Thread [{}] joined...", static_cast<int>(pair.first));
        }
    }
    return 1;
}


// uapi
int ExecManager::runMainThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecManager] runMainThread()");
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Exec Manager Main Thread Start.");

    int ret = -1;

    ExecWhiteList execWhiteList(pConnectionPool_, EVP_sha256());
    pWhiteList_ = &execWhiteList;
    ExecMonitor execMonitor(pWhiteList_, pConnectionPool_, EVP_sha256(), HgWorkModeOption::WORK_MODE_OPTION_WARNING);
    pMonitor_ = &execMonitor;

    /* ExecWhiteList */
    ret = execWhiteList.init();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "Init ExecWhiteList Failed. Exit..");
        goto end;
    }

    /* ExecMonitor */
    ret = execMonitor.init();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "Init ExecMonitor Failed. Exit..");
        goto end;
    }

    /* Sub Threads */
    ret = startSubThreads();
    if (1 != ret) {
        stopSubThreads();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Start Sub Threads Failed. Set [exitingFlag: true]! Exit..");
        goto join_threads;
    }


    /* 
    
        todo:
        1. IPC thread to communicate with web backend.
        2. Manager thread to handle user requests.
     */

    // /* wait for all ALL Sub Threads start finish */
    // std::this_thread::sleep_for(std::chrono::milliseconds(3000));

    // testExecRequestProcess();



join_threads:
    /* Join Sub Threads */
    joinSubThreads();

end:
    exitingFlag_ = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecManager] Exec Manager Main Thread End.");
   
    return 1;
}

int ExecManager::stopMainThread() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecManager] Exec Manager Main Thread Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;
    stopSubThreads();
    return 1;
}















/* 
    process functions
*/

/* Exec */

json ExecManager::processExecWorkModeQueryPacket(const json& packetJson) {
    HgExecSimplePacket packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_WORKMODE_QUERY) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_WORKMODE_QUERY!");
        }

        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Query command.
         */

        /* response packet */
        HgExecPacketWithWorkMode responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* getWorkMode */
        {
            // HgWorkModeOption workMode = pWhiteList_->getWorkMode();
            responsePacket.workMode_ = pMonitor_->getWorkMode();
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecWorkModeQueryPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json ExecManager::processExecWorkModeSetPacket(const json& packetJson) {
    HgExecPacketWithWorkMode packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_WORKMODE_SET) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_WORKMODE_SET!");
        }

        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Set command.
         */

        /* response packet */
        HgExecPacketWithWorkMode responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* setWorkMode */
        {
            int ret = pMonitor_->setWorkMode(packet.workMode_);
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Set WorkMode Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Set WorkMode Failed.");
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Set WorkMode Success.");
            }
        }

        /* synchronizeKernelWorkMode */
        {
            int ret = pMonitor_->synchronizeKernelWorkMode();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Synchronize Kernel WorkMode Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Synchronize Kernel WorkMode Failed.");
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Synchronize Kernel WorkMode Success.");
            }
        }

        /* lookupKernelWorkMode */
        {
            HgWorkModeOption workMode = HgWorkModeOption::WORK_MODE_OPTION_DEF;
            int ret = pMonitor_->lookupKernelWorkMode(workMode);
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Lookup Kernel WorkMode Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Lookup Kernel WorkMode Failed.");
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Lookup Kernel WorkMode Success.");
            }

            if (workMode != packet.workMode_) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Kernel WorkMode is not the same as Set WorkMode.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Kernel WorkMode is not the same as Set WorkMode.");
            }
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecWorkModeSetPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json ExecManager::processExecWhiteListReloadPacket(const json& packetJson) {
    HgExecSimplePacket packet;

    try {
        /* 
            request json -> packet
         */
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_WHITELIST_RELOAD) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_WHITELIST_RELOAD!");
        }

        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Reload command.
         */

        /* response packet */
        HgExecSimplePacket responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* reloadWhiteList */
        {
            int ret = pMonitor_->reloadWhiteList();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Reload WhiteList Failed.");
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Reload WhiteList Success.");
            }
        }
        
end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecWhiteListReloadPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json ExecManager::processExecExceptionPathReloadPacket(const json& packetJson) {
    HgExecSimplePacket packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_EXCEPTION_PATH_RELOAD) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_EXCEPTION_PATH_RELOAD!");
        }

        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Reload command.
        */

        /* response packet */
        HgExecSimplePacket responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* reloadExceptionPathList */
        {
            int ret = pWhiteList_->scanExceptionPathList_.reloadExceptionPathList();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Reload Exception PathList Failed.");
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Reload Exception PathList Success.");
            }
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecExceptionPathReloadPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}


json ExecManager::processExecPathScanStartPacket(const json& packetJson) {

    HgExecPacketWithPathList packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_PATH_SCAN_START) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_PATH_SCAN_START!");
        }
    
        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Start command.
        */

        std::string pathToScan = "";
        // std::string pathToScan = "/";
        // std::string pathToScan = "/home/JiaHao/test_dir/my_test_bin";
        // pathToScan = "/sys/kernel/tracing/";
        // pathToScan = "/";

        /* response packet */
        HgExecPacketWithIdList responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* check pathlist size, should be 1 */
        {
            if (packet.pathList_.size() != 1) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "PathList size should be 1!";
                goto end;
            } else {
                pathToScan = packet.pathList_[0].path_ ;    // "/home/JiaHao/test_dir/my_test_bin";
            }
        }

        /* check scanRunningFlag_ */
        {
            if (pWhiteList_->scanRunningFlag_.load() == true) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Scan is Running!";
                goto end;
            }
        }

        // /* get lastIdInDB_ */
        // {
        //     int ret = pWhiteList_->getLastIdInDB();
        //     if (1 != ret) {
        //         responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
        //         responsePacket.description_ = "Get Last Id In DB Failed!";
        //         SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Get Last Id In DB Failed.");
        //         goto end;
        //     } else {
        //         SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Get Last Id In DB Success.");
        //     }

            
        //     /* 
        //         send lastIdInDB_ to web backend

        //      */

        //     responsePacket.description_ = "lastIdInDB";
        //     responsePacket.idList_.emplace_back(pWhiteList_->lastIdInDB_.load());

        //     // send packet

        // }
        
        /* push to whitelist Scan Path Queue, 0.000279s*/
        {
            std::unique_lock<std::mutex> lock(pWhiteList_->scanRequestQueueMutex_);
            pWhiteList_->scanPathRequestQueue_.emplace(packet.id_, pathToScan);
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Exec Manager Scan Path Request: [path: {}].", pathToScan.c_str());
        }

        /* begin the scan transaction */
        {
            int ret = pWhiteList_->beginTransaction();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Begin WhiteList Transaction Failed!";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Begin WhiteList Transaction Failed.");
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Begin WhiteList Transaction Success.");
            }
        }

        /* scan request */
        {
            /* tell scan thread to work */
            pWhiteList_->scanRequestSemaphore_.release();

            /* 
                user could query candidates continuously

            */

            /* test scan stop */
            {
                // /* scan 5s */
                // std::this_thread::sleep_for(std::chrono::milliseconds(5000));

                // /* wait for scan stop */
                // {
                //     pWhiteList_->stopScan();
                // }

                // /* rollback */
                // {
                //     int ret = pWhiteList_->rollbackTransaction();
                //     if (1 != ret) {
                //         // responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                //         // responsePacket.description_ = "Rollback Transaction Failed.";
                //         SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Rollback Transaction Failed.");
                //         // goto end;
                //     } else {
                //         SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Rollback Transaction Success.");
                //     }
                // }
            }


            /* wait for scan finish */
            pWhiteList_->scanFinishSemaphore_.acquire();
        }

        /* scan mission result description */
        {
            std::stringstream ss;
            ScanPathResponse response = {};
            
            /* scan Response Queue */
            std::unique_lock<std::mutex> lock(pWhiteList_->scanResponseQueueMutex_);
            if (!pWhiteList_->scanPathResponseQueue_.empty()) {
                response = pWhiteList_->scanPathResponseQueue_.front();
                pWhiteList_->scanPathResponseQueue_.pop();
            } else {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] ScanPath Response Queue is empty!");
            }
            lock.unlock();

            if (response.isSuccess_) {
                responsePacket.description_ = "Scan Mission Success!";
            } else {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Scan Mission Interrupted!";
            }
            
            responsePacket.idList_.emplace_back(response.scannedFileCount_);
            responsePacket.idList_.emplace_back(response.candidateFileCount_);

            /* description */
            ss  << "[Path: "                    << pathToScan                   << "], "
                << "[Scanned File Count: "      << response.scannedFileCount_   << "], "
                << "[Candidate File Count: "    << response.candidateFileCount_ << "]";

            
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] scanPath Response:\n{}.", ss.str().c_str());
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecPathScanStartPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }    
}

json ExecManager::processExecPathScanStopPacket(const json& packetJson) {

    HgExecSimplePacket packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_PATH_SCAN_STOP) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_PATH_SCAN_STOP!");
        }

        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Stop command.
        */
        /* response packet */
        HgExecSimplePacket responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* scan stop */
        {
            pWhiteList_->stopScan();
        }

        /* rollback */
        {
            int ret = pWhiteList_->rollbackTransaction();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Rollback Transaction Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Rollback Transaction Failed.");
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Rollback Transaction Success.");
            }
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecPathScanStopPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json ExecManager::processExecCandidateDeletePacket(const json& packetJson) {

    HgExecPacketWithIdList packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_CANDIDATE_DELETE) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_CANDIDATE_DELETE!");
        }

        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Delete command.
        */

        /* response packet */
        HgExecPacketWithIdList responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;
        
        /* delete from database */
        {
            int i = 0;
            std::stringstream ss;

            std::map<unsigned long long, bool> resultMap = pWhiteList_->deleteEntryListInDB(packet.idList_);
            for (const auto& pair : resultMap) {
                ss  << "    [" << pair.first << "] " << pair.second << std::endl;
                if (pair.second == false) {
                    responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                    responsePacket.description_ = "Delete Candidate Entry In DataBase Failed.";
                    responsePacket.idList_.emplace_back(pair.first);
                    SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Delete Candidate Entry In DataBase Failed. [id: {}]", pair.first);
                }
            }
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Delete Candidate Entry In DataBase Result:\n{}", ss.str().c_str());
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecCandidateDeletePacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}


json ExecManager::processExecCandidateOverWritePacket(const json& packetJson) {

    HgExecSimplePacket packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_CANDIDATE_OVERWRITE) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_CANDIDATE_OVERWRITE!");
        }
    
        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute OverWrite command.
        */

        /* response packet */
        HgExecSimplePacket responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* 
            1. reload candidateListMap_ (select where CandidateFlag = True)
            2. send to go webackend and get user's decision (Need to delete some of candidates?)
        
         */

        /* delete entries if Candidate Flag is False */
        {
            int ret = pWhiteList_->deleteNonCandidateEntryInDB();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Delete Entries with Candidate Flag False In DB Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Delete Entries Candidate Flag is False In DB Failed.");
                pWhiteList_->rollbackTransaction();
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Delete Entries Candidate Flag is False In DB Success.");
            }
        }

        /* Now all entries left Candidate Flag is True */

        /* set all entries Candidate Flag False */
        {
            int ret = pWhiteList_->setCandidateFlagFalseInDB();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Set Candidate Flag False In DB Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Set Candidate Flag False In DB Failed.");
                pWhiteList_->rollbackTransaction();
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Set Candidate Flag False In DB Success.");
            }
        }

        /* set all entries Formal Flag True */
        {
            int ret = pWhiteList_->setFormalFlagTrueInDB();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Set Formal Flag True In DB Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Set Formal Flag True In DB Failed.");
                pWhiteList_->rollbackTransaction();
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Set Formal Flag True In DB Success.");
            }
        }

        // /* delete entries id under lastIdInDB_ */
        // {
        //     int ret = pWhiteList_->deleteEntryUnderLastIdInDB();
        //     if (1 != ret) {
        //         responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
        //         responsePacket.description_ = "Delete Entries Under Last Id In DB Failed.";
        //         SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Delete Entries Under Last Id In DB Failed.");
        //         pWhiteList_->rollbackTransaction();
        //         goto end;
        //     } else {
        //         SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Delete Entries Under Last Id In DB Success.");
        //     }
            
        // }

        /* commit the scan transaction */
        {
            int ret = pWhiteList_->endTransaction();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Commit Candidate Overwrite Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Commit Candidate Overwrite Failed.");
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Commit Candidate Overwrite Success.");
            }
        }

        // /* reload whiteListMap */
        // {
        //     int ret = pWhiteList_->reloadWhiteListRuntimeMap();
        //     if (1 != ret) {
        //         SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Reload WhiteList Runtime Map Failed.");
        //     } else {
        //         SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Reload WhiteList Runtime Map Success.");
        //     }
        // }
        
end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecCandidateOverWritePacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}

json ExecManager::processExecCandidateAppendPacket(const json& packetJson) {

    HgExecSimplePacket packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_CANDIDATE_APPEND) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_CANDIDATE_APPEND!");
        }
    
        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Append command.
        */
        /* response packet */
        HgExecSimplePacket responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;


        /* 
            1. reload candidateListMap_ (select where CandidateFlag = True)
            2. send to go webackend and get user's decision (Need to delete some of candidates?)
        
         */

        /* set all entries Candidate Flag False */
        {
            int ret = pWhiteList_->setCandidateFlagFalseInDB();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Set Candidate Flag False In DB Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Set Candidate Flag False In DB Failed.");
                pWhiteList_->rollbackTransaction();
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Set Candidate Flag False In DB Success.");
            }
        }

        /* set all entries Formal Flag True */
        {
            int ret = pWhiteList_->setFormalFlagTrueInDB();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Set Formal Flag True In DB Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Set Formal Flag True In DB Failed.");
                pWhiteList_->rollbackTransaction();
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Set Formal Flag True In DB Success.");
            }
        }

        /* commit the scan transaction */
        {
            int ret = pWhiteList_->endTransaction();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Commit Candidate Append Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Commit Candidate Append Failed.");
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Commit Candidate Append Success.");
            }
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecCandidateAppendPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}


json ExecManager::processExecCandidateDropPacket(const json& packetJson) {

    HgExecSimplePacket packet;

    try {
        packet.fromJson(packetJson);
        if (packet.getSubCode() != HgExecSubCode::EXEC_SUBCODE_CANDIDATE_DROP) {
            throw std::invalid_argument("SubCode is not EXEC_SUBCODE_CANDIDATE_DROP!");
        }
    
        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Drop command.
        */

        /* response packet */
        HgExecSimplePacket responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;


        /* rollback */
        {
            int ret = pWhiteList_->rollbackTransaction();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                responsePacket.description_ = "Rollback Candidate Data Failed.";
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Rollback Candidate Data Failed.");
                goto end;
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Rollback Candidate Data Success.");
            }
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecCandidateDropPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}



json ExecManager::processExecPacket(const json& packetJson) {

    HgExecPacket packet;
    
    try {
        /* json -> HgExecPacket */
        packet.fromJson(packetJson);
        std::cout << packet.print().str() << std::endl;

        /* check subcode */
        switch (packet.getSubCode()) {
        case HgExecSubCode::EXEC_SUBCODE_WORKMODE_QUERY:            // √
            return processExecWorkModeQueryPacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_WORKMODE_SET:              // √
            return processExecWorkModeSetPacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_WHITELIST_RELOAD:          // √
            return processExecWhiteListReloadPacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_EXCEPTION_PATH_RELOAD:     // √
            return processExecExceptionPathReloadPacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_PATH_SCAN_START:           // √
            return processExecPathScanStartPacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_PATH_SCAN_STOP:            // √
            return processExecPathScanStopPacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_CANDIDATE_DELETE:          // √
            return processExecCandidateDeletePacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_CANDIDATE_OVERWRITE:       // √
            return processExecCandidateOverWritePacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_CANDIDATE_APPEND:          // √
            return processExecCandidateAppendPacket(packetJson);
            // break;
        case HgExecSubCode::EXEC_SUBCODE_CANDIDATE_DROP:            // √
            return processExecCandidateDropPacket(packetJson);
            // break;
        default:
            std::string errmsg = std::string("[Invalid SubCode: ") + std::to_string((int)packet.getSubCode()) + "]";
            throw std::invalid_argument(errmsg);
            break;
        }
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processExecPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}














void ExecManager::testExecRequestProcess() {
    {
        /* 
            1. send request json.
            2. recv response json.
            3. parse response json.
        */
        int i = 0;
        std::vector<std::vector<std::string>> jsonStringLists = getJsonStringLists();
        std::vector<std::string> requestJsonStringList = jsonStringLists[0];
        std::vector<std::string> responseJsonStringList = jsonStringLists[1];

        for(const auto& jsonstr : requestJsonStringList) {
            std::cout   << "request jsonstr ["  << i << "]: \n" << jsonstr << std::endl << std::endl;
            try {

                /*
                    1. Parse & Process the request json.
                    2. Get response json.
                */
                json responseJson = processExecPacket(json::parse(jsonstr));
                
                // /* compare */
                // json responseJsonExpected = json::parse(responseJsonStringList[i]);
                // if (responseJson == responseJsonExpected) {
                //     std::cout << "Response Json String Matched!" << std::endl;
                // } else {
                //     std::cerr   << "Response Json String Not Matched! Expected: \n"
                //                 << responseJsonStringList[i] <<std::endl;
                // }
                
            } catch (const std::exception& e) {
                std::cout << e.what() << std::endl;
            }
            
            std::cout   << "\n\n---------------------------------------------------------------------------------\n\n" << std::endl << std::endl;
            
            i++;
        }
        
    }

}














static std::vector<std::vector<std::string>> getJsonStringLists() {
    /* 
        WorkMode Query 
    */
    
// {
//     "id": 0,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 1
// }

    std::string HgExecWorkModeQueryPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(0)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                         + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_WORKMODE_QUERY)   + std::string("\n")     +
        std::string("}");

    std::string HgExecWorkModeQueryResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 0,
    "status": 1,
    "subCode": 1,
    "type": 1,
    "workMode": 2
})";



    /* 
        WorkMode Set
    */

// {
//     "id": 2,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 2,
//     "workMode": 2
// }

    std::string HgExecWorkModeSetPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(2)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                         + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_WORKMODE_SET)     + std::string(",\n")    +
        std::string("    \"workMode\": ")   + std::to_string((int)HgWorkModeOption::WORK_MODE_OPTION_BLOCK)   + std::string("\n")     +
        std::string("}");

    std::string HgExecWorkModeSetResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 2,
    "status": 1,
    "subCode": 2,
    "type": 1,
    "workMode": 0
})";


    /* 
        Exec Whitelist Reload 
    */

// {
//     "id": 8,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 3
// }


    std::string HgExecWhiteListReloadPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(8)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                         + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_WHITELIST_RELOAD) + std::string("\n")  +
        std::string("}");


    std::string HgExecWhiteListReloadResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 8,
    "status": 1,
    "subCode": 3,
    "type": 1
})";


    /* 
        Exec Exeception Path Reload
    */

// {
//     "id": 9,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 4
// }

    std::string HgExecExceptionPathReloadPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(9)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                         + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_EXCEPTION_PATH_RELOAD) + std::string("\n")  +
        std::string("}");

    std::string HgExecExceptionPathReloadResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 9,
    "status": 1,
    "subCode": 4,
    "type": 1
})";


    /* 
        Exec Path Scan Start
    */

// {
//     "id": 13,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 5,
//     "pathList": [                
//         {                          
//             "path":  "/"        
//         }                          
//     ] 
// }

    std::string HgExecPathScanStartPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(13)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                        + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_PATH_SCAN_START) + std::string(",\n")  +
        std::string("    \"pathList\": [                \n")    +
        std::string("        {                          \n")    +
        // std::string("            \"path\":  \"/home/JiaHao/Documents/test_spdlog\"        \n")    +
        // std::string("            \"path\":  \"/home/JiaHao/test_dir/my_test_bin\"        \n")    +
        std::string("            \"path\":  \"/\"        \n")   +
        std::string("        }                          \n")    +
        std::string("    ] \n")                                 +
        std::string("}");

    std::string HgExecPathScanStartResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 13,
    "status": 1,
    "subCode": 5,
    "type": 1
})";


    /* 
        Exec Path Scan Stop
     */

// {
//     "id": 15,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 6
// }

    std::string HgExecPathScanStopPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(15)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                        + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_PATH_SCAN_STOP) + std::string("\n")  +
        std::string("}");

    std::string HgExecPathScanStopResponsePacketJsonString = 
R"({
    "code": 2,
    "id": 15,
    "status": 1,
    "subCode": 6,
    "type": 1
})";


    /* 
        Exec Candidate Delete
     */

// {
//     "id": 16,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 7,
//     "idList": [      
//             1,         
//             87103      
//    ]                   
// }


    std::string HgExecCandidateDeletePacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(16)                                                + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                         + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_CANDIDATE_DELETE)  + std::string(",\n")  +
        std::string("    \"idList\": [      \n")    +
        std::string("            1,         \n")    +
        std::string("            87142      \n")    +
        std::string("   ]                   \n")    +
        std::string("}");

    std::string HgExecCandidateDeleteResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 16,
    "idList": null,
    "status": 1,
    "subCode": 7,
    "type": 1
})";

    /* 
        Exec Candidate OverWrite
     */

// {
//     "id": 17,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 8
// }

    std::string HgExecCandidateOverWritePacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(17)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                        + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_CANDIDATE_OVERWRITE) + std::string("\n")  +
        std::string("}");

    std::string HgExecCandidateOverWriteResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 17,
    "status": 1,
    "subCode": 8,
    "type": 1
})";

    /* 
        Exec Candidate Append
     */

// {
//     "id": 18,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 9
// }

    std::string HgExecCandidateAppendPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(18)                                                + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                         + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_CANDIDATE_APPEND) + std::string("\n")  +
        std::string("}");

    std::string HgExecCandidateAppendResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 18,
    "status": 1,
    "subCode": 9,
    "type": 1
})";

    /* 
        HgExecCandidateDropRequest
     */

// {
//     "id": 19,
//     "type": 0,
//     "status": 0,
//     "code": 2,
//     "subCode": 10
// }


    std::string HgExecCandidateDropPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(19)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_EXEC)                        + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgExecSubCode::EXEC_SUBCODE_CANDIDATE_DROP) + std::string("\n")  +
        std::string("}");

    std::string HgExecCandidateDropResponsePacketJsonString = 
R"({
    "code": 2,
    "description": "",
    "id": 19,
    "status": 1,
    "subCode": 10,
    "type": 1
})";


    int i = 0;

    /* 
        JsonString
     */

/* request */
    std::vector<std::string> JsonStringList = {};
    
    /* Exec */
    // JsonStringList.emplace_back(HgExecWorkModeQueryPacketJsonString);
    // JsonStringList.emplace_back(HgExecWorkModeSetPacketJsonString);
    JsonStringList.emplace_back(HgExecPathScanStartPacketJsonString);
    // JsonStringList.emplace_back(HgExecPathScanStopPacketJsonString);
    // JsonStringList.emplace_back(HgExecCandidateDeletePacketJsonString);
    // JsonStringList.emplace_back(HgExecCandidateOverWritePacketJsonString);
    // JsonStringList.emplace_back(HgExecCandidateAppendPacketJsonString);
    // JsonStringList.emplace_back(HgExecCandidateDropPacketJsonString);
    // JsonStringList.emplace_back(HgExecWhiteListReloadPacketJsonString);
    // JsonStringList.emplace_back(HgExecExceptionPathReloadPacketJsonString);

/* response */
    std::vector<std::string> responseJsonStringList = {};
    // /* WorkMode */
    // responseJsonStringList.emplace_back(HgWorkModeQueryResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgWorkModeUpdateResponsePacketJsonString);

    // /* Udisk */
    // responseJsonStringList.emplace_back(HgUdiskWhiteListQueryResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgUdiskCandidateQueryResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgUdiskWhitelistUpdateResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgUdiskCandidateAppendResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgUdiskWhitelistDeleteResponsePacketJsonString);
    
    /* Exec */
    // responseJsonStringList.emplace_back(HgExecWhiteListReloadResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgExecExceptionPathReloadResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgExecPathScanStartResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgExecPathScanStopResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgExecCandidateDeleteResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgExecCandidateOverWriteResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgExecCandidateAppendResponsePacketJsonString);
    // responseJsonStringList.emplace_back(HgExecCandidateDropResponsePacketJsonString);

    std::vector<std::vector<std::string>> jsonStrLists= {JsonStringList, responseJsonStringList};
    return jsonStrLists;
}


