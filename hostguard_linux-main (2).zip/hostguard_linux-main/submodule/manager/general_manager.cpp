/*** 
 * @Author: JiaHao
 * @Date: 2024-07-25 15:20:45
 * @LastEditors: Jaxion
 * @LastEditTime: 2024-07-26 09:51:08
 * @FilePath: /hostguard_linux/submodule/manager/general_manager.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#include "manager/general_manager.h"

extern Spdlogger logger;
extern volatile bool mainExitingFlag;

////////////////// GeneralManager ///////////////////////

volatile bool& GeneralManager::exitingFlag_ = mainExitingFlag;

GeneralManager::GeneralManager(
    UdiskManager* pUdiskManager, 
    ExecManager* pExecManager
) 
:   pUdiskManager_(pUdiskManager),
    pExecManager_(pExecManager)
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] GeneralManager(xx...)");
}
int GeneralManager::init() {
    if (unixSocketServer_.init() != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Failed to initialize UnixSocketServer");
        return -1;
    }

    SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Server initialized, waiting for connections...");

    return 1;
}


json GeneralManager::getJson(const std::string& jsonStr) {
    try {
        return json::parse(jsonStr);
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error getJson(): \n") + std::string(e.what()) + "\n";
        errmsg += std::string("Json String: \n") + jsonStr;
        throw std::invalid_argument(errmsg);
    }
}


/* 
    General Process Packet function
 */
json GeneralManager::processHgPacket(const json& packetJson) {
    
    HgPacket packet;

    try {
        /* json -> HgPacket */
        packet.fromJson(packetJson);
        std::cout << packet.print().str() << std::endl;

        /* process methods */
        switch (packet.getCode()) {
        case HgCode::HG_CODE_UDISK:
            return pUdiskManager_->processUdiskPacket(packetJson);

        case HgCode::HG_CODE_EXEC:
            return pExecManager_->processExecPacket(packetJson);

        default:
            std::string errmsg = std::string("Error: [Unknown Code: ") + std::to_string((int)packet.getCode()) + "]";
            throw std::invalid_argument(errmsg);
            break;
        }
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processHgPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(e.what());
    }
}

/* 
    Sub Threads
*/
int GeneralManager::processPacket(std::string packet) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] processPacket()");

    json responsePacketJson = {};
    
    /*
        1. Parse & Process the request json.
        2. Get response json.
    */
    try {
        /* jsonStr -> json */
        json jsonObject = getJson(packet);
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[GeneralManager] Packet JSON: \n {}", jsonObject.dump(4));

        responsePacketJson = processHgPacket(jsonObject);

        if (exitingFlag_) {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] exitingFlag_ is True, processPacket() return.");
            return -1;
        }
    } catch (const std::exception& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Process packet error: {}", e.what());
        return -2;
    }


    /* send response */
    std::string responsePacket = responsePacketJson.dump(4);
    if (unixSocketServer_.sendMessage(responsePacket) == -1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Failed to send packet.");
        return -3;
    }

    SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Send response packet success.");
    return 1;
}

int GeneralManager::runPacketProcessThread(int id) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] runPacketProcessThread[{}] Start!", id);

    std::string packet = {};

    /* process packet comming */
    while(!exitingFlag_) {

        /* wait for Semaphore */
        packetProcessRequestSemaphore_.acquire();
        SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] packetProcessRequestSemaphore_ got by PacketProcess Thread[{}].", id);
        
        /* sub thread should exit now */
        if (exitingFlag_) {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Break PacketProcess Thread[{}] While Loop.", id);
            break;
        }

        /* lock & pop from queue */
        {
            std::unique_lock<std::mutex> lock(packetProcessRequestQueueMutex_);
            if (!packetProcessRequestQueue_.empty()) {
                packet = packetProcessRequestQueue_.front();
                packetProcessRequestQueue_.pop();
            } else {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] PacketProcess Thread[{}] Queue is empty!", id);
                continue;
            }
        }

        /* work */
        {
            int ret = processPacket(packet);

            if (-1 == ret) {
                SPDLOG_LOGGER_WARN(logger.my_logger, "[GeneralManager] exitingFlag_ is True. PacketProcess Thread[{}] is exitting...", id);
                break;
            }

            if (1 != ret) {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] PacketProcess Thread[{}] process packet failed.", id);
            }
        }
    }

end:
    exitingFlag_ = true;

    SPDLOG_LOGGER_WARN(logger.my_logger, "[GeneralManager] PacketProcess Thread[{}] end. Set [exitingFlag: true]!", id);
    return 0;
}

void GeneralManager::runServerThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] runServerThread()");

    int rnt = 0;
    while (!exitingFlag_) {
        /* accept */
        rnt = unixSocketServer_.acceptConnection();
        if (-3 == rnt) {
            SPDLOG_LOGGER_WARN(logger.my_logger, "[GeneralManager] exitingFlag_ is True. Accepting connection is stopped.");
            continue;  /* accept next connect */
        }

        if (rnt != 1) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Failed to accept connection.");
            continue;  /* accept next connect */
        }
        SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Client connected.");

        int cnt = 0;
        /* communicate with client */
        while (!exitingFlag_) {
            std::cout   << "\n\n---------------------------------------------------------------------------------\n\n" << std::endl << std::endl;
            
            std::vector<char> receivedPacket(BUFFER_SIZE, 0);   /* memset to 0 */

            /* recv -> vector */
            long readSize = unixSocketServer_.receiveMessage(receivedPacket, BUFFER_SIZE);
            if (readSize == 0) {
                SPDLOG_LOGGER_WARN(logger.my_logger, "[GeneralManager] Connection is closed by client.");
                break;
            }

            if (readSize == -3) {
                SPDLOG_LOGGER_WARN(logger.my_logger, "[GeneralManager] exitingFlag_ is True. Receiving packet is stopped.");
                break;
            }

            if (readSize < 0) {    /* number read, -1 for errors or 0 for EOF. */
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Failed to receive packet.");
                break;
            }
            
            /* vector -> string */
            std::string packet(receivedPacket.begin(), receivedPacket.end());
            std::cout << "[GeneralManager] Received packet[" << cnt++ << "]: \n" << packet << std::endl;


            /* Use ThreadPool to process packet*/
            {
                std::unique_lock<std::mutex> lock(packetProcessRequestQueueMutex_);
                packetProcessRequestQueue_.emplace(packet);
                lock.unlock();

                packetProcessRequestSemaphore_.release();
            }
        }

        unixSocketServer_.cleanClientFd();
        SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Client disconnected, waiting for new connections...");
    }

end:
    exitingFlag_ = true;
    SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] runServerThread() End. Set [exitingFlag: true]!");
}


int GeneralManager::startSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] startSubThread()");

    /* Check exiting flag */
    if (exitingFlag_) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[GeneralManager] ExitingFlag is True. No Need to Start Sub Threads. Exit..");
        return -1;
    }

    /* Server thread*/
    try {
        std::thread serverThread = std::thread([this]() {
            this->runServerThread(); 
        });
        serverThread_ = std::move(serverThread);    // 移动操作，thread 对象不可拷贝

        SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Server Thread Running...");

    } catch (const std::system_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Failed to start Server Thread: {}. Exit..", e.what());
        return -2;
    }


    /* Packet process threadpool */
    try {
        SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Hardware [Concurrency: {}].", packetProcessThreadNum_);
        for (int i = 0; i < packetProcessThreadNum_; ++i) {
            packetProcessThreads_.emplace_back(
                [this, i](){
                    this->runPacketProcessThread(i);
                }
            );
            SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Sub Thread PacketProcess Thread[{}] Running...", i);
        }
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Failed to run Sub Thread PacketProcess Thread. Error: {}. Set [exitingFlag: true]!", e.what());
        return -3;
    }

    return 1;
}

int GeneralManager::stopSubThreads() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[GeneralManager] Exec Manager SubThreads Stopping. Set [exitingFlag: true]!");
    
    exitingFlag_ = true;

    /* stop packet process threadpool */
    for (auto& packetProcessThread : packetProcessThreads_) {
        packetProcessRequestSemaphore_.release();
    }
    
    return 1;
}

int GeneralManager::joinSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] joinSubThreads()");

    /* join packet process threadpool */
    int i = 0;
    for (auto& packetProcessThread : packetProcessThreads_) {
        if (packetProcessThread.joinable()) {
            packetProcessThread.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecWhiteList] PacketProcess Thread [{}] joined...", i);
        }
        i++;
    }

    /* join thread */
    if (serverThread_.joinable()) {
        serverThread_.join();
        SPDLOG_LOGGER_INFO(logger.my_logger, "[GeneralManager] Sub Thread joined...");
    }
    return 1;
}


/* 
    Main Thread
*/
int GeneralManager::runMainThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[GeneralManager] runMainThread()");

    /* Sub Threads */
    int ret = startSubThreads();
    if (1 != ret) {
        stopSubThreads();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[GeneralManager] Start Sub Threads Failed. Set [exitingFlag: true]! Exit..");
        goto join_threads;
    }

join_threads:
    /* Join Sub Threads */
    joinSubThreads();

end:
    exitingFlag_ = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[GeneralManager] GeneralManager Main Thread End.");
    
    return 1;
}

int GeneralManager::stopMainThread() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[GeneralManager] Exec Manager Main Thread Stopping. Set [exitingFlag: true]!");

    exitingFlag_ = true;
    stopSubThreads();
    return 1;
}

