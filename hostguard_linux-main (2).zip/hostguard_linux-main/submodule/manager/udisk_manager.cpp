/*** 
 * @Author: JiaHao
 * @Date: 2024-05-13 15:16:00
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-21 17:23:06
 * @FilePath: /hostguard_linux/submodule/manager/udisk_manager.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */

#include "manager/udisk_manager.h"

extern Spdlogger logger;
extern volatile bool mainExitingFlag;

static std::vector<std::vector<std::string>> getJsonStringLists();

////////////////// UdiskManager ///////////////////////

volatile bool& UdiskManager::exitingFlag_ = mainExitingFlag;

UdiskManager::UdiskManager(
    MySQLConnectionPool* pConnectionPool
)
:
    pConnectionPool_(pConnectionPool)
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskManager] UdiskManager(xx)");
}

UdiskManager::~UdiskManager() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskManager] ~UdiskManager()");
}

// void UdiskManager::signalHandler(int sig) {
//     exitingFlag_ = true;
//     SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskManager] signalHandler: exitingFlag_ = True."); 
// }

int UdiskManager::startSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskManager] startSubThreads()");

    /* Check exiting flag */
    if (exitingFlag_) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskManager] ExitingFlag is True. No Need to run Sub Threads. Exit..");
        return -1;
    }

    /* Udisk Monitor thread */
    try{

        std::thread udiskMonitorMainThread = std::thread([this]() {
            this->pMonitor_->runMainThread(); 
        });

        subThreadsMap_.emplace(
            ManagerSubThreadId::SUB_THREAD_MONITOR_MAIN_THREAD,
            std::move(udiskMonitorMainThread)       // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskManager] Udisk Monitor Main Thread Running...");

    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskManager] Failed to start Udisk Monitor Main Thread: {}. Set [exitingFlag: true]! Exit..", e.what());
        return -2;
    }

    return 1;
}

int UdiskManager::stopSubThreads() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskManager] Udisk Manager SubThreads Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;
    if (pMonitor_) {
        pMonitor_->stopMainThread();        /* monitor */
    }
    return 1;
}


int UdiskManager::joinSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskManager] joinSubThreads()");

    /* join sub threads */
    for (auto& pair : subThreadsMap_) {
        if (pair.second.joinable()) {
            pair.second.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskManager] Sub Thread [{}] joined...", static_cast<int>(pair.first));
        }
    }
    return 1;
}

// uapi
int UdiskManager::runMainThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskManager] runMainThread()");
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskManager] Udisk Manager Main Thread Start.");

    int ret = -1;
    
    UdiskWhiteList udiskWhiteList(pConnectionPool_);
    pWhiteList_ = &udiskWhiteList;
    UdiskMonitor udiskMonitor(pWhiteList_, pConnectionPool_);
    pMonitor_ = &udiskMonitor;

    /* UdiskWhiteList */
    ret = udiskWhiteList.init();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "Init UdiskWhiteList Failed. Exit..");
        goto end;
    }

    /* UdiskMonitor */
    ret = udiskMonitor.init();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "Init UdiskMonitor Failed. Exit..");
        goto end;
    }

    /* Sub Threads */
    ret = startSubThreads();
    if (1 != ret) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskManager] Start Sub Threads Failed. Set [exitingFlag: true]! Exit..");
        goto join_threads;
    }

    /* 
    
        todo:
        1. IPC thread to communicate with web backend.
        2. Manager thread to handle user requests.
     */

    // /* wait for all ALL Sub Threads start finish */
    // std::this_thread::sleep_for(std::chrono::milliseconds(3000));

    // {
    //     while(!exitingFlag_) {
    //         /* 
    //             1. send request json.
    //             2. recv response json.
    //             3. parse response json.
    //         */
    //         testUdiskRequestProcess();
    //         std::this_thread::sleep_for(std::chrono::milliseconds(5000));
    //     }
    // }

    

join_threads:
    /* Join Sub Threads */
    joinSubThreads();

end:
    exitingFlag_ = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskManager] Udisk Manager Main Thread End.");
   
    return 1;
}


int UdiskManager::stopMainThread() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskManager] Udisk Manager Main Thread Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;
    stopSubThreads();
    return 1;
}
























void UdiskManager::testUdiskRequestProcess() {
    {
        /* 
            1. send request json.
            2. recv response json.
            3. parse response json.
        */
        int i = 0;
        std::vector<std::vector<std::string>> jsonStringLists = getJsonStringLists();
        std::vector<std::string> requestJsonStringList = jsonStringLists[0];
        std::vector<std::string> responseJsonStringList = jsonStringLists[1];

        for(const auto& jsonstr : requestJsonStringList) {
            std::cout   << "request jsonstr ["  << i << "]: \n" << jsonstr << std::endl << std::endl;
            try {

                /*
                    1. Parse & Process the request json.
                    2. Get response json.
                */
                json responseJson = processUdiskPacket(json::parse(jsonstr));
                
                // /* compare */
                // json responseJsonExpected = json::parse(responseJsonStringList[i]);
                // if (responseJson == responseJsonExpected) {
                //     std::cout << "Response Json String Matched!" << std::endl;
                // } else {
                //     std::cerr   << "Response Json String Not Matched! Expected: \n"
                //                 << responseJsonStringList[i] <<std::endl;
                // }
                
            } catch (const std::exception& e) {
                std::cout << e.what() << std::endl;
            }
            
            std::cout   << "\n\n---------------------------------------------------------------------------------\n\n" << std::endl << std::endl;
            
            i++;
        }
        
    }

}




/* 
    Actual parse functions：

    void processUdiskPacket(const json& packetJson);

    json processUdiskWhiteListReloadPacket(const json& packetJson);

*/

/* Udisk */
json UdiskManager::processUdiskWhiteListReloadPacket(const json& packetJson) {

    HgUdiskSimplePacket packet;

    try {
        packet.fromJson(packetJson);

        if (packet.getSubCode() != HgUdiskSubCode::UDISK_SUBCODE_WHITELIST_RELOAD) {
            throw std::invalid_argument("SubCode is not UDISK_SUBCODE_WHITELIST_RELOAD!");
        }
    
        std::cout << packet.print().str() << std::endl;

        /* 
            1. execute Reload command.
            2. build response packet.
        */
        /* response packet */
        HgUdiskSimplePacket responsePacket = {packet.getSubCode()};
        responsePacket.id_      = packet.id_;
        responsePacket.type_    = HgType::HG_TYPE_RESPONSE;
        responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_SUCCESS;

        /* reloadWhiteList */
        {
            int ret = pMonitor_->reloadWhiteList();
            if (1 != ret) {
                responsePacket.status_  = HgRspStatus::HG_RSP_STATUS_FAILED;
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecManager] Reload WhiteList Failed.");
            } else {
                SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecManager] Reload WhiteList Success.");
            }
        }

end:
        /* packet -> json */
        json newPacketJson = packet.toJson();
        std::cout << "newPacketJson JSON: \n" << newPacketJson.dump(4) << std::endl;
        json responsePacketJson = responsePacket.toJson();
        std::cout << "responsePacket JSON: \n" << responsePacketJson.dump(4) << std::endl;

        return responsePacketJson;

    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processUdiskWhiteListReloadPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}


json UdiskManager::processUdiskPacket(const json& packetJson) {

    HgUdiskPacket packet;

    try {
        /* json -> HgUdiskPacket */
        packet.fromJson(packetJson);
        std::cout << packet.print().str() << std::endl;

        /* check subcode */
        switch (packet.getSubCode()) {
        case HgUdiskSubCode::UDISK_SUBCODE_WHITELIST_RELOAD:
            return processUdiskWhiteListReloadPacket(packetJson);
            // break;
        default:
            std::string errmsg = std::string("[Invalid SubCode: ") + std::to_string((int)packet.getSubCode()) + "]";
            throw std::invalid_argument(errmsg);
            break;
        }
    } catch (const std::exception& e) {
        std::string errmsg = std::string("Error processUdiskPacket(): \n") + std::string(e.what());
        throw std::invalid_argument(errmsg);
    }
}















static std::vector<std::vector<std::string>> getJsonStringLists() {
    /* 
        Udisk Whitelist Reload 
    */

// {
//     "id": 3,
//     "type": 0,
//     "status": 0,
//     "code": 1,
//     "subCode": 1
// }


    std::string HgUdiskWhiteListReloadPacketJsonString = 
        std::string("{\n") +
        std::string("    \"id\": ")         + std::to_string(3)                                                 + std::string(",\n")    +
        std::string("    \"type\": ")       + std::to_string((int)HgType::HG_TYPE_REQUEST)                      + std::string(",\n")    +
        std::string("    \"status\": ")     + std::to_string((int)HgRspStatus::HG_RSP_STATUS_DEF)               + std::string(",\n")    +
        std::string("    \"code\": ")       + std::to_string((int)HgCode::HG_CODE_UDISK)                        + std::string(",\n")    +
        std::string("    \"subCode\": ")    + std::to_string((int)HgUdiskSubCode::UDISK_SUBCODE_WHITELIST_RELOAD)+ std::string("\n")  +
        std::string("}");

    std::string HgUdiskWhiteListReloadResponsePacketJsonString = 
R"({
    "code": 1,
    "id": 3,
    "status": 1,
    "subCode": 3,
    "type": 1
})";



    int i = 0;

    /* 
        JsonString
     */

/* request */
    std::vector<std::string> JsonStringList = {};

    /* Udisk */
    JsonStringList.emplace_back(HgUdiskWhiteListReloadPacketJsonString);

/* response */
    std::vector<std::string> responseJsonStringList = {};

    /* Udisk */
    responseJsonStringList.emplace_back(HgUdiskWhiteListReloadResponsePacketJsonString);

    
    
    std::vector<std::vector<std::string>> jsonStrLists= {JsonStringList, responseJsonStringList};
    return jsonStrLists;
}


