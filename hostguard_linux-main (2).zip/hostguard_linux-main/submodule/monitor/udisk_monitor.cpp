/*** 
 * @Author: JiaHao
 * @Date: 2024-05-13 15:16:00
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-22 15:59:13
 * @FilePath: /hostguard_linux/submodule/monitor/udisk_monitor.cpp
 * @Description: 
 * @
 * @Copyright (c) 2024 by JiaHao, All Rights Reserved. 
 */


#include "monitor/udisk_monitor.h"
#include "udisk_monitor.skel.h"

extern Spdlogger logger;
extern volatile bool mainExitingFlag;

std::string getLocalTimeStr() {
    char ts[32];
    time_t t;
    time(&t);
    struct tm* tm = localtime(&t);
    strftime(ts, sizeof(ts), "%H:%M:%S", tm);

    return std::string(ts);
}


////////////////// UdiskMonitor ///////////////////////
/* signal handler */
volatile bool& UdiskMonitor::exitingFlag_ = mainExitingFlag;
/* sub thread running flag */
volatile bool UdiskMonitor::subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_MAX)] = {};   // 0
/* database connection */
MySQLConnectionPool* UdiskMonitor::pConnectionPool_(nullptr);
std::shared_ptr<sql::Connection> UdiskMonitor::connection_(nullptr);
std::string UdiskMonitor::database_ = {};
std::string UdiskMonitor::tableName_ = {};
/* whitelist */
UdiskWhiteList* UdiskMonitor::pWhiteList_(nullptr);
/* mutex */
std::mutex UdiskMonitor::recordMutex_ = {};
/* semaphore */
std::counting_semaphore<0> UdiskMonitor::recordRequestSemaphore_(0);
/* data record queue */
std::queue<UdiskRecord> UdiskMonitor::recordQueue_ = {};


UdiskMonitor::UdiskMonitor(
    UdiskWhiteList* const pWhiteList, 
    MySQLConnectionPool* pConnectionPool, 
    const std::string& database, 
    const std::string& tableName
)
{
    database_ = database;
    tableName_ = tableName;
    pWhiteList_ = pWhiteList;
    pConnectionPool_ = pConnectionPool;
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] UdiskMonitor(xx)");
}

UdiskMonitor::~UdiskMonitor() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] ~UdiskMonitor()");
    releaseConnection();
}

// void UdiskMonitor::signalHandler(int sig) {
//     exitingFlag_ = true;
//     SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] signalHandler: exitingFlag_ = True."); 
// }

/* clean bpf program */
void UdiskMonitor::clean() {
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] udisk monitor EBPF Clean up.");
    ring_buffer__free(rb_);
    udisk_monitor_bpf__destroy(skel_);
}

/* show mount event info */
void printMountInfo(const struct mount_info* p_mount_info, const UdiskMountArgs& mountArgs, const LauncherInfo& launcher) {
    std::stringstream ss;
    
    ss << std::left << std::endl
       << std::setw(20) << " [EVENT: "          << std::setw(6) << udiskEventStrList[p_mount_info->event.event_type] << "]"  << std::endl
       << std::setw(20) << " [PID: "            << std::setw(6) << p_mount_info->pid << "]" << std::endl
       << std::setw(20) << " [LAUNCHER PID: "   << std::setw(6) << launcher.pid << "]"  << std::endl
       << std::setw(20) << " [LAUNCHER UID: "   << std::setw(6) << launcher.uid << "]"  << std::endl
       << std::setw(20) << " [LAUNCHER EUID: "  << std::setw(6) << launcher.euid << "]" << std::endl
       << std::setw(20) << " [LAUNCHER UNAME: " << std::setw(6) << launcher.userName << "]" << std::endl
       << std::setw(20) << " [DEV: "            << std::setw(0) << mountArgs.devName << "]" << std::endl
       << std::setw(20) << " [PATH: "           << std::setw(0) << mountArgs.mountPoint.pathStr << "]" << std::endl
       << std::setw(20) << " [TYPE: "           << std::setw(0) << mountArgs.mountPoint.mountType << "]" << std::endl
       << std::setw(20) << " [FLAG: "           << std::setw(0) << "0x" << std::right << std::setfill('0') << std::setw(8) << std::hex << mountArgs.mountPoint.mountFlags << "]" 
                                                << std::left    << std::setfill(' ') << std::setw(0) << std::dec << std::endl
       << std::setw(20) << " [REQUEST   MODE: " << std::setw(0) << udiskMountModeStrList[p_mount_info->event.mode_in_request] << " (" << p_mount_info->event.mode_in_request << ")]" << std::endl
       << std::setw(20) << " [WHITELIST MODE: " << std::setw(0) << udiskMountModeStrList[p_mount_info->event.mode_in_udisk_whitelist] << " (" << p_mount_info->event.mode_in_udisk_whitelist << ")]" << std::endl
       << std::setw(20) << " [LEGAL: "          << std::setw(0) << std::hex << p_mount_info->event.isLegal << std::dec << "]" << std::endl
       << std::setw(20) << " [REACT: "          << std::setw(0) << udiskMountReactStrList[p_mount_info->event.react] << " (" << p_mount_info->event.react << ")]" << std::endl
       << std::setw(20) << " [SYSCALL RETVAL: " << std::setw(0) << ((p_mount_info->event.syscall_ret == 0) ? "SUCCESS" : "FAIL") << " (" << p_mount_info->event.syscall_ret << ")]";

    SPDLOG_LOGGER_INFO(logger.my_logger, "{}", ss.str().c_str());
}

int UdiskMonitor::handleMount(const struct mount_info* p_mount_info) {

    /* mount point */
    UdiskMountPoint mountPoint = {
        p_mount_info->args.path_str, 
        p_mount_info->args.mount_type, 
        p_mount_info->args.flags
    };

    /* mount args */
    UdiskMountArgs mountArgs = {
        p_mount_info->args.dev_name,
        mountPoint
    };

    /* event launcher info */
    struct passwd *pw = nullptr;
    pw = getpwuid((uid_t)p_mount_info->event.launcher.uid);
    LauncherInfo launcher = {
        p_mount_info->event.launcher.pid,
        p_mount_info->event.launcher.uid,
        p_mount_info->event.launcher.euid,
        pw ? pw->pw_name : ""
    };
    
    /* find udiskDevice who has this dev_name */
    std::unique_lock<std::mutex> lock(pWhiteList_->whiteListRuntimeMapMutex_);
    std::map<std::string, UdiskWhiteListEntry>& whiteListRuntimeMap = *(pWhiteList_->pWhiteListRuntimeMap_.load());

    UdiskDevice udiskDevice = {};
    
    /* <std::string, UdiskWhiteListEntry> */
    for (auto& pairWhiteList : whiteListRuntimeMap) {
        UdiskWhiteListEntry& whiteListEntry = pairWhiteList.second;
        
        /* <std::string, UdiskRuntimeDevNodeEntry> */
        for (auto& pairDevNode : whiteListEntry.runtimeDevNodes_) {
            
            /* find devnode in RuntimeDevNodes */
            if (pairDevNode.first == std::string(p_mount_info->args.dev_name)) {
                
                udiskDevice = whiteListEntry.device_;
                
                /* update info in RuntimeDevNodes */
                if (p_mount_info->event.syscall_ret == MOUNT_SUCCESS) {     /* mount success */
                    UdiskRuntimeDevNodeEntry& runtimeDevNodeEntry = pairDevNode.second;
                    runtimeDevNodeEntry.mountRefCnt_++;
                    auto pair = runtimeDevNodeEntry.mountPoints_.emplace(p_mount_info->args.path_str, mountPoint);    /* update path devnode mounted on, in user space whiteListRuntimeMap */
                    if (!pair.second) {
                        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskWhiteList] Upsert Mount Points failed, key already exists: {}", pair.first->first.c_str());
                    }
                }
            }
        }
    }
    lock.unlock();

    /* show mount event info */
    printMountInfo(p_mount_info, mountArgs, launcher);

    /* show whiteListRuntimeMap */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] UdiskWhiteListRuntimeMap: \n{}", 
                                            pWhiteList_->printWhiteListRuntimeMap().str().c_str());

    /* Insert to mysql */
    UdiskRecord udiskRecord = {
        p_mount_info->pid,
        launcher,
        udiskEventStrList[p_mount_info->event.event_type],
        udiskDevice,
        mountArgs,
        p_mount_info->event.isLegal,
        udiskMountModeStrList[p_mount_info->event.mode_in_request],
        udiskMountModeStrList[p_mount_info->event.mode_in_udisk_whitelist],
        udiskMountReactStrList[p_mount_info->event.react],
        (p_mount_info->event.syscall_ret == 0) ? "SUCCESS" : "FAIL"  // mount success or failed
    };

    /* push to monitor Record Queue, 0.000279s*/
    {
        std::unique_lock<std::mutex> lock(recordMutex_);
        recordQueue_.push(udiskRecord);
        recordRequestSemaphore_.release();
    }

    /* alert user */
    {
        if (p_mount_info->event.react == mount_reaction::DENY_MOUNT) {
            /* 
                send udiskRecord to web backend by unix socket
             */
        }
    }
    
    return 1;
}



int UdiskMonitor::handleUmount(const struct mount_info* p_mount_info) {

    /* mount point */
    UdiskMountPoint mountPoint = {
        "-",            /* umount cannot provide path str from kernel space */
        "-",            /* umount cannot provide mount type from kernel space */
        p_mount_info->args.flags
    };

    /* mount args */
    UdiskMountArgs mountArgs = {
        p_mount_info->args.dev_name,
        mountPoint
    };

    /* event launcher info */
    struct passwd *pw = nullptr;
    pw = getpwuid((uid_t)p_mount_info->event.launcher.uid);
    LauncherInfo launcher = {
        p_mount_info->event.launcher.pid,
        p_mount_info->event.launcher.uid,
        p_mount_info->event.launcher.euid,
        pw ? pw->pw_name : ""
    };

    /* find udiskDevice who has this dev_name */
    std::unique_lock<std::mutex> lock(pWhiteList_->whiteListRuntimeMapMutex_);
    std::map<std::string, UdiskWhiteListEntry>& whiteListRuntimeMap = *(pWhiteList_->pWhiteListRuntimeMap_.load());

    UdiskDevice udiskDevice = {};

    /* <std::string, UdiskWhiteListEntry> */
    for (auto& pairWhiteList : whiteListRuntimeMap) {
        UdiskWhiteListEntry& whiteListEntry = pairWhiteList.second;
        
        /* <std::string, UdiskRuntimeDevNodeEntry> */
        for (auto& pairDevNode : whiteListEntry.runtimeDevNodes_) {

            /* find devnode in RuntimeDevNodes */
            if (pairDevNode.first == std::string(p_mount_info->args.dev_name)) {
                
                /* update devnode info */
                if (p_mount_info->event.syscall_ret == UMOUNT_SUCCESS) {    /* Umount success */     
                    UdiskRuntimeDevNodeEntry& runtimeDevNodeEntry = pairDevNode.second;          
                    if (--runtimeDevNodeEntry.mountRefCnt_ <= 0) {
                        runtimeDevNodeEntry.mountRefCnt_ = 0;
                        runtimeDevNodeEntry.mountPoints_.clear();                      /* clear the mount points in user space whiteListRuntimeMap */
                    }
                }
                
                udiskDevice = whiteListEntry.device_;
            }
        }
    }
    lock.unlock();

    /* show umount event info */
    printMountInfo(p_mount_info, mountArgs, launcher);

    /* show whiteListRuntimeMap */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] UdiskWhiteListRuntimeMap: \n{}", 
                                            pWhiteList_->printWhiteListRuntimeMap().str().c_str());

    /* Insert to mysql */
    UdiskRecord udiskRecord = {
        p_mount_info->pid,
        launcher,
        udiskEventStrList[p_mount_info->event.event_type],
        udiskDevice,
        mountArgs,
        p_mount_info->event.isLegal,
        "-", /* udiskMountModeStrList[p_mount_info->event.mode_in_request], */
        udiskMountModeStrList[p_mount_info->event.mode_in_udisk_whitelist],
        udiskMountReactStrList[p_mount_info->event.react],
        (p_mount_info->event.syscall_ret == 0) ? "SUCCESS" : "FAIL"  // mount success or failed
    };

    /* push to monitor Record Queue, 0.000279s*/
    {
        std::unique_lock<std::mutex> lock(recordMutex_);
        recordQueue_.push(udiskRecord);
        recordRequestSemaphore_.release();
    }

    return 1;
}


// static member func
int UdiskMonitor::handle_event(void* ctx, void* data, size_t data_sz) {
    /* 
        如果 handle_event 函数的执行时间超过了 ring_buffer__poll 的超时时间，并且在此期间有大量的消息从内核态传送过来，
        那么 ring_buffer__poll 可能会在 handle_event 函数执行完成之前再次被调用。
        这样一来，handle_event 函数可能会被执行多次。
        因此，即使设置了 exitingFlag_ 为 true，while 循环也无法立即退出，因为 ring_buffer__poll 在某些情况下仍在等待数据到达。
        解决方法是在 handle_event 函数中检查 exitingFlag_ 标志，并在为True时，立即返回，尽快进入下一轮while循环检查，达到尽快退出的效果。
     */
    if (exitingFlag_) {
        // Exit early if exitingFlag_ is set
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] handle_event: exiting_flag = True. Return directly."); 
        return 0;
    }

    const struct mount_info* p_mount_info = (const struct mount_info*)data;

    if (p_mount_info->event.event_type == MOUNT) {        
        handleMount(p_mount_info);
    } else if(p_mount_info->event.event_type == UMOUNT){
        handleUmount(p_mount_info);
    } else if(p_mount_info->event.event_type == REMOUNT){
        // handleRemount(p_mount_info);
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] udisk monitor handleRemount(p_mount_info).");
    }

    return 0;
}


int UdiskMonitor::runDataRecordThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] runDataRecordThread()");

    subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_RECORD)] = true;
    
    int ret = 0;
    UdiskRecord udiskRecord = {};

    /* process UdiskRecord comming */
    while(!exitingFlag_) {

        recordRequestSemaphore_.acquire();    /* wait for element in queue*/
        
        if (exitingFlag_) {             /* udev/kernel monitor sub thread ended */
            SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Break Data Record While Loop..");
            break;
        }

        /* lock & pop from queue*/
        {
            std::unique_lock<std::mutex> lock(recordMutex_);
            if (!recordQueue_.empty()) {
                udiskRecord = recordQueue_.front();
                recordQueue_.pop();
            } else {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] recordQueue is empty!");
                continue;
            }
        }

        /* Insert to mysql, 0.008211s */           
        ret  = upsertData(udiskRecord);
        if (1 != ret) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Upsert Data Failed: {}!", udiskRecord.event_);
        }
    }

end:
    exitingFlag_ = true;
    subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_RECORD)] = false;
    SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] Sub Thread Udisk Data Record end. Set [exitingFlag: true]!");

    return 0;
}


int UdiskMonitor::clearKernelWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] clearKernelWhiteList()");

    #define BATCH_SIZE 1024

    std::string errorMsg = {};
    int err = 0, num_keys = 0, cnt = 0;
    struct kernel_udisk_whitelist_key* p_key = nullptr;
    struct kernel_udisk_whitelist_key keys[BATCH_SIZE] = {0};
    struct kernel_udisk_whitelist_key key = {{0}}, next_key = {{0}};

    auto start = getTimePoint();

    /* delete, [duration: 2.386669 seconds], [entry num: 21984] */
    {
        while(!exitingFlag_) {
            num_keys = 0;
            p_key = nullptr;
            memset(keys, 0, sizeof(keys));

            /* get keys by batch */
            while (num_keys < BATCH_SIZE) {
                /* in case exiting */
                if (!skel_->maps.kernel_udisk_whitelist) {
                    break;
                }

                p_key = (num_keys == 0) ? nullptr : &keys[num_keys - 1];
                err = bpf_map__get_next_key(skel_->maps.kernel_udisk_whitelist, p_key, &next_key, sizeof(next_key));
                if (err != 0) {
                    break;
                }
                keys[num_keys++] = next_key;
            }

            /* No entry left */
            if (num_keys == 0) {
                break;
            }

            /* delete entries by batch */
            for (int i = 0; i < num_keys; i++) {
                /* in case exiting */
                if (!skel_->maps.kernel_udisk_whitelist) {
                    break;
                }

                err = bpf_map__delete_elem(skel_->maps.kernel_udisk_whitelist, &keys[i], sizeof(keys[i]), BPF_ANY);
                if (err != 0) {
                    errorMsg = capturePerrorOutput();
                    SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Udisk Kernel WhiteList delete elem failed, ret: {}: {}", err, errorMsg.c_str());
                }
                cnt++;
            }
        }
    }

    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Time taken by delete Udisk Kernel WhiteList: [duration: {} seconds], [entry num: {}]", duration.count() / 1000000.0, cnt);
    
    return 1;
}


int UdiskMonitor::updateKernelWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] updateKernelWhiteList()");

    int err = 0, cnt = 0;
    std::map<std::string, UdiskWhiteListEntry> whiteListRuntimeMapCopy = {};
    struct kernel_udisk_whitelist_key key = {{0}};
    struct kernel_udisk_whitelist_value value = {mount_mode::DEFAULT_MOUNT_MODE, {0}};

    auto start = getTimePoint();
    /* copy whiteListRuntimeMap, [duration: 0.000202 seconds], [entry num: 2] */
    {
        std::unique_lock<std::mutex> lock(pWhiteList_->whiteListRuntimeMapMutex_);
        whiteListRuntimeMapCopy = *(pWhiteList_->pWhiteListRuntimeMap_.load());
    }
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Time taken by copy WhiteListRuntimeMap: [duration: {} seconds], [entry num: {}]", duration.count() / 1000000.0, whiteListRuntimeMapCopy.size());

    start = getTimePoint();
    /* update WhiteListMap in kernel, [duration: 9.1e-05 seconds], [entry num: 3] */
    {
        cnt = 0;
        /* <std::string, UdiskWhiteListEntry> */
        for(const auto& pair : whiteListRuntimeMapCopy){
            /* in case exiting */
            if (!skel_->maps.kernel_udisk_whitelist) {
                break;
            }

            for(const auto& subPair : pair.second.runtimeDevNodes_){
                /* in case exiting */
                if (!skel_->maps.kernel_udisk_whitelist) {
                    break;
                }
                
                memset(&key, 0, sizeof(key));
                strncpy(key.dev_name, subPair.first.c_str(), sizeof(key.dev_name)-1);
                value.mode = pair.second.mountMode_;
                err = bpf_map__update_elem(skel_->maps.kernel_udisk_whitelist, &key, sizeof(key), &value, sizeof(value), BPF_ANY);
                if (err != 0) {
                    SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Udisk Kernel WhiteList update elem failed. [dev_name: {}], [mode: {}], ret: {}.", key.dev_name, value.mode, err);
                    // goto end;
                }
                // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] Udisk Kernel WhiteList update elem success. [dev_name: {}], [mode: {}].", key.dev_name, value.mode);
                cnt++;
            }
        }

    }
    duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Time taken by update Udisk Kernel WhiteList: [duration: {} seconds], [entry num: {}]", duration.count() / 1000000.0, cnt);

    return 1;
}



int UdiskMonitor::synchronizeKernelWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] synchronizeKernelWhiteList()");
    
    int ret = 1;
    auto start = getTimePoint();


    /* delete, [duration: 0.011433 seconds], [entry num: 3] */
    {
        clearKernelWhiteList();
    }
    
    /* update WhiteListMap in kernel, [duration: 0.000191 seconds], [entry num: 2] */
    {
        updateKernelWhiteList();
    }


end:
    /* 0.033109 seconds*/ 
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Time taken by synchronize Udisk Kernel WhiteList: {} seconds.", duration.count() / 1000000.0);
    
    return ret;
}


int UdiskMonitor::lookupKernelWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] lookupKernelWhiteList()");
    
    int err = 0, cnt = 0, ret = 1;
    struct kernel_udisk_whitelist_key key = {0}, next_key = {0};
    struct kernel_udisk_whitelist_value value = {DEFAULT_MOUNT_MODE, {0}};

    /* 开始计时 */
    auto start = getTimePoint();

    while (bpf_map__get_next_key(skel_->maps.kernel_udisk_whitelist, &key, &next_key, sizeof(next_key)) == 0) {
        memset(&value, 0, sizeof(value));
        err = bpf_map__lookup_elem(skel_->maps.kernel_udisk_whitelist, &next_key, sizeof(next_key), &value, sizeof(value), BPF_ANY);
        if (err != 0) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Udisk Kernel WhiteList lookup elem failed. [dev_name: {}], ret: {}.", next_key.dev_name, err);
            ret = -1;
            goto end;
        }
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] Udisk Kernel WhiteList lookup elem success. [dev_name: {}], [mode: {}].", next_key.dev_name, value.mode);
        key = next_key;
        cnt++;
    }

end:
    /* 0.034379 seconds. [entry num: 1]， 0.00636 seconds. [entry num: 2] */
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Time taken by lookup Udisk Kernel WhiteList: {} seconds. [entry num: {}]", duration.count() / 1000000.0, cnt);
    
    return ret;
}



/* database */

int UdiskMonitor::initConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] initConnection()");

    std::shared_ptr<sql::Connection> connection = pConnectionPool_->getConnection();
    if (nullptr == connection) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to getConnection: connection_ == nullptr !");
        return -1;
    }

    connection_ = connection;
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] connection_: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection_.get()));
    return 1;
}

void UdiskMonitor::releaseConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] releaseConnection()");
    if (nullptr != connection_) {
        pConnectionPool_->releaseConnection(connection_);
        connection_ = nullptr;
    }
}

int UdiskMonitor::beginTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] beginTransaction()");
    try {
        pConnectionPool_->beginTransaction(connection_);
        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::createDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] createDatabase()");
    try {
        pConnectionPool_->createDatabase(connection_, database_);
        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::deleteTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] deleteTable()");
    
    try {
        bool exists = pConnectionPool_->hasTable(connection_, tableName_);
        if (exists) {
            pConnectionPool_->deleteTable(connection_, tableName_);
        }
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] Table deleted: {}", tableName_);
        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::createTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] createTable()");
    
    try {
        const std::string sql = "CREATE TABLE IF NOT EXISTS " + tableName_ +
                                " ("
                                "       id                      BigInt AUTO_INCREMENT PRIMARY KEY, "  // unsigned long long
                                "       event                   VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + "), "
                                "       event_time              TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "  // automatic generate time
                                "       pid                     BigInt, "
                                "       launcherPid             BigInt, "
                                "       launcherUid             BigInt, "
                                "       launcherEuid            BigInt, "
                                "       launcherUserName        VARCHAR(" + std::to_string(USER_NAME_MAXLEN+20) + "), "
                                "       udiskKey                VARCHAR(" + std::to_string(UDISK_KEY_MAXLEN+20) + "), "
                                "       vendorId                VARCHAR(" + std::to_string(VENDOR_ID_MAXLEN+20) + "), "
                                "       productId               VARCHAR(" + std::to_string(PRODUCT_ID_MAXLEN+20) + "), "
                                "       serialId                VARCHAR(" + std::to_string(SERAIL_ID_MAXLEN+20) + "), "
                                "       devName                 VARCHAR(" + std::to_string(DEV_NAME_MAXLEN+20) + "), "
                                "       pathStr                 VARCHAR(" + std::to_string(PATH_STR_MAXLEN+20) + "), "
                                "       mountType               VARCHAR(" + std::to_string(MOUNT_TYPE_MAXLEN+20) + "), "                                
                                "       mountFlags              BigInt, "
                                "       isLegal                 BOOLEAN, "
                                "       modeInRequest           VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + "), "
                                "       modeInWhiteList         VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + "), "
                                "       react                   VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + "), "
                                "       mountResult             VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + ")"
                                " )";
        pConnectionPool_->createTable(connection_, sql);
        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::deleteData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] deleteData()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement("DELETE FROM " + tableName_));

        pConnectionPool_->deleteData(connection_, pstmt);
        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::upsertData(const UdiskRecord& udiskRecord) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] upsertData()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement(
                "INSERT INTO " + tableName_ +   " ( "
                                                " event,"
                                                " pid,"
                                                " launcherPid,"
                                                " launcherUid,"
                                                " launcherEuid,"
                                                " launcherUserName,"
                                                " udiskKey,"
                                                " vendorId,"
                                                " productId,"
                                                " serialId,"
                                                " devName,"
                                                " pathStr,"
                                                " mountType,"
                                                " mountFlags,"
                                                " isLegal,"
                                                " modeInRequest,"
                                                " modeInWhiteList,"
                                                " react,"
                                                " mountResult"
                                                " ) "
                                                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "));
        pstmt->setString(1, udiskRecord.event_);
        pstmt->setUInt64(2, udiskRecord.pid_);
        pstmt->setUInt64(3, udiskRecord.launcher_.pid);
        pstmt->setUInt64(4, udiskRecord.launcher_.uid);
        pstmt->setUInt64(5, udiskRecord.launcher_.euid);
        pstmt->setString(6, udiskRecord.launcher_.userName);
        pstmt->setString(7, udiskRecord.device_.udiskKey_);
        pstmt->setString(8, udiskRecord.device_.vendorId_);
        pstmt->setString(9, udiskRecord.device_.productId_);
        pstmt->setString(10, udiskRecord.device_.serialId_);
        pstmt->setString(11, udiskRecord.mountArgs_.devName);
        pstmt->setString(12, udiskRecord.mountArgs_.mountPoint.pathStr);
        pstmt->setString(13, udiskRecord.mountArgs_.mountPoint.mountType);
        pstmt->setUInt64(14, udiskRecord.mountArgs_.mountPoint.mountFlags);
        pstmt->setBoolean(15, udiskRecord.isLegal_);
        pstmt->setString(16, udiskRecord.modeInRequest_);
        pstmt->setString(17, udiskRecord.modeInWhiteList_);
        pstmt->setString(18, udiskRecord.react_);
        pstmt->setString(19, udiskRecord.result_);

        pConnectionPool_->upsertData(connection_, pstmt);
        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::retrieveData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] retrieveData()");

    try {
        UdiskRecord udiskRecord;
        std::unique_ptr<sql::ResultSet> result(nullptr);
        const std::string sql = "SELECT * FROM " + tableName_ + " LIMIT 4 OFFSET 0";
        pConnectionPool_->selectData(connection_, sql, result);

        // Handle result set
        while (!exitingFlag_ && result->next()) {
            udiskRecord.event_  = result->getString("event");
            udiskRecord.pid_    = result->getUInt64("pid");
            udiskRecord.launcher_.pid   = result->getUInt64("launcherPid");
            udiskRecord.launcher_.uid   = result->getUInt64("launcherUid");
            udiskRecord.launcher_.euid  = result->getUInt64("launcherEuid");
            udiskRecord.launcher_.userName  = result->getString("launcherUserName");
            udiskRecord.device_.udiskKey_    = result->getString("udiskKey");
            udiskRecord.device_.vendorId_    = result->getString("vendorId");
            udiskRecord.device_.productId_   = result->getString("productId");
            udiskRecord.device_.serialId_    = result->getString("serialId");
            udiskRecord.mountArgs_.devName  = result->getString("devName");
            udiskRecord.mountArgs_.mountPoint.pathStr  = result->getString("pathStr");
            udiskRecord.mountArgs_.mountPoint.mountType    = result->getString("mountType");
            udiskRecord.mountArgs_.mountPoint.mountFlags   = result->getUInt64("mountFlags");
            udiskRecord.isLegal_            = result->getBoolean("isLegal");
            udiskRecord.modeInRequest_      = result->getString("modeInRequest");
            udiskRecord.modeInWhiteList_    = result->getString("modeInWhiteList");
            udiskRecord.react_  = result->getString("react");
            udiskRecord.result_ = result->getString("mountResult");

            std::stringstream ss;
            ss  << "[UdiskMonitor] ID: " << udiskRecord.id_ 
                << ", time: "       << udiskRecord.event_time_ 
                << ", pid: "        << udiskRecord.pid_ 
                << ", udiskKey: "   << udiskRecord.device_.udiskKey_ 
                << ", vendorId: "   << udiskRecord.device_.vendorId_ 
                << ", productId: "  << udiskRecord.device_.productId_ 
                << ", serialId: "   << udiskRecord.device_.serialId_ 
                << ", devName: "    << udiskRecord.mountArgs_.devName
                << ", pathStr: "    << udiskRecord.mountArgs_.mountPoint.pathStr
                << ", mountType: "  << udiskRecord.mountArgs_.mountPoint.mountType
                << ", mountFlags: " << udiskRecord.mountArgs_.mountPoint.mountFlags
                << ", isLegal: "    << udiskRecord.isLegal_ 
                << ", modeInRequest: "      << udiskRecord.modeInRequest_ 
                << ", modeInWhiteList: "    << udiskRecord.modeInWhiteList_
                << ", react: "              << udiskRecord.react_
                << ", mountResult: "        << udiskRecord.result_;
            
            SPDLOG_LOGGER_INFO(logger.my_logger, "{}", ss.str().c_str());
        }

        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::endTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] endTransaction()");

    try {
        pConnectionPool_->endTransaction(connection_);
        // throw std::runtime_error("[UdiskMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int UdiskMonitor::initDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] initDatabase().");
    
    int ret = -1;

    ret = beginTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Begin Transaction Failed.");
        return -1;
    }

    ret = createDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Create Database Failed.");
        return -1;
    }

    // ret = deleteTable();
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Delete Table Failed.");
    //     return -1;
    // }

    ret = createTable();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Create Table Failed.");
        return -1;
    }

    ret = deleteData();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Delete Data Failed.");
        return -1;
    }

    LauncherInfo launcher = {};
    UdiskDevice udiskDevice{"v1_p1_s1", "v1", "p1", "s1"};
    UdiskMountArgs udiskMountArgs{"/dev/sdx1", "/path/to/mount/on", "ext4", 111};
    UdiskRecord udiskRecord = {6666, launcher, "DEFAULT_MOUNT_EVENT_TYPE", udiskDevice, udiskMountArgs, false, "DEFAULT_MOUNT_MODE"};
    
    ret = upsertData(udiskRecord);
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Upsert Data Failed.");
        return -1;
    }

    ret = retrieveData();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Retrieve Data Failed.");
        return -1;
    }

    ret = endTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] End Transaction Failed.");
        return -1;
    }

    return 1;
}

int UdiskMonitor::recordUdiskPlugEvent(const char *devnode, const std::string& plugEvent, const struct UdiskDevice& udiskDevice) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] recordUdiskPlugEvent()");
    
    mount_mode mountModeInWhiteList = DEFAULT_MOUNT_MODE;
    const std::string& udiskKey = udiskDevice.udiskKey_;

    std::unique_lock<std::mutex> lock(pWhiteList_->whiteListRuntimeMapMutex_);
    const std::map<std::string, UdiskWhiteListEntry>& whiteListRuntimeMap = *(pWhiteList_->pWhiteListRuntimeMap_.load());
    
    /* <std::string, UdiskWhiteListEntry> */
    const auto it = whiteListRuntimeMap.find(udiskKey);
    if (it != whiteListRuntimeMap.end()) {
        mountModeInWhiteList = it->second.mountMode_;       /* UdiskWhiteListEntry.mountMode_ */
    } else {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] When Record Udisk Plug Event: Cannot find [udiskKey: {}] in udiskWhiteListRuntimeMap!", udiskKey);
    }
    lock.unlock();

    LauncherInfo launcher = {0, 0, 0, "-"};
    UdiskMountArgs MountArgs = {devnode, {"-", "-", 0}};
    UdiskRecord udiskRecord = {
        0,                  /* pid */
        launcher,           /* launcher */
        plugEvent,          /* event */
        udiskDevice,        /* udiskDevice */
        MountArgs,          /* mountArgs */
        true,               /* isLegal */
        "-",                /* modeInRequest */
        udiskMountModeStrList[mountModeInWhiteList],   /* modeInWhiteList */
        "-",                /* react */
        "-"                 /* mountResult */
    };
    
    /* push to monitor Record Queue, 0.000279s*/
    {
        std::unique_lock<std::mutex> lock(recordMutex_);
        recordQueue_.push(udiskRecord);
        recordRequestSemaphore_.release();
    }
    
    return 0;
}


int UdiskMonitor::getBlockDeviceInfo(struct udev_device *udevDevice, struct UdiskDevice& udiskDevice) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] getBlockDeviceInfo()");
    
    /* check sdxx */
    const char *devnode = udev_device_get_devnode(udevDevice);
    if (strncmp(devnode, "/dev/sd", 7) != 0) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] [devnode: {}] is not a udisk dev like /dev/sdxx. Ignore it.", devnode);
        return -1;
    }

    /* check usbDriver, vendorID, productID, serialID */
    bool usbStorageFlag = false, vendorFlag = false, productFlag = false, serialFlag = false;
    const char *usbDriver = nullptr, *vendorID = nullptr, *productID = nullptr, *serialID = nullptr;

    /* properties */
    struct udev_list_entry *property = nullptr;
    struct udev_list_entry *properties = udev_device_get_properties_list_entry(udevDevice);
    
    udev_list_entry_foreach(property, properties) {

        const char *property_key = udev_list_entry_get_name(property);
        const char *property_value = udev_list_entry_get_value(property);

        if (strcmp(property_key, "ID_USB_DRIVER") == 0) {

            /* No usb driver */
            if (property_value == nullptr) {
                usbStorageFlag = false;
                SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] [devnode: {}] [ID_USB_DRIVER: NULL]. Ignore it.", devnode);
                return -2;
            }
            SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] [devnode: {}] [ID_USB_DRIVER: {}].", devnode, property_value);
            
            /* Not udisk dev */
            // if (strncmp(property_value, "usb-storage", 11) != 0) {  /* usb-storage/uas/g_mass_storage/... */
            //     usbStorageFlag = false;
            //     SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] [devnode: {}] [ID_USB_DRIVER: {}, not usb-storage]. Ignore it.", devnode, property_value);
            //     return -3;
            // }

            /* udisk dev */
            usbStorageFlag = true;
            udiskDevice.usbDriver_ = property_value;
        }

        if (strcmp(property_key, "ID_VENDOR_ID") == 0) {
            if (property_value != nullptr) {
                vendorFlag = true;
                udiskDevice.vendorId_ = property_value;
            } else {
                vendorFlag = false;
            }
        }

        if (strcmp(property_key, "ID_MODEL_ID") == 0) {
            if (property_value != nullptr) {
                productFlag = true;
                udiskDevice.productId_ = (property_value == nullptr) ? "" : property_value;
            } else {
                productFlag = false;
            }
        }

        if (strcmp(property_key, "ID_SERIAL_SHORT") == 0) {
            if (property_value != nullptr) {
                serialFlag = true;
                udiskDevice.serialId_ = (property_value == nullptr) ? "" : property_value;
            } else {
                serialFlag = false;
            }
        }

    }

    /* check invalid device */
    // if (usbStorageFlag && (vendorFlag || productFlag || serialFlag)) {
    if (vendorFlag || productFlag || serialFlag) {
        udiskDevice.udiskKey_ = udiskDevice.vendorId_ + "_" + udiskDevice.productId_ + "_" + udiskDevice.serialId_;
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] [devnode: {}], [vendorId: {}], [productId: {}], [serialId: {:<4}], [usbDriver: {}]", 
                            devnode, udiskDevice.vendorId_, udiskDevice.productId_, udiskDevice.serialId_, udiskDevice.usbDriver_);
        return 1;
    } else {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] [devnode: {}], [vendorId: {}], [productId: {}], [serialId: {:<4}], [usbDriver: {}]", 
                            devnode, udiskDevice.vendorId_, udiskDevice.productId_, udiskDevice.serialId_, udiskDevice.usbDriver_);
        return -4;
    }

}


int UdiskMonitor::handleBlockDeviceAdd(struct udev_device *udevDevice) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] handleBlockDeviceAdd()");

    struct UdiskDevice udiskDevice = {};
    int ret = getBlockDeviceInfo(udevDevice, udiskDevice);
    if (ret != 1) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] Block Device invalid.");
        return -1;
    }

    const char *devnode = udev_device_get_devnode(udevDevice);

    /* 将kernel分配的 devNode 添加到 UdiskWhiteListRuntimeMap 中的某个 udiskDevice 对应的 udiskRuntimeDevNodeEntry */
    UdiskRuntimeDevNodeEntry udiskRuntimeDevNodeEntry = {devnode, {}, true, 0, getLocalTimeStr()};
    pWhiteList_->upsertDevNodeEntryInRuntimeMap(udiskDevice, udiskRuntimeDevNodeEntry);

    /* 打印 whiteListRuntimeMap */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] UdiskWhiteListRuntimeMap: \n{}", 
                                            pWhiteList_->printWhiteListRuntimeMap().str().c_str());

    /* Insert to mysql */
    ret = recordUdiskPlugEvent(devnode, "ADD", udiskDevice);
    if (ret != 0) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] record Udisk Plug Event Failed: Block Dev ADD!");
    }

    return 1;
}


int UdiskMonitor::handleBlockDeviceRemove(struct udev_device *udevDevice) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] handleBlockDeviceRemove()");

    struct UdiskDevice udiskDevice = {};
    int ret = getBlockDeviceInfo(udevDevice, udiskDevice);
    if (ret != 1) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] Block Device not valid.");
        return -1;
    }

    const char *devnode = udev_device_get_devnode(udevDevice);
    
    /* Insert to mysql */    
    ret = recordUdiskPlugEvent(devnode, "REMOVE", udiskDevice);
    if (ret != 0) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] record Udisk Plug Event Failed: Block Dev REMOVE!");
    }

    /* 删除 UdiskWhiteListRuntimeMap 中的某个 udiskDevice 的某个 devnode 对应的 udiskRuntimeDevNodeEntry */
    pWhiteList_->deleteDevNodeEntryInRuntimeMap(udiskDevice.udiskKey_, devnode);

    /* 打印 whiteListRuntimeMap */
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] UdiskWhiteListRuntimeMap: \n{}", 
                                            pWhiteList_->printWhiteListRuntimeMap().str().c_str());
    
    return 1;
}

int UdiskMonitor::handleBlockDeviceOtherAction(struct udev_device *udevDevice) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] handleBlockDeviceOtherAction()");
    // SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Udev Monitor: [Other Action : Block Device]");
    /* 
        some action 
    */
    return 1;
}

/* Udev plugged in scan */
int UdiskMonitor::scanUdiskPluggedIn() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] scanUdiskPluggedIn()");

    std::string errorMsg = {};

    struct udev *udev = udev_new();
    if (!udev) {
        errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to create udev. {}", errorMsg.c_str());
        return -1;
    }
   
    struct udev_enumerate *enumerate = udev_enumerate_new(udev);    
    if (!enumerate) {
        errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to create udev enumerate. {}", errorMsg.c_str());
        udev_unref(udev); // 释放udev
        return -1;
    }
    
    /* filter and scan devices enumerate */
    udev_enumerate_add_match_subsystem(enumerate, "block");
    udev_enumerate_scan_devices(enumerate);

    /* get device entry list */
    struct udev_list_entry *entry = nullptr;
    struct udev_list_entry *deviceEntries = udev_enumerate_get_list_entry(enumerate);
    
    /* for each device entry */    
    udev_list_entry_foreach(entry, deviceEntries) {
        const char *syspath = udev_list_entry_get_name(entry);
        struct udev_device *udevDevice = udev_device_new_from_syspath(udev, syspath);
        if (!udevDevice) {
            errorMsg = capturePerrorOutput();
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed udev_device_new_from_syspath(). {}", errorMsg.c_str());
            continue;
        }

        handleBlockDeviceAdd(udevDevice);    // ret  -1:not /dev/sdxx dev, -2:ID_USB_DRIVER is NULL, -3:ID_USB_DRIVER is not "usb-storage"
        udev_device_unref(udevDevice);      // 释放 udevDevice
    }

    udev_enumerate_unref(enumerate); // 释放 enumerate
    udev_unref(udev); // 释放 udev

    return 1;
}


int UdiskMonitor::handleBlockDeviceAction(const char *action, udev_device *udevDevice) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] handleBlockDeviceAction()");

    if (strcmp(action, "add") == 0) {
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Udev Monitor: [ADD : Block Device]");
        handleBlockDeviceAdd(udevDevice);    // ret  -1:not /dev/sdxx dev, -2:ID_USB_DRIVER is NULL, -3:ID_USB_DRIVER is not "usb-storage"
    } else if (strcmp(action, "remove") == 0) {
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Udev Monitor: [REMOVE : Block Device]");
        handleBlockDeviceRemove(udevDevice);    // ret  -1:not /dev/sdxx dev, -2:ID_USB_DRIVER is NULL, -3:ID_USB_DRIVER is not "usb-storage"
    } else {
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Udev Monitor: [Action {} : Block Device]", action);
        handleBlockDeviceOtherAction(udevDevice);        
        return 1;
    }

    if (subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_KERNEL)]) {

        /* 同步到内核白名单 */
        int ret = synchronizeKernelWhiteList();
        if (ret != 1) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to synchronize Udisk Kernel WhiteList.");
            return -1;
        }

        /* 查看内核白名单 */
        ret = lookupKernelWhiteList();
        if (ret != 1) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to lookup Udisk Kernel WhiteList.");
            return -2;
        }  
    }

    return 1;
}


/* Udisk Udev Monitor */
int UdiskMonitor::runUdevMonitorThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] runUdevMonitorThread()");

    int ret = -1;
    int blkFd = -1;
    udev *udev = nullptr;
    udev_monitor *blkMonitor = nullptr;
    std::string errorMsg = {};

    udev = udev_new();
    if (!udev) {
        errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to create udev. {}", errorMsg.c_str());
        goto end;
    }

    blkMonitor = udev_monitor_new_from_netlink(udev, "udev");
    if (!blkMonitor) {
        errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to create block monitor. {}", errorMsg.c_str());
        goto clean_udev;
    }

    ret = udev_monitor_filter_add_match_subsystem_devtype(blkMonitor, "block", nullptr);
    if (ret < 0) {
        errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to add BLOCK to subsystem devtype of blkMonitor. {}", errorMsg.c_str());
        goto clean_udev_monitor;
    }

    ret = udev_monitor_enable_receiving(blkMonitor);
    if (ret < 0) {
        errorMsg = capturePerrorOutput();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to enable blkMonitor receiving. {}", errorMsg.c_str());
        goto clean_udev_monitor;
    }

    blkFd = udev_monitor_get_fd(blkMonitor);

    subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_UDEV)] = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskMonitor] Udisk Udev Monitor Start Success...");

    while (!exitingFlag_) {
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(blkFd, &fds);

        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 200000;    /* 0.2s */

        int ret = select(blkFd + 1, &fds, nullptr, nullptr, &tv);
        if (ret > 0 && FD_ISSET(blkFd, &fds)) {
            udev_device *blkDevice = udev_monitor_receive_device(blkMonitor);
            if (blkDevice) {
                const char *devnode = udev_device_get_devnode(blkDevice);
                const char *action = udev_device_get_action(blkDevice);                
                if (devnode && action) {
                    handleBlockDeviceAction(action, blkDevice);
                }
                udev_device_unref(blkDevice);
            }
        }
    }

clean_udev_monitor:
    udev_monitor_unref(blkMonitor);

clean_udev:
    udev_unref(udev);

end:
    exitingFlag_ = true;
    subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_UDEV)] = false;
    SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] Sub Thread Udisk Udev Monitor end. Set [exitingFlag: true]!");

    return 1;
}

/* Udisk Kernel Monitor */
int UdiskMonitor::runKernelMonitorThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] runKernelMonitorThread()");

    int err = -1, ret = 0;
    unsigned int max_entries = 0;

    /* Load and verify BPF application */
    skel_ = udisk_monitor_bpf__open();
    if (!skel_) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to open and load udisk monitor BPF skeleton.");
        goto end;
    }

    /* Load & verify BPF programs */
    err = udisk_monitor_bpf__load(skel_);
    if (err) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to load and verify udisk monitor BPF skeleton.");
        goto clean;
    }

    /* max_entries */
    max_entries = bpf_map__max_entries(skel_->maps.kernel_udisk_whitelist);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Udisk Kernel WhiteList max_entries: {}.", max_entries);

    /* 同步 WhiteList 到内核 */
    ret = synchronizeKernelWhiteList();
    if (ret != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to synchronize Udisk Kernel WhiteList.");
        goto clean;
    }
    
    // /* 查看内核白名单 */
    // ret = lookupKernelWhiteList();
    // if (ret != 1) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to lookup Udisk Kernel WhiteList.");
    //     goto clean;
    // }    

    /* Attach tracepoints */
    err = udisk_monitor_bpf__attach(skel_);
    if (err) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to attach udisk monitor BPF skeleton.");
        goto clean;
    }

    /* Set up ring buffer polling */
    rb_ = ring_buffer__new(bpf_map__fd(skel_->maps.rb), handle_event, nullptr, nullptr);
    if (!rb_) {
        err = -1;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to create udisk monitor ring buffer.");
        goto clean;
    }

    subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_KERNEL)] = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskMonitor] Udisk Kernel Monitor Start Success.");

    /* Process events */
    while (!exitingFlag_) {
        err = ring_buffer__poll(rb_, 100 /* timeout, ms */);
        /* Ctrl-C will cause -EINTR */
        if (err == -EINTR) {
            err = 0;
            break;
        }
        if (err < 0) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Error polling udisk monitor ring buffer: {}.", err);
            break;
        }
    }

clean:
    /* Clean up */
    clean();

end:
    exitingFlag_ = true;
    subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_KERNEL)] = false;
    SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] Sub Thread Udisk Kernel Monitor end. Set [exitingFlag: true]!");

    return err < 0 ? err : 0;
}


int UdiskMonitor::startSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] startSubThreads()");
    
    /* Monitor Sub Threads */

    /* data record sub thread */
    try{
        std::thread udiskDataRecordThread = std::thread([this](){ this->runDataRecordThread(); });
        subThreadsMap_.emplace(
            UdiskMonitorSubThreadId::SUB_THREAD_RECORD,
            std::move(udiskDataRecordThread)     // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Sub Thread Udisk Data Record Running...");
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to start Sub Thread Udisk Data Record. Error: {}. Set [exitingFlag: true]!", e.what());
        return -1;
    }
    
    /* Udev monitor sub thread */
    try{
        std::thread udiskUdevMonitorThread = std::thread([this](){ this->runUdevMonitorThread(); });        
        subThreadsMap_.emplace(
            UdiskMonitorSubThreadId::SUB_THREAD_UDEV,
            std::move(udiskUdevMonitorThread)       // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Sub Thread Udisk Udev Monitor Running...");
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to start Sub Thread Udisk Udev Monitor. Error: {}. Set [exitingFlag: true]!", e.what());
        return -2;
    }

    /* ebpf monitor sub thread */
    try{
        std::thread udiskKernelMonitorThread = std::thread([this](){ this->runKernelMonitorThread(); });
        subThreadsMap_.emplace(
            UdiskMonitorSubThreadId::SUB_THREAD_KERNEL,
            std::move(udiskKernelMonitorThread)     // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Sub Thread Udisk Kernel Monitor Running...");
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to start Sub Thread Udisk Kernel Monitor. Error: {}. Set [exitingFlag: true]!", e.what());
        return -3;
    }

    return 1;
}

int UdiskMonitor::stopSubThreads() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskMonitor] Udisk Monitor SubThreads Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;

    /* stop record thread */
    recordRequestSemaphore_.release();
    return 1;
}


int UdiskMonitor::joinSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] joinSubThreads()");

    /* join monitor sub threads */
    for (auto& pair : subThreadsMap_) {
        if (pair.second.joinable()) {
            pair.second.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Udisk Monitor Sub Thread [{}] joined...", static_cast<int>(pair.first));
        }
    }
    return 1;
}

int UdiskMonitor::reloadWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] reloadWhiteList()");

    int ret = -1;

    ret = pWhiteList_->reloadWhiteListRuntimeMap();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Reload WhiteListMap Failed.");
        return -1;
    }

    if (subThreadRunningFlag_[static_cast<int>(UdiskMonitorSubThreadId::SUB_THREAD_KERNEL)]) {
        /* 同步到内核白名单 */
        ret = synchronizeKernelWhiteList();
        if (1 != ret) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to synchronize Udisk Kernel WhiteList.");
            return -2;
        }

        /* 查看内核白名单 */
        ret = lookupKernelWhiteList();
        if (1 != ret) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Failed to lookup Udisk Kernel WhiteList.");
            return -3;
        }
    }
    
    return 1;
}

int UdiskMonitor::runMainThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] runMainThread()");

    int ret = -1;

    /* Check exiting flag */
    if (exitingFlag_) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[UdiskMonitor] ExitingFlag is True. No Need to Start Udisk Monitor Sub Threads. Exit..");
        goto end;
    }

    /* Start threads */
    ret = startSubThreads();
    if (1 != ret) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Start Udisk Monitor Sub Threads Failed. Set [exitingFlag: true]! Exit..");
    }

    /* 
    
        todo:
        1. IPC thread to communicate with web backend.
        2. Manager thread to handle user requests.
     */

    
    // /* test Reload WhiteList from database on runtime */
    // for (int i=0; ; i++) {
    //     if (exitingFlag_) {
    //         break;
    //     }
    //     ret = testReloadWhiteList(i);
    //     if (1 != ret) {
    //         exitingFlag_ = true;
    //         SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Test Reload WhiteList Failed. Exit..");
    //         break;
    //     }
    //     SPDLOG_LOGGER_INFO(logger.my_logger, "[UdiskMonitor] Test Reload WhiteList SUCCESS");
    //     std::this_thread::sleep_for(std::chrono::milliseconds(10000));
    // }
    


    /* join monitor sub threads */
    joinSubThreads();

end:
    exitingFlag_ = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskMonitor] Udisk Monitor Main Thread End. Set [exitingFlag: true]!");
    return 1;
}

int UdiskMonitor::stopMainThread() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[UdiskMonitor] Udisk Monitor Main Thread Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;
    stopSubThreads();
    return 1;
}

// uapi
int UdiskMonitor::init() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[UdiskMonitor] init()");

    // 获取 libbpf 版本信息
    const char *libbpf_version = libbpf_version_string();
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[UdiskMonitor] libbpf Version: {}", libbpf_version);

    int ret = initConnection();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Init Connection Failed. Exit..");
        return -1;
    }

    ret = initDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Init Database Failed. Exit..");
        return -2;
    }

    ret = scanUdiskPluggedIn();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[UdiskMonitor] Scan Udisk Plugged In Failed. Exit..");
        return -3;
    }

    return 1;
}