/***
 * @Author: JiaHao
 * @Date: 2023-12-11 14:36:04
 * @LastEditors: JiaHao
 * @LastEditTime: 2023-12-11 14:41:53
 * @FilePath: /hostguard_linux/submodule/monitor/exec_monitor.cpp
 * @Description:
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved.
 */

// gcc -o md5_calc md5_calc.c -lssl -lcrypto

#include "monitor/exec_monitor.h"
#include "exec_monitor.skel.h"

extern Spdlogger logger;
extern volatile bool mainExitingFlag;

////////////////// ExecMonitor ///////////////////////
/* signal handler */
volatile bool& ExecMonitor::exitingFlag_ = mainExitingFlag;
/* sub thread running flag */
volatile bool ExecMonitor::subThreadRunningFlag_[static_cast<int>(ExecMonitorSubThreadId::SUB_THREAD_MAX)] = {};   // 0
/* database connection */
MySQLConnectionPool* ExecMonitor::pConnectionPool_(nullptr);
std::shared_ptr<sql::Connection> ExecMonitor::connection_(nullptr);
std::string ExecMonitor::database_ = {};
std::string ExecMonitor::tableName_ = {};
/* whitelist */
const EVP_MD* ExecMonitor::pEVP_MD_(nullptr);
ExecWhiteList* ExecMonitor::pWhiteList_(nullptr);
FileDigestCalculator ExecMonitor::fileDigestCalculator_(EVP_sha256());  // static member
/* mutex */
std::mutex ExecMonitor::recordRequestQueueMutex_  = {};
std::mutex ExecMonitor::recordResponseQueueMutex_ = {};
/* semaphore */
std::counting_semaphore<0> ExecMonitor::recordRequestSemaphore_(0);
std::counting_semaphore<0> ExecMonitor::recordFinishSemaphore_(0);
/* data record queue */
std::queue<ExecMonitorRecordRequest> ExecMonitor::recordRequestQueue_   = {};
std::queue<ExecMonitorRecordResponse> ExecMonitor::recordResponseQueue_ = {};


ExecMonitor::ExecMonitor(
    ExecWhiteList* const pWhiteList, 
    MySQLConnectionPool* pConnectionPool, 
    const EVP_MD* pEVP_MD,
    const HgWorkModeOption workMode,
    const std::string& database, 
    const std::string& tableName
) {
    database_ = database;
    tableName_ = tableName;
    pWhiteList_ = pWhiteList;
    pConnectionPool_ = pConnectionPool;
    pEVP_MD_ = pEVP_MD;
    fileDigestCalculator_.setDigestAlgorithm(pEVP_MD);
    workMode_ = workMode;
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] ExecMonitor(xx)");
}

ExecMonitor::~ExecMonitor() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] ~ExecMonitor()");
    releaseConnection();
}


// void ExecMonitor::signalHandler(int sig) {
//     exitingFlag_ = true;
//     SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] signalHandler: exitingFlag_ = True."); 
// }

void ExecMonitor::clean() {
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] exec monitor EBPF Clean up.");
    ring_buffer__free(rb_);
    exec_monitor_bpf__destroy(skel_);
}

/* static member func */
std::vector<unsigned char> ExecMonitor::getFileDigest(const std::string& filePath) {
    std::vector<unsigned char> fileDigest = {};

    try {
        // 计算 File Digest
        fileDigest = fileDigestCalculator_.calculateFileDigest(filePath);

        // 将哈希值转换为十六进制字符串并打印结果
        // SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] File: {}", filePath.c_str());
        // SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor]   fileDigest: {}", toHexString(fileDigest).c_str());
        return fileDigest;

    } catch (const std::exception& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Error: Calculate File Digest {}", e.what());
        return {};
    }
}


int ExecMonitor::getEventBasicInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventBasicInfo) {
    
    /* event launcher info */
    struct passwd *pw = nullptr;
    pw = getpwuid((uid_t)p_taskinfo->event.launcher.uid);
    LauncherInfo launcher = {
        p_taskinfo->event.launcher.pid,
        p_taskinfo->event.launcher.uid,
        p_taskinfo->event.launcher.euid,
        pw ? pw->pw_name : ""
    };

    /* ExecRecord */
    execRecord.event_       = execEventStrList[p_taskinfo->event.type];
    execRecord.pid_         = p_taskinfo->pid;
    execRecord.ppid_        = p_taskinfo->ppid;
    execRecord.launcher_    = launcher;
    execRecord.command_     = p_taskinfo->args.comm;
    execRecord.filepath_    = p_taskinfo->event.abs_filepath;
    execRecord.duration_us_ = p_taskinfo->event.duration_us;
    execRecord.reactActual_ = execReactionStrList[p_taskinfo->event.react_actual];

    /* for debug info */
    std::stringstream ss;
    ss  << std::left << std::endl
        << std::setw(20) << " [EVENT: "         << std::setw(6) << execEventStrList[p_taskinfo->event.type]   << "]"  << std::endl
        << std::setw(20) << " [COMM: "          << std::setw(6) << p_taskinfo->args.comm    << "]"  << std::endl
        << std::setw(20) << " [PID: "           << std::setw(6) << p_taskinfo->pid          << "]"  << std::endl
        << std::setw(20) << " [PPID: "          << std::setw(6) << p_taskinfo->ppid         << "]"  << std::endl
        << std::setw(20) << " [LAUNCHER PID: "  << std::setw(6) << launcher.pid             << "]"  << std::endl
        << std::setw(20) << " [LAUNCHER UID: "  << std::setw(6) << launcher.uid             << "]"  << std::endl
        << std::setw(20) << " [LAUNCHER EUID: " << std::setw(6) << launcher.euid            << "]"  << std::endl
        << std::setw(20) << " [LAUNCHER NAME: " << std::setw(6) << launcher.userName        << "]"  << std::endl
        << std::setw(20) << " [FILE PATH: "     << std::setw(6) << p_taskinfo->event.abs_filepath       << "]"  << std::endl
        << std::setw(20) << " [ACTUAL REACT: "  << std::setw(6) << execReactionStrList[p_taskinfo->event.react_actual]   << "]" << std::endl
        << std::setw(20) << " [EXIT CODE: "     << std::setw(6) << p_taskinfo->event.exit_code          << "]"  << std::endl
        << std::setw(20) << " [DURATION MS: "   << std::setw(6) << p_taskinfo->event.duration_us/1000.0 << "]"  << std::endl;

    eventBasicInfo = ss.str();
    
    return 1;
}

int ExecMonitor::getEventArgsInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventArgsInfo) {

    std::string args = {};
    for (int i = 1; i < TASK_ARGV_NUM; i++) {  // i=0: command
        const char* ptr = &p_taskinfo->args.argv[i * TASK_ARGV_LEN];
        if (ptr[0] != '\0') {
            args = args + std::string(ptr) + " ";
        } else {
            break;
        }
    }

    /* ExecRecord */
    execRecord.args_ = args;

    /* for debug info */
    std::stringstream ss;
    ss  << std::left    << std::setw(20) << " [ARGS: "  << std::setw(6) << args << "]"  << std::endl;
    eventArgsInfo = ss.str();

    return 1;
}

int ExecMonitor::getEventFileDigestInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventFileDigestInfo) {

    std::string fileDigestStr = "-";
    std::vector<unsigned char> fileDigest = {};

    /* process clone / fork / vfork */
    if (p_taskinfo->event.type >= FORK && p_taskinfo->event.type <= CLONE) {
        /* copy ima_hash from kernel p_taskinfo */
        // fileDigest.assign(p_taskinfo->event.ima_hash, p_taskinfo->event.ima_hash + EVP_MD_size(pEVP_MD_));    /* [ ) */
    
        /* calc ima_hash from kernel p_taskinfo */
        // fileDigest = getFileDigest(p_taskinfo->event.abs_filepath);
    }

    /* process exec */
    if (p_taskinfo->event.type == LSM_EXEC) {
        /* copy ima_hash from kernel p_taskinfo */
        fileDigest.assign(p_taskinfo->event.ima_hash, p_taskinfo->event.ima_hash + EVP_MD_size(pEVP_MD_));    /* [ ) */
    }

    /* process exit */
    if (p_taskinfo->event.type == EXIT) {
        if (p_taskinfo->event_history_flag & FLAG_LSM_EXEC) {
            /* copy ima_hash from kernel p_taskinfo */
            // fileDigest.assign(p_taskinfo->event.ima_hash, p_taskinfo->event.ima_hash + EVP_MD_size(pEVP_MD_));    /* [ ) */
        } else {
            /* calc ima_hash from kernel p_taskinfo */
            // fileDigest = getFileDigest(p_taskinfo->event.abs_filepath);
        }        
    }

    /* To string */
    if (!fileDigest.empty()) {
        fileDigestStr = toHexString(fileDigest);
    }

    /* ExecRecord */  
    execRecord.fileDigest_ = fileDigestStr;

    /* for debug info */
    std::stringstream ss;
    ss  << std::left
        << std::setw(20)    << " [FILE DIGEST: "    << std::setw(6) << execRecord.fileDigest_ << "]"  << std::endl;
    eventFileDigestInfo = ss.str();

    return 1;
}

bool ExecMonitor::getEventWhiteListEntryInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord, std::string& eventWhiteListEntryInfo) {

    bool isInExecWhiteList = false;
    std::string whiteListEntryStr = "";

    /* very quick & read only & massive times, no lock */
    std::unordered_map<std::string, ExecWhiteListEntry>& whiteListRuntimeMap = *(pWhiteList_->pWhiteListRuntimeMap_.load());

    const auto& it = whiteListRuntimeMap.find(execRecord.fileDigest_);
    if (it != whiteListRuntimeMap.end()) {
        isInExecWhiteList = true;
        execRecord.reactWhiteList_  = execReactionStrList[static_cast<int>(it->second.reaction_)];
        whiteListEntryStr = "\n    " + it->second.print().str() + " ";
    } else {
        execRecord.reactWhiteList_ = "-";
    }

    /* for debug info */
    std::stringstream ss;
    ss  << std::left
        << std::setw(20) << " [USER WHITELIST REACT: "  << std::setw(6) << execRecord.reactWhiteList_   << "]"  << std::endl
        << std::setw(20) << " [KERN WHITELIST REACT: "  << std::setw(6) << execReactionStrList[p_taskinfo->event.react_whitelist]    << "]"  << std::endl
        << std::setw(20) << " [WHITELIST ENTRY: "       << std::setw(6) << whiteListEntryStr            << "]"  << std::endl;

    eventWhiteListEntryInfo = ss.str();

    return isInExecWhiteList;
}

int ExecMonitor::getEventInfo(const struct task_info* p_taskinfo, ExecRecord& execRecord) {
    
    std::stringstream ss;

    /* Get Event Basic Info */
    std::string eventBasicInfo = {};
    getEventBasicInfo(p_taskinfo, execRecord, eventBasicInfo);
    ss << eventBasicInfo;

    /* Get task args from taskinfo */
    std::string eventArgsInfo = {};
    getEventArgsInfo(p_taskinfo, execRecord, eventArgsInfo);
    ss << eventArgsInfo;

    /* Get file digest */
    std::string eventFileDigestInfo = {};
    getEventFileDigestInfo(p_taskinfo, execRecord, eventFileDigestInfo);
    ss << eventFileDigestInfo;
    
    /* Check LSM_EXEC only, whether fileDigest is in the WhiteListEntry map */
    execRecord.reactWhiteList_ = "-";
    bool isInExecWhiteList = true;
    if (p_taskinfo->event.type == LSM_EXEC) {        
        std::string eventWhiteListEntryInfo = {};
        isInExecWhiteList = getEventWhiteListEntryInfo(p_taskinfo, execRecord, eventWhiteListEntryInfo);
        ss << eventWhiteListEntryInfo;
    }
    
    /* print Event Info */
    if (isInExecWhiteList) {
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] {}", ss.str().c_str());
    } else {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecMonitor] {}", ss.str().c_str());
    }

    return 1;
}

int ExecMonitor::handleTaskEvent(const struct task_info* p_taskinfo) {
    ExecRecord execRecord = {};
    getEventInfo(p_taskinfo, execRecord);

    /* push to monitor Record Queue, 0.000279s*/
    {
        std::unique_lock<std::mutex> lock(recordRequestQueueMutex_);
        recordRequestQueue_.emplace(0, execRecord);
        recordRequestSemaphore_.release();
    }

    /* alert user */
    {
        if (p_taskinfo->event.react_actual == exec_reaction::DENY_EXEC) {
            /* 
                send execRecord to web backend by unix socket
             */
        }
    }

    return 1;
}

// static member func
int ExecMonitor::handleEvent(void* ctx, void* data, size_t data_sz) {
    /* 
        如果 handleEvent 函数的执行时间超过了 ring_buffer__poll 的超时时间，并且在此期间有大量的消息从内核态传送过来，
        那么 ring_buffer__poll 可能会在 handleEvent 函数执行完成之前再次被调用。
        这样一来，handleEvent 函数可能会被执行多次。
        因此，即使设置了 exitingFlag_ 为 true，while 循环也无法立即退出，因为 ring_buffer__poll 在某些情况下仍在等待数据到达。
        解决方法是在 handleEvent 函数中检查 exiting 标志，并在为True时，立即返回，尽快进入下一轮while循环检查，达到尽快退出的效果。
     */
    if (exitingFlag_) {
        // Exit early if exiting flag is set
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] handleEvent: exitingFlag_ = True. Return directly."); 
        return 0;
    }

    const struct task_info* p_taskinfo = (const struct task_info*)data;

    if ( p_taskinfo->event.type == EXIT 
        || p_taskinfo->event.type == LSM_EXEC
        || p_taskinfo->event.type >= FORK && p_taskinfo->event.type <= CLONE
        ) 
    {
        handleTaskEvent(p_taskinfo);        /* 0.002482 seconds */
    }

    return 0;
}

int ExecMonitor::runDataRecordThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] runDataRecordThread()");

    subThreadRunningFlag_[static_cast<int>(ExecMonitorSubThreadId::SUB_THREAD_RECORD)] = true;
    
    int ret;
    bool isSuccess = true;
    ExecMonitorRecordRequest request = {};
    std::chrono::_V2::system_clock::time_point start = {};

    /* process ExecRecord comming */
    while(!exitingFlag_) {

        recordRequestSemaphore_.acquire();    /* wait for element in queue*/
        
        if (exitingFlag_) {             /* kernel monitor sub thread ended */
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Break Data Record While Loop..");
            break;
        }

        /* lock & pop from queue*/
        {
            std::unique_lock<std::mutex> lock(recordRequestQueueMutex_);
            if (!recordRequestQueue_.empty()) {
                request = recordRequestQueue_.front();
                recordRequestQueue_.pop();
            } else {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] recordQueue is empty!");
                continue;
            }
        }

        /* work start */
        isSuccess = true;
        start = getTimePoint();
        const ExecRecord& execRecord = request.execRecordEntry_;

        /* Insert to mysql, 0.008211s */ 
        {
            ret  = upsertData(execRecord);
            if (1 != ret) {
                isSuccess = false;
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Upsert Data Failed: [event: {}], [filepath: {}]!", execRecord.event_, execRecord.filepath_);
            }
        }          
        
response:
        /* push to response queue & pop request queue */
        {
            // std::unique_lock<std::mutex> lock(recordResponseQueueMutex_);
            // recordResponseQueue_.emplace(request.id_, request.execRecordEntry_, isSuccess);
        }

        /* notify work finish */
        recordFinishSemaphore_.release();

        /* duration */
        auto duration = getDuration_us(start);
        // SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] [duration: {} seconds], [event: {}], [pid: {}], [ppid: {}], [command: {}], [filepath: {}], [reactWhiteList: {}], [reactActual: {}], [duration_us: {}], [fileDigest: {}], [comm_args: {}]", 
        //     duration.count() / 1000000.0, execRecord.event_, execRecord.pid_, execRecord.ppid_, execRecord.command_, execRecord.filepath_, execRecord.reactWhiteList_, execRecord.reactActual_, execRecord.duration_us_, execRecord.fileDigest_, execRecord.args_);

    }

end:
    exitingFlag_ = true;
    subThreadRunningFlag_[static_cast<int>(ExecMonitorSubThreadId::SUB_THREAD_RECORD)] = false;
    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecMonitor] Sub Thread Exec Data Record end. Set [exitingFlag: true]!");

    return 0;
}


int ExecMonitor::clearKernelWhiteList(bpf_map* whiteListMapToClear) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] clearKernelWhiteList()");

    #define BATCH_SIZE 1024

    std::string errorMsg = {};
    int err = 0, num_keys = 0, cnt = 0;
    struct kernel_exec_whitelist_key* p_key = nullptr;
    struct kernel_exec_whitelist_key keys[BATCH_SIZE] = {0};
    struct kernel_exec_whitelist_key key = {{0}}, next_key = {{0}};

    auto start = getTimePoint();

    /* delete, [duration: 2.386669 seconds], [entry num: 21984] */
    {
        while(!exitingFlag_) {
            num_keys = 0;
            p_key = nullptr;
            memset(keys, 0, sizeof(keys));

            /* get keys by batch */
            while (num_keys < BATCH_SIZE) {
                /* in case exiting */
                if (!whiteListMapToClear) {
                    break;
                }

                p_key = (num_keys == 0) ? nullptr : &keys[num_keys - 1];
                err = bpf_map__get_next_key(whiteListMapToClear, p_key, &next_key, sizeof(next_key));
                if (err != 0) {
                    break;
                }
                keys[num_keys++] = next_key;
            }

            /* No entry left */
            if (num_keys == 0) {
                break;
            }

            /* delete entries by batch */
            for (int i = 0; i < num_keys; i++) {
                /* in case exiting */
                if (!whiteListMapToClear) {
                    break;
                }

                err = bpf_map__delete_elem(whiteListMapToClear, &keys[i], sizeof(keys[i]), BPF_ANY);
                if (err != 0) {
                    errorMsg = capturePerrorOutput();
                    SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList delete elem failed, ret: {}: {}", err, errorMsg.c_str());
                }
                cnt++;
            }
        }
    }

    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Time taken by delete Exec Kernel WhiteList: [duration: {} seconds], [entry num: {}]", duration.count() / 1000000.0, cnt);
    
    return 1;
}


int ExecMonitor::updateKernelWhiteList(bpf_map* whiteListMapToUpdate) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] updateKernelWhiteList()");

    int err = 0, cnt = 0;
    std::vector<unsigned char> fileDigest = {0};
    std::unordered_map<std::string, ExecWhiteListEntry> whiteListRuntimeMapCopy = {};
    struct kernel_exec_whitelist_key key = {{0}};
    struct kernel_exec_whitelist_value value = {exec_reaction::ALLOW_EXEC, {0}};

    auto start = getTimePoint();
    /* copy whiteListRuntimeMap, [duration: 0.132291~0.7 seconds], [entry num: 21984] */
    {
        std::unique_lock<std::mutex> lock(pWhiteList_->whiteListRuntimeMapMutex_);
        whiteListRuntimeMapCopy = *(pWhiteList_->pWhiteListRuntimeMap_.load());
    }
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Time taken by copy WhiteListRuntimeMap: [duration: {} seconds], [entry num: {}]", duration.count() / 1000000.0, whiteListRuntimeMapCopy.size());

    start = getTimePoint();
    /* update WhiteListMap in kernel, [duration: 2.256315 seconds], [entry num: 21984] */
    {
        for(const auto& pair : whiteListRuntimeMapCopy){
            /* in case exiting */
            if (!whiteListMapToUpdate) {
                break;
            }

            fileDigest = fromHexString(pair.first);
            if(fileDigest.size() != EVP_MD_size(pEVP_MD_)){
                SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecMonitor] [filepath: {}], [fileDigest.size(): {}], [EVP_MD_size(pEVP_MD_): {}], they should be equal!", 
                                                        pair.second.filePaths_.begin()->first.c_str(), fileDigest.size(), EVP_MD_size(pEVP_MD_));
                continue;
            }

            memset(&key, 0, sizeof(key));
            memcpy(key.ima_hash, fileDigest.data(), EVP_MD_size(pEVP_MD_));
            value.react = static_cast<exec_reaction>(pair.second.reaction_);
            err = bpf_map__update_elem(whiteListMapToUpdate, &key, sizeof(key), &value, sizeof(value), BPF_ANY);
            if (err != 0) {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList update elem failed. [ima_hash: {}], [mode: {}], [ret: {}].", pair.first.c_str(), value.react, err);
            }

            // SPDLOG_LOGGER_DEBUG(logger.my_logger, "Exec Kernel WhiteList update elem success. [ima_hash: {}], [mode: {}]", pair.first.c_str(), value.react);
            cnt++;
        }
    }
    duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Time taken by update Exec Kernel WhiteList: [duration: {} seconds], [entry num: {}]", duration.count() / 1000000.0, cnt);

    return 1;
}

int ExecMonitor::switchKernelWhiteList(unsigned long long whiteListMapIdToUse) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] switchKernelWhiteList()");

    int err = 0;
    auto start = getTimePoint();
    
    /* update runtime MapId 0->1 or 1->0, [duration: 0.000586 seconds], [entry num: 21984] */
    {
        unsigned long long zero = 0;
        err = bpf_map__update_elem(skel_->maps.whitelist_id_in_use, &zero, sizeof(zero), &whiteListMapIdToUse, sizeof(whiteListMapIdToUse), BPF_ANY);
        if (err != 0) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList update runtime whitelist id failed. [whiteListMapIdToUse: {}], [ret: {}].", whiteListMapIdToUse, err);
            return -1;
        }

        kernelWhiteListIdInUse_.store(whiteListMapIdToUse);
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList update runtime whitelist id success. [whiteListIdInUse: {}]", kernelWhiteListIdInUse_.load());
    }

    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Time taken by switch Exec Kernel WhiteList: [duration: {} seconds]", duration.count() / 1000000.0);
    return 1;
}

int ExecMonitor::synchronizeKernelWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] synchronizeKernelWhiteList()");
    
    int ret = 1;
    bpf_map* whiteListMapToUpdate = nullptr;
    unsigned long long whiteListMapIdToUse = 1 - kernelWhiteListIdInUse_.load();

    /* start */
    auto start = getTimePoint();

    /* get MapId need to update  */
    {
        if (whiteListMapIdToUse % 2 == 0) {
            whiteListMapToUpdate = skel_->maps.kernel_exec_whitelist_0;
        } else {
            whiteListMapToUpdate = skel_->maps.kernel_exec_whitelist_1;
        }
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList MapId to update: [whiteListMapIdToUse: {}]", whiteListMapIdToUse);
    }

    /* delete, [duration: 2.386669 seconds], [entry num: 21984] */
    {
        clearKernelWhiteList(whiteListMapToUpdate);
    }

    /* update WhiteListMap in kernel, [duration: 2.256315 seconds], [entry num: 21984] */
    {
        updateKernelWhiteList(whiteListMapToUpdate);
    }

    
    /* update runtime MapId 0->1 or 1->0, [duration: 0.000586 seconds], [entry num: 21984] */
    {
        ret = switchKernelWhiteList(whiteListMapIdToUse);
        if (ret != 1) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to switch Exec Kernel WhiteList.");
        }
    }
    
    /* [duration: 5.305518 seconds] (21984 entries) */
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Time taken by synchronize Exec Kernel WhiteList: [duration: {} seconds]", duration.count() / 1000000.0);
    return ret;
}


int ExecMonitor::lookupKernelWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] lookupKernelWhiteList()");
    
    int err = 0, cnt = 0, ret = 1;
    bpf_map* whiteListMapToLookup = nullptr;
    std::vector<unsigned char> fileDigest = {0};
    struct kernel_exec_whitelist_key key = {{0}}, next_key = {{0}};
    struct kernel_exec_whitelist_value value = {exec_reaction::DENY_EXEC, {0}};

    /* 开始计时 */
    auto start = getTimePoint();


    /* get MapId need to lookup  */
    {
        if (kernelWhiteListIdInUse_.load() % 2 == 0) {
            whiteListMapToLookup = skel_->maps.kernel_exec_whitelist_0;
        } else {
            whiteListMapToLookup = skel_->maps.kernel_exec_whitelist_1;
        }
    }

    while (bpf_map__get_next_key(whiteListMapToLookup, &key, &next_key, sizeof(key)) == 0) {
        fileDigest.assign(next_key.ima_hash, next_key.ima_hash + EVP_MD_size(pEVP_MD_));      /* [ ) */
        memset(&value, 0, sizeof(value));
        cnt++;

        err = bpf_map__lookup_elem(whiteListMapToLookup, &next_key, sizeof(next_key), &value, sizeof(value), BPF_ANY);
        if (err != 0) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList lookup elem failed. [ima_hash: {}], [react: {}], ret: {}.", toHexString(fileDigest).c_str(), value.react, err);
            ret = -1;
            goto end;
        }
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList lookup elem success. [ima_hash: {}], [react: {}].", toHexString(fileDigest).c_str(), value.react);
        key = next_key;
    }

end:
    /* 计算时间差 */   
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Time taken by lookup Exec Kernel WhiteList: [duration: {} seconds], [entry num: {}]", duration.count() / 1000000.0, cnt);
    return ret;
}


int ExecMonitor::runKernelMonitorThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecWhiteList] runKernelMonitorThread()");

    int err, ret = 0;
    unsigned int max_entries = 0;
    HgWorkModeOption workMode = HgWorkModeOption::WORK_MODE_OPTION_DEF;
    
    /* Load and verify BPF application */
    skel_ = exec_monitor_bpf__open();
    if (!skel_) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "Failed to open and load exec monitor BPF skeleton!");
        goto end;
    }

    /* Load & verify BPF programs */
    err = exec_monitor_bpf__load(skel_);
    if (err) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "Failed to load and verify exec monitor BPF skeleton!");
        goto clean;
    }

    /* max_entries */
    max_entries = bpf_map__max_entries(skel_->maps.kernel_exec_whitelist_0);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Exec Kernel WhiteList max_entries: {}.", max_entries);

    /* WorkMode -> Kernel */
    ret = synchronizeKernelWorkMode();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to synchronize Exec Kernel WorkMode.");
        goto clean;
    }

    /* lookup Kernel WorkMode */
    ret = lookupKernelWorkMode(workMode);
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to lookup Exec Kernel WorkMode.");
        goto clean;
    }

    /* WhiteList -> Kernel */
    ret = synchronizeKernelWhiteList();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to synchronize Exec Kernel WhiteList.");
        goto clean;
    }

    // /* lookup Kernel WhiteList */
    // ret = lookupKernelWhiteList(skel_);
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to lookup Exec Kernel WhiteList.");
    //     goto clean;
    // }  

    /* Attach tracepoints */
    err = exec_monitor_bpf__attach(skel_);
    if (err) {
        SPDLOG_LOGGER_ERROR(logger.my_logger,  "Failed to attach exec monitor BPF skeleton!");
        goto clean;
    }

    /* Set up ring buffer polling */
    rb_ = ring_buffer__new(bpf_map__fd(skel_->maps.rb), handleEvent, nullptr, nullptr);
    if (!rb_) {
        err = -1;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "Failed to create exec monitor ring buffer!");
        goto clean;
    }

    subThreadRunningFlag_[static_cast<int>(ExecMonitorSubThreadId::SUB_THREAD_KERNEL)] = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecMonitor] Exec Kernel Monitor Start Success.");

    /* Process events */
    while (!exitingFlag_) {
        err = ring_buffer__poll(rb_, 100 /* timeout, ms */);
        /* Ctrl-C will cause -EINTR */
        if (err == -EINTR) {
            err = 0;
            break;
        }
        if (err < 0) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "Error polling exec monitor ring buffer: {}", err);
            break;
        }
    }

clean:
    /* Clean up */
    clean();

end:
    exitingFlag_ = true;
    subThreadRunningFlag_[static_cast<int>(ExecMonitorSubThreadId::SUB_THREAD_KERNEL)] = false;
    SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecMonitor] Sub Thread Exec Kernel Monitor end. Set [exitingFlag: true]!");

    return err < 0 ? -err : 0;
}

/* database */

int ExecMonitor::initConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] initConnection()");
    
    std::shared_ptr<sql::Connection> connection = pConnectionPool_->getConnection();
    if (nullptr == connection) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to getConnection: connection_ == nullptr !");
        return -1;
    }

    connection_ = connection;
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] connection_: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection_.get()));
    return 1;
}

void ExecMonitor::releaseConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] releaseConnection()");
    if (nullptr != connection_) {
        pConnectionPool_->releaseConnection(connection_);
        connection_ = nullptr;
    }
}

int ExecMonitor::beginTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] beginTransaction()");

    try {
        pConnectionPool_->beginTransaction(connection_);
        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::createDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] createDatabase()");

    try {
        SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] createDatabase()");

        pConnectionPool_->createDatabase(connection_, database_);
        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::deleteTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] deleteTable()");

    try {
        bool exists = pConnectionPool_->hasTable(connection_, tableName_);
        if (exists) {
            pConnectionPool_->deleteTable(connection_, tableName_);
        }
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] Table deleted: {}", tableName_);
        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::createTable() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] createTable()");

    try {
        const std::string sql = "CREATE TABLE IF NOT EXISTS " + tableName_ +
                                " ("
                                "       id                  BigInt AUTO_INCREMENT PRIMARY KEY, "  // unsigned long long
                                "       event               VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + "), "
                                "       time                TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "  // automatic generate time
                                "       pid                 BigInt, "
                                "       ppid                BigInt, "
                                "       launcherPid         BigInt, "
                                "       launcherUid         BigInt, "
                                "       launcherEuid        BigInt, "
                                "       launcherUserName    VARCHAR(" + std::to_string(USER_NAME_MAXLEN+20) + "), "
                                "       command             VARCHAR(" + std::to_string(TASK_COMM_LEN+20) + "), "
                                "       filepath            VARCHAR(" + std::to_string(MAX_FILEPATH_LEN+20) + "), "  // linux filepath max 4096, but mysql only support 3072 bytes( UTF-8: 1-3 bytes)
                                "       reactWhiteList      VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + "), "
                                "       reactActual         VARCHAR(" + std::to_string(STATIC_STR_MAXLEN+20) + "), "
                                "       duration_us         BigInt, "
                                "       fileDigest          VARCHAR(256), "     /* sha1: 20 bytes -> 40 hex char */
                                "       comm_args           VARCHAR(" + std::to_string(TASK_ARGV_NUM*TASK_ARGV_LEN+100) + ") "
                                " )";
        pConnectionPool_->createTable(connection_, sql);
        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::deleteData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] deleteData()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement("DELETE FROM " + tableName_));

        pConnectionPool_->deleteData(connection_, pstmt);
        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::upsertData(const ExecRecord& execRecord) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] upsertData()");

    try {
        std::unique_ptr<sql::PreparedStatement> pstmt(
            connection_->prepareStatement(
                "INSERT INTO " + tableName_ + " ("
                                                    "event, "
                                                    "pid, "
                                                    "ppid, "
                                                    "launcherPid, "
                                                    "launcherUid, "
                                                    "launcherEuid, "
                                                    "launcherUserName, "
                                                    "command, "
                                                    "filepath, "
                                                    "reactWhiteList, "
                                                    "reactActual, "
                                                    "duration_us, "
                                                    "fileDigest, "
                                                    "comm_args"
                                                ") "
                                                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                                                " ON DUPLICATE KEY UPDATE fileDigest = VALUES(fileDigest)"));
        pstmt->setString(1, execRecord.event_);
        pstmt->setUInt64(2, execRecord.pid_);
        pstmt->setUInt64(3, execRecord.ppid_);
        pstmt->setUInt64(4, execRecord.launcher_.pid);
        pstmt->setUInt64(5, execRecord.launcher_.uid);
        pstmt->setUInt64(6, execRecord.launcher_.euid);
        pstmt->setString(7, execRecord.launcher_.userName);
        pstmt->setString(8, execRecord.command_);
        pstmt->setString(9, execRecord.filepath_);
        pstmt->setString(10, execRecord.reactWhiteList_);
        pstmt->setString(11, execRecord.reactActual_);
        pstmt->setUInt64(12, execRecord.duration_us_);
        pstmt->setString(13, execRecord.fileDigest_);
        pstmt->setString(14, execRecord.args_);

        pConnectionPool_->upsertData(connection_, pstmt);
        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::retrieveData() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] retrieveData()");

    try {
        ExecRecord execRecord;
        std::unique_ptr<sql::ResultSet> result(nullptr);
        const std::string sql = "SELECT * FROM " + tableName_ + " LIMIT 4 OFFSET 0";
        pConnectionPool_->selectData(connection_, sql, result);

        // Handle result set
        while (!exitingFlag_ && result->next()) {
            execRecord.id_ = result->getUInt64("id");
            execRecord.time_ = result->getString("time");
            execRecord.event_= result->getString("event");
            execRecord.pid_ = result->getUInt64("pid");
            execRecord.ppid_ = result->getUInt64("ppid");
            execRecord.launcher_.pid = result->getUInt64("launcherPid");
            execRecord.launcher_.uid = result->getUInt64("launcherUid");
            execRecord.launcher_.euid = result->getUInt64("launcherEuid");
            execRecord.launcher_.userName = result->getString("launcherUserName");
            execRecord.command_ = result->getString("command");
            execRecord.filepath_ = result->getString("filepath");
            execRecord.reactWhiteList_ = result->getString("reactWhiteList");
            execRecord.reactActual_ = result->getString("reactActual");
            execRecord.duration_us_ = result->getInt64("duration_us");
            execRecord.fileDigest_ = result->getString("fileDigest");
            execRecord.args_ = result->getString("comm_args");

            std::stringstream ss;
            ss  << "[ExecMonitor] ID: " << execRecord.id_ 
                << ", time: " << execRecord.time_ 
                << ", event: " << execRecord.event_
                << ", pid: " << execRecord.pid_ 
                << ", ppid: " << execRecord.ppid_ 
                << ", launcherPid: " << execRecord.launcher_.pid
                << ", launcherUid: " << execRecord.launcher_.uid
                << ", launcherEuid: " << execRecord.launcher_.euid
                << ", launcherUserName: " << execRecord.launcher_.userName
                << ", command: " << execRecord.command_ 
                << ", filepath: " << execRecord.filepath_ 
                << ", reactWhiteList: " << execRecord.reactWhiteList_
                << ", reactActual: " << execRecord.reactActual_ 
                << ", duration_us: " << execRecord.duration_us_ 
                << ", fileDigest: " << execRecord.fileDigest_
                << ", comm_args: " << execRecord.args_;
            
            SPDLOG_LOGGER_INFO(logger.my_logger, "{}", ss.str().c_str());
        }

        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::endTransaction() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] endTransaction()");

    try {
        pConnectionPool_->endTransaction(connection_);
        // throw std::runtime_error("[ExecMonitor] test runtime_error");
        return 1;
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] MySQL error: {}", e.what());
        return -1;
    }
}

int ExecMonitor::initDatabase() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] initDatabase()");

    int ret = -1;

    ret = beginTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Begin Transaction Failed.");
        return -1;
    }

    ret = createDatabase();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Create Database Failed.");
        return -1;
    }

    // ret = deleteTable();
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Delete Table Failed.");
    //     return -1;
    // }

    ret = createTable();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Create Table Failed.");
        return -1;
    }

    // ret = deleteData();
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Delete Data Failed.");
    //     return -1;
    // }

    // ExecRecord execRecord = {
    //     "EXEC", 
    //     444, 
    //     333, 
    //     "testCommand", 
    //     "testFilepath", 
    //     "args", 
    //     execReactionStrList[static_cast<int>(exec_reaction::ALLOW_EXEC)], 
    //     execReactionStrList[static_cast<int>(exec_reaction::ALLOW_EXEC)], 
    //     50, 
    //     "SHA256_SHA256_SHA256_SHA256_SHA257"
    // };
    // ret = upsertData(execRecord);
    // if (1 != ret) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Upsert Data Failed.");
    //     return -1;
    // }

    ret = retrieveData();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Retrieve Data Failed.");
        return -1;
    }

    ret = endTransaction();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] End Transaction Failed.");
        return -1;
    }

    return 1;
}


int ExecMonitor::startSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] startSubThreads()");

    /* Monitor Sub Threads */

    /* data record sub thread */
    try{
        std::thread execDataRecordThread = std::thread([this](){ this->runDataRecordThread(); });
        subThreadsMap_.emplace(
            ExecMonitorSubThreadId::SUB_THREAD_RECORD,
            std::move(execDataRecordThread)     // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Sub Thread Exec Data Record Running...");
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to run Sub Thread Exec Data Record. Error: {}. Set [exitingFlag: true]!", e.what());
        return -1;
    }

    /* ebpf monitor sub thread */
    try{
        std::thread execKernelMonitorThread = std::thread([this](){ this->runKernelMonitorThread(); });
        subThreadsMap_.emplace(
            ExecMonitorSubThreadId::SUB_THREAD_KERNEL,
            std::move(execKernelMonitorThread)     // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Sub Thread Exec Kernel Monitor Running...");
    } catch (const std::system_error& e) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to run Sub Thread Exec Kernel Monitor. Error: {}. Set [exitingFlag: true]!", e.what());
        return -2;
    }

    return 1;
}

int ExecMonitor::stopSubThreads() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecMonitor] Exec Monitor SubThreads Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;

    /* stop record thread */
    recordRequestSemaphore_.release();
    return 1;
}

int ExecMonitor::joinSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] joinSubThreads()");

    /* join monitor sub threads */
    for (auto& pair : subThreadsMap_) {
        if (pair.second.joinable()) {
            pair.second.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Exec Monitor Sub Thread [{}] joined...", static_cast<int>(pair.first));
        }
    }

    return 1;
}


int ExecMonitor::reloadWhiteList() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] reloadWhiteList()");

    int ret = -1;

    /* database -> user mem */
    ret = pWhiteList_->reloadWhiteListRuntimeMap();
    if (1 != ret) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Reload WhiteListMap Failed.");
        return -1;
    }

    /* user mem -> ebpf kernel mem */
    if (subThreadRunningFlag_[static_cast<int>(ExecMonitorSubThreadId::SUB_THREAD_KERNEL)]) {
        /* 同步到内核白名单 */
        ret = synchronizeKernelWhiteList();
        if (1 != ret) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to synchronize Exec Kernel WhiteList.");
            return -2;
        }

        // /* 查看内核白名单 */
        // ret = lookupKernelWhiteList();
        // if (1 != ret) {
        //     SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to lookup Exec Kernel WhiteList.");
        //     return -3;
        // }
    }
    
    return 1;
}

HgWorkModeOption ExecMonitor::getWorkMode() const {
    return workMode_;
}

int ExecMonitor::setWorkMode(const HgWorkModeOption& workMode) {
    workMode_ = workMode;
    return 1;
}

int ExecMonitor::synchronizeKernelWorkMode() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] synchronizeKernelWorkMode()");

    int err = 0;
    kernel_exec_workmode_value value = {workMode_, {0}};

    auto start = getTimePoint();

    /* WorkMode: user mem -> ebpf kernel */
    {
        unsigned long long zero = 0;
        err = bpf_map__update_elem(skel_->maps.work_mode, &zero, sizeof(zero), &value, sizeof(value), BPF_ANY);
        if (err != 0) {
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Exec Kernel WorkMode update runtime work mode failed. [workMode: {}], [ret: {}].", workMode_, err);
            return -1;
        }
        
        SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Exec Kernel WorkMode update runtime work mode success. [workMode: {}]", workMode_);
    }

    /* Time Consume */
    auto duration = getDuration_us(start);
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Time taken by synchronize Exec Kernel WorkMode: [duration: {} seconds]", duration.count() / 1000000.0);
    return 1;
}

int ExecMonitor::lookupKernelWorkMode(HgWorkModeOption& workMode) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] lookupKernelWorkMode()");

    int err = 0;
    unsigned long long zero = 0;
    kernel_exec_workmode_value value = {HgWorkModeOption::WORK_MODE_OPTION_DEF, {0}};

    err = bpf_map__lookup_elem(skel_->maps.work_mode, &zero, sizeof(zero), &value, sizeof(value), BPF_ANY);
    if (err != 0) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Failed to lookup kernel work mode. ret: {}.", err);
        return -1;
    }

    workMode = value.workmode;
    SPDLOG_LOGGER_INFO(logger.my_logger, "[ExecMonitor] Kernel Work Mode: {}.", value.workmode);
    return 1;
}


int ExecMonitor::runMainThread() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] runMainThread()");

    int ret = -1;

    /* Check exiting flag */
    if (exitingFlag_) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[ExecMonitor] ExitingFlag is True. No Need to Start Exec Monitor Sub Threads. Exit..");
        goto end;
    }

    /* Start threads */
    ret = startSubThreads();
    if (1 != ret) {
        stopSubThreads();
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Start Exec Monitor Sub Threads Failed. Set [exitingFlag: true]!Exit..");
    }


    // /* test */
    // {
    //     std::this_thread::sleep_for(std::chrono::seconds(10));
    //     while(!exitingFlag_) {
    //         std::this_thread::sleep_for(std::chrono::seconds(5));
    //         ret = reloadWhiteList();
    //         if (1 != ret) {
    //             SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Test Reload WhiteList Failed. Exit..");
    //             goto end;
    //         }
    //     }
    // }
    


    /* join monitor sub threads */
    joinSubThreads();

end:
    exitingFlag_ = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecMonitor] Exec Monitor Main Thread End. Set [exitingFlag: true]!");
    return 1;
}

int ExecMonitor::stopMainThread() {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[ExecMonitor] Exec Monitor Main Thread Stopping. Set [exitingFlag: true]!");
    exitingFlag_ = true;
    stopSubThreads();
    return 1;
}


// uapi
int ExecMonitor::init() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[ExecMonitor] init()");

    // 获取 libbpf 版本信息
    const char *libbpf_version = libbpf_version_string();
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[ExecMonitor] libbpf Version: {}", libbpf_version);

    int ret = initConnection();
    if (1 != ret) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Init Connection Failed. Set [exitingFlag: true]! Exit..");
        return -1;
    }

    ret = initDatabase();
    if (1 != ret) {
        exitingFlag_ = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[ExecMonitor] Init Database Failed. Set [exitingFlag: true]! Exit..");
        return -2;
    }

    return 1;
}
