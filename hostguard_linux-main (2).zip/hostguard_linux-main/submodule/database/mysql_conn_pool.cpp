/*** 
 * @Author: JiaHao
 * @Date: 2023-12-06 15:45:56
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-08-09 15:57:02
 * @FilePath: /hostguard_linux/submodule/database/mysql_conn_pool.cpp
 * @Description: 
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved. 
 */

#include "database/mysql_conn_pool.h"

// clang++ mysql_conn_pool_4.cpp -std=c++17 -lspdlog -lfmt -lmysqlcppconn -fsanitize=address -fno-omit-frame-pointer -fno-optimize-sibling-calls -O1

extern Spdlogger logger;


MySQLConnectionPool::MySQLConnectionPool(
    const std::string& host, 
    const std::string& user, 
    const std::string& password, 
    const std::string& database, 
    unsigned int port, 
    unsigned int poolSize
)
:   host_(host), 
    user_(user), 
    password_(password), 
    database_(database), 
    port_(port), 
    poolSize_(poolSize) 
{
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] MySQLConnectionPool(xx...)");
    try {
        initializeConnections();
    } catch (const std::runtime_error& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[MySQLConnPool] initializeConnections failed: {}", e.what());
        throw std::runtime_error("[MySQLConnPool] MySQLConnPool init error: " + std::string(e.what()));
    }
}

MySQLConnectionPool::~MySQLConnectionPool() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] ~MySQLConnectionPool()");
    closeConnections();
}

void MySQLConnectionPool::initializeConnections() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] initializeConnections()");

    sql::mysql::MySQL_Driver* driver = sql::mysql::get_mysql_driver_instance();

    try {
        for (unsigned int i = 0; i < poolSize_; ++i) {
            std::shared_ptr<sql::Connection> connection(driver->connect(host_, user_, password_));
            if (connection == nullptr) {
                SPDLOG_LOGGER_ERROR(logger.my_logger, "[MySQLConnPool] Error connecting to MySQL server");
                continue;
            }

            // connection->setSchema(database_);

            connections_.push_back(connection);
            inUse_.push_back(false);
        }
    } catch (const sql::SQLException& e) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[MySQLConnPool] SQLException: {}", e.what());
        throw std::runtime_error("[MySQLConnPool] MySQL connection error: " + std::string(e.what()));
        // Handle the exception as needed
    }
}

void MySQLConnectionPool::closeConnections() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] closeConnections()");

    // Connections will be automatically closed when shared_ptr goes out of scope
    connections_.clear();
    inUse_.clear();
    SPDLOG_LOGGER_DEBUG(logger.my_logger, "[MySQLConnPool] Connections Closed");
}

const std::shared_ptr<sql::Connection> MySQLConnectionPool::getConnection() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] getConnection()");

    std::unique_lock<std::mutex> lock(mutex_);

    for (unsigned int i = 0; i < poolSize_; ++i) {
        if (inUse_[i])
            continue;

        // Add a check for connection health before returning
        if (connections_[i]->isValid()) {
            inUse_[i] = true;
            SPDLOG_LOGGER_DEBUG(logger.my_logger, "[MySQLConnPool] Get Mysql Connection [{}]: 0x{:x}", i, reinterpret_cast<std::uintptr_t>(connections_[i].get()));
            return connections_[i];
        }
    }

    return nullptr;  // No available connections
}

void MySQLConnectionPool::releaseConnection(std::shared_ptr<sql::Connection> connection) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] releaseConnection()");

    std::unique_lock<std::mutex> lock(mutex_);

    for (unsigned int i = 0; i < poolSize_; ++i) {
        if (connections_[i] == connection) {
            SPDLOG_LOGGER_DEBUG(logger.my_logger, "[MySQLConnPool] Release Connection [{}]", i);
            inUse_[i] = false;
            break;
        }
    }
}


void MySQLConnectionPool::setIsolationLevel(const std::shared_ptr<sql::Connection>& connection, const sql::enum_transaction_isolation& level) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] setIsolationLevel()");

    try {
        connection->setTransactionIsolation(level);
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("[MySQLConnPool] MySQL setTransactionIsolation error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::beginTransaction(const std::shared_ptr<sql::Connection>& connection) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] beginTransaction()");

    try {
        connection->setAutoCommit(false);
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[MySQLConnPool] Connection Transaction Begin: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection.get()));
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("[MySQLConnPool] MySQL setAutoCommit error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::rollbackTransaction(const std::shared_ptr<sql::Connection>& connection) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] rollbackTransaction()");

    try {
        connection->rollback();
        connection->setAutoCommit(true);    // reset AutoCommit
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[MySQLConnPool] Connection Transaction Rollback: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection.get()));
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("[MySQLConnPool] MySQL rollback error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::endTransaction(const std::shared_ptr<sql::Connection>& connection) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] endTransaction()");

    try {
        // throw sql::SQLException("[MySQLConnPool] Test commit error");
        connection->commit();
        connection->setAutoCommit(true);    // reset AutoCommit
        SPDLOG_LOGGER_DEBUG(logger.my_logger, "[MySQLConnPool] Connection Transaction Finish: 0x{:x}", reinterpret_cast<std::uintptr_t>(connection.get()));
    } catch (const sql::SQLException& e) {
        
        // Rollback the transaction on commit failure
        try {
            connection->rollback();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[MySQLConnPool] Rollback Success");
        } catch (const sql::SQLException& rollbackError) {
            // Handle rollback failure (you may choose to log or throw an exception)
            SPDLOG_LOGGER_ERROR(logger.my_logger, "[MySQLConnPool] Rollback error: {}", rollbackError.what());
        }

        // You can choose to rethrow the original exception or handle it appropriately
        throw std::runtime_error("[MySQLConnPool] MySQL commit error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::createDatabase(const std::shared_ptr<sql::Connection>& connection, const std::string& databaseName) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] createDatabase()");

    try {
        std::unique_ptr<sql::Statement> stmt(connection->createStatement());
        stmt->execute("CREATE DATABASE IF NOT EXISTS " + databaseName);
        stmt->execute("USE " + databaseName);
        // connection->setSchema(databaseName);
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("MySQL database creation error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::createTable(const std::shared_ptr<sql::Connection>& connection, const std::string& sql) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] createTable()");

    try {
        std::unique_ptr<sql::Statement> stmt(connection->createStatement());
        stmt->execute(sql);
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("[MySQLConnPool] MySQL table creation error: " + std::string(e.what()));
    }
}

bool MySQLConnectionPool::hasTable(const std::shared_ptr<sql::Connection>& connection, const std::string& tableName) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] hasTable()");

    try {
        // 执行查询，检查表是否存在
        std::unique_ptr<sql::Statement> stmt(connection->createStatement());
        std::unique_ptr<sql::ResultSet> result(stmt->executeQuery("SHOW TABLES LIKE '" + tableName + "'"));

        if (result->next()) {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[MySQLConnPool] Table exists in the database: {}", tableName);
            return true;
        } else {
            SPDLOG_LOGGER_INFO(logger.my_logger, "[MySQLConnPool] Table does not exists in the database: {}", tableName);
            return false;
        }

    } catch (const sql::SQLException& e) {
        throw std::runtime_error("MySQL table search error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::deleteTable(const std::shared_ptr<sql::Connection>& connection, const std::string& tableName) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] deleteTable()");

    try {
        std::unique_ptr<sql::Statement> stmt(connection->createStatement());
        stmt->execute("DROP TABLE " + tableName);
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("MySQL table delete error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::upsertData(const std::shared_ptr<sql::Connection>& connection, const std::unique_ptr<sql::PreparedStatement>& pstmt) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] upsertData()");

    try {
        pstmt->executeUpdate();
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("[MySQLConnPool] MySQL data insertion error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::deleteData(const std::shared_ptr<sql::Connection>& connection, const std::unique_ptr<sql::PreparedStatement>& pstmt) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] deleteData()");

    try {
        pstmt->executeUpdate();
    } catch (const sql::SQLException& e) {
        throw std::runtime_error("[MySQLConnPool] MySQL data delete error: " + std::string(e.what()));
    }
}

void MySQLConnectionPool::selectData(const std::shared_ptr<sql::Connection>& connection, const std::string& sql, std::unique_ptr<sql::ResultSet>& result) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[MySQLConnPool] selectData()");

    try {
        std::unique_ptr<sql::Statement> stmt(connection->createStatement());
        result.reset(stmt->executeQuery(sql));

    } catch (const sql::SQLException& e) {
        throw std::runtime_error("[MySQLConnPool] MySQL data select error: " + std::string(e.what()));
    }
}
