/*** 
 * @Author: JiaHao
 * @Date: 2023-12-06 13:38:01
 * @LastEditors: JiaHao
 * @LastEditTime: 2024-06-18 10:09:04
 * @FilePath: /hostguard_linux/src/logger.cpp
 * @Description: 
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved. 
 */

#include "logger.hpp"

Spdlogger logger = {};
