#!/bin/bash

./clear.sh
./build.sh
