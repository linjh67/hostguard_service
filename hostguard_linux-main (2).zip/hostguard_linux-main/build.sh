#!/bin/bash

# 检查当前目录是否存在 build 文件夹
if [ ! -d "build" ]; then
    # 如果不存在，创建新的 build 文件夹
    echo "Build folder not exists. mkdir build.."
    # build folder
    mkdir build
fi

# 检查当前目录是否存在 logs 文件夹
if [ ! -d "logs" ]; then
    # 如果不存在，创建新的 logs 文件夹
    echo "Build folder not exists. mkdir logs.."
    # logs folder
    mkdir logs
fi

cd build

# cmake
echo "cmake..."
cmake ..
echo "cmake end!"
echo ""

# make
echo "make..."
make
echo "make end!"
echo ""