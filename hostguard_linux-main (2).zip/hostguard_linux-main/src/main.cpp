#include "manager/udisk_manager.h"
#include "manager/exec_manager.h"
#include "manager/general_manager.h"

extern Spdlogger logger;

/* signal handler */
volatile bool mainExitingFlag = false;

ExecManager* pExecManager = nullptr;
UdiskManager* pUdiskManager = nullptr;
GeneralManager* pGeneralManager = nullptr;

/* manager threads */
std::map<ManagerMainThreadId, std::thread> managerMainThreadMap_ = {};


void signalHandler(int sig) {
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "Receive [sig: {}] [signalHandler: mainExitingFlag = True].", sig); 
    mainExitingFlag = true;
    if (pExecManager) {
        pExecManager->stopMainThread();
    }

    if (pUdiskManager) {
        pUdiskManager->stopMainThread();
    }

    if (pGeneralManager) {
        pGeneralManager->stopMainThread();
    }
}

int startUdiskManagerMainThread(UdiskManager* pUdiskManager) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Main] startUdiskManagerMainThread()");

    /* Check exiting flag */
    if (mainExitingFlag) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[Main] ExitingFlag is True. No Need to run Udisk Manager Main Thread. Exit..");
        return -1;
    }

    /* Udisk Manager Main Thread */
    try{

        std::thread udiskManagerMainThread = std::thread([pUdiskManager](){ 
            pUdiskManager->runMainThread();
        });   

        managerMainThreadMap_.emplace(
            ManagerMainThreadId::UDISK_MANAGER_MAIN_THREAD,
            std::move(udiskManagerMainThread)       // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[Main] Udisk Manager Main Thread Running...");

    } catch (const std::system_error& e) {
        mainExitingFlag = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Main] Failed to Start Udisk Manager Main Thread: {}. Set [exitingFlag: true]! Exit..", e.what());
        return -2;
    }

    return 1;
}

int startExecManagerMainThread(ExecManager* pExecManager) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Main] startExecManagerMainThread()");

    /* Check exiting flag */
    if (mainExitingFlag) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[Main] ExitingFlag is True. No Need to run Exec Manager Main Thread. Exit..");
        return -1;
    }

    /* Exec Manager Main Thread */
    try{

        std::thread execManagerMainThread = std::thread([pExecManager](){ 
            pExecManager->runMainThread();
        });   

        managerMainThreadMap_.emplace(
            ManagerMainThreadId::EXEC_MANAGER_MAIN_THREAD,
            std::move(execManagerMainThread)       // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[Main] Exec Manager Main Thread Running...");

    } catch (const std::system_error& e) {
        mainExitingFlag = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Main] Failed to Start Exec Manager Main Thread: {}. Set [exitingFlag: true]! Exit..", e.what());
        return -2;
    }

    return 1;
}

int startGeneralManagerMainThread(GeneralManager* pGeneralManager) {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Main] startGeneralManagerMainThread()");

    /* Check exiting flag */
    if (mainExitingFlag) {
        SPDLOG_LOGGER_WARN(logger.my_logger, "[Main] ExitingFlag is True. No Need to run General Manager Main Thread. Exit..");
        return -1;
    }

    /* General Manager Main Thread */
    try{

        std::thread generalManagerMainThread = std::thread([pGeneralManager](){ 
            pGeneralManager->runMainThread();
        });   

        managerMainThreadMap_.emplace(
            ManagerMainThreadId::GENERAL_MANAGER_MAIN_THREAD,
            std::move(generalManagerMainThread)       // 移动操作，thread 对象不可拷贝
        );
        SPDLOG_LOGGER_INFO(logger.my_logger, "[Main] General Manager Main Thread Running...");

    } catch (const std::system_error& e) {
        mainExitingFlag = true;
        SPDLOG_LOGGER_ERROR(logger.my_logger, "[Main] Failed to Start General Manager Main Thread: {}. Set [exitingFlag: true]! Exit..", e.what());
        return -2;
    }

    return 1;
}

int joinSubThreads() {
    SPDLOG_LOGGER_TRACE(logger.my_logger, "[Main] joinSubThreads()");

    /* join monitor threads */
    for (auto& pair : managerMainThreadMap_) {
        if (pair.second.joinable()) {
            pair.second.join();
            SPDLOG_LOGGER_INFO(logger.my_logger, "[Main] Manager [{}] Main Thread joined...", static_cast<int>(pair.first));
        }
    }
    return 1;
}


int main(int argc, char*argv[]){

    // /* Check Args */
    // if (2 != argc) {
    //     SPDLOG_LOGGER_ERROR(logger.my_logger, "Usage: ./build/examples/example1  dirname");
    //     return -1;
    // }

    /* Cleaner handling of Ctrl-C */
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);

    int ret = -1;

    /* MySQLConnectionPool */    
    MySQLConnectionPool connectionPool;

    /* UdiskManager */
    UdiskManager udiskManager = {&connectionPool};
    pUdiskManager = &udiskManager;

    /* ExecManager */
    ExecManager execManager = {&connectionPool};
    pExecManager = &execManager;

    /* GeneralManager */
    GeneralManager generalManager = {pUdiskManager, pExecManager};
    pGeneralManager = &generalManager;


    /* UdiskManager */
    // UdiskManager udiskManager = {&connectionPool};
    // pUdiskManager = &udiskManager;

    ret = startUdiskManagerMainThread(pUdiskManager);
    if (ret != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "UdiskManager runMainThread failed.");
        goto end;
    }

    

    /* ExecManager */
    // ExecManager execManager = {&connectionPool};
    // pExecManager = &execManager;

    ret = startExecManagerMainThread(pExecManager);
    if (ret != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "ExecManager runMainThread failed.");
        goto end;
    }



    /* GeneralManager */
    ret = pGeneralManager->init();
    if (ret != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "GeneralManager init failed.");
        goto end;
    }

    ret = startGeneralManagerMainThread(pGeneralManager);
    if (ret != 1) {
        SPDLOG_LOGGER_ERROR(logger.my_logger, "GeneralManager runMainThread failed.");
        goto end;
    }
    


join_threads:
    /* Join Sub Threads */
    joinSubThreads();

end:
    mainExitingFlag = true;
    SPDLOG_LOGGER_CRITICAL(logger.my_logger, "[Main] Linux HostGuard End.");

    return 0;
}