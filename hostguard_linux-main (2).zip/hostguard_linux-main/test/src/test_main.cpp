/*** 
 * @Author: JiaHao
 * @Date: 2023-11-21 10:20:39
 * @LastEditors: JiaHao
 * @LastEditTime: 2023-12-05 14:35:31
 * @FilePath: /hostguard_linux/test/src/test_main.cpp
 * @Description: 
 * @
 * @Copyright (c) 2023 by JiaHao, All Rights Reserved. 
 */


#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <iostream>
#include <string>

// Demonstrate some basic assertions.
TEST(HelloTest, BasicAssertions) {
  // Expect two strings not to be equal.
  EXPECT_STRNE("hello", "world");
  // Expect equality.
  EXPECT_EQ(7 * 6, 42);
}


// Demonstrate some basic assertions.
TEST(HelloTest2, BasicAssertions2) {
  // Expect two strings not to be equal.
  EXPECT_STREQ("hello", "world");
  // Expect equality.
  EXPECT_EQ(7 * 6, 42);
}



int main(int argc, char **argv){

  ::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();

	return 0;
}