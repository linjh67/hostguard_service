sudo apt update
sudo apt install cmake pkg-config
sudo apt install openssl libssl-dev
sudo apt install linux-tools-generic
sudo apt install libspdlog-dev
sudo apt install mysql-server
sudo apt install libmysqlcppconn-dev
sudo apt install libelf1 libelf-dev zlib1g-dev
# sudo apt install libstdc++-11-dev     # for C++20, or install at least gcc-11, will automatically install libstdc++-11-dev

# kernel <=6.2 C++20
# sudo apt install clang-14 clang 
wget https://apt.llvm.org/llvm.sh
chmod u+x llvm.sh
sudo ./llvm.sh 18
clang-18 --version

# kernel >6.2
# wget https://apt.llvm.org/llvm.sh
# chmod u+x llvm.sh
# sudo ./llvm.sh 18
# clang-18 --version



# # build && install bpftool
# sudo spt install libelf zlib
# git clone --recurse-submodules https://github.com/libbpf/bpftool.git
# cd bpftool/src
# sudo make install

# # build libbpf && copy the lib and header files to dir lib and dir include in this project (I have done this for you)
# git clone https://github.com/libbpf/libbpf.git
# cd src
# mkdir build root
# BUILD_STATIC_ONLY=y OBJDIR=build DESTDIR=root make install
# or use clang as ${cc}: CMAKE_C_COMPILER=clang BUILD_STATIC_ONLY=y OBJDIR=build DESTDIR=root make install